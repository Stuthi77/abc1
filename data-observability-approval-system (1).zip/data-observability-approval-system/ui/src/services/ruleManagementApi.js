// ui/src/services/ruleManagementApi.js
// Matches Flask routes in server/app/RuleManagement/Rulemanagement.py

const API_BASE_URL = `${import.meta.env.VITE_API_URL}`;

// Helpers
const withBase = (path) => `${API_BASE_URL}${path}`;
const pickOne = (v) => (Array.isArray(v) ? (v[0] ?? '') : v);

// 🔑 Always read from sessionStorage dynamically
const getGroupId = () => {
  const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
  return userData?.selectedGroupId || "";
};

async function doFetch(url, init) {
  const startTime = performance.now();
  const res = await fetch(url, {
    ...init,
    headers: { Accept: 'application/json', ...(init && init.headers) },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status} on ${url} :: ${text}`);
  }

  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    const result = await res.json();
    const endTime = performance.now();
    console.log(`⚡ ${url} took ${Math.round(endTime - startTime)}ms`);
    return result;
  }

  const t = await res.text();
  try { return JSON.parse(t); } catch { return t; }
}

export const ruleManagementApi = {
  // GET /api/rulemanagement_filters
  async getFilterOptions() {
    const groupId = getGroupId();
    const url = withBase(`/api/rulemanagement_filters?group_id=${groupId}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // GET /api/table_rule_cards
  async getTablesData(params = {}) {
    const groupId = getGroupId();
    const sp = new URLSearchParams();
    if (params.search)   sp.append('search', params.search);
    if (params.severity) sp.append('severity', pickOne(params.severity));
    if (params.status)   sp.append('status',   pickOne(params.status));
    if (groupId)         sp.append('group_id', groupId);

    const url = withBase(`/api/table_rule_cards${sp.toString() ? `?${sp}` : ''}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // GET /api/tables/:tableId/approved_rules
  async getApprovedRules(tableId, params = {}) {
    const groupId = getGroupId();
    const sp = new URLSearchParams();
    if (params.search)      sp.append('search', params.search);
    if (params.schema)      sp.append('schema', pickOne(params.schema));
    if (params.column_name) sp.append('column_name', pickOne(params.column_name));
    if (groupId)            sp.append('group_id', groupId);

    const url = withBase(`/api/tables/${tableId}/approved_rules${sp.toString() ? `?${sp}` : ''}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // GET /api/tables/:tableId/rules
  async getRuleStatus(tableId, params = {}) {
    const groupId = getGroupId();
    const sp = new URLSearchParams();
    if (params.status)             sp.append('status',             pickOne(params.status));
    if (params.severity)           sp.append('severity',           pickOne(params.severity));
    if (params.Condition_Type)     sp.append('Condition_Type',     pickOne(params.Condition_Type));
    if (params.Condition_Category) sp.append('Condition_Category', pickOne(params.Condition_Category));
    if (groupId)                   sp.append('group_id', groupId);

    const url = withBase(`/api/tables/${tableId}/rules${sp.toString() ? `?${sp}` : ''}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // GET /api/tables/:tableId/filters
  async getTableFilters(tableId) {
    const groupId = getGroupId();
    const url = withBase(`/api/tables/${tableId}/filters${groupId ? `?group_id=${groupId}` : ''}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // GET /api/rules/:ruleId
  async getRuleDetails(ruleId) {
    const groupId = getGroupId();
    const url = withBase(`/api/rules/${ruleId}${groupId ? `?group_id=${groupId}` : ''}`);
    console.debug('[GET]', url);
    return doFetch(url);
  },

  // PUT /api/rules/:ruleId
  async updateRule(ruleId, updateData) {
    const groupId = getGroupId();
    const url = withBase(`/api/rules/${ruleId}${groupId ? `?group_id=${groupId}` : ''}`);
    console.debug('[PUT]', url, updateData);
    return doFetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updateData),
    });
  },

  // DELETE /api/rules/:ruleId
  async deleteRule(ruleId) {
    const groupId = getGroupId();
    const url = withBase(`/api/rules/${ruleId}${groupId ? `?group_id=${groupId}` : ''}`);
    console.debug('[DELETE]', url);
    return doFetch(url, { method: 'DELETE' });
  },

  // Dropdown columns
  async getTableColumns(tableId) {
    const groupId = getGroupId();
    const url = `${import.meta.env.VITE_API_URL}/api/columns/${tableId}${groupId ? `?group_id=${groupId}` : ''}`;
    console.debug('[GET]', url);
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Failed to fetch columns');
    }
    return response.json();
  },

  // NEW: GET /api/groups - Get subscribed groups for current user
  async getSubscribedGroups() {
    const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
    const userId = userData.userId;
    
    if (!userId) {
      throw new Error("User ID not found in session storage");
    }

    const url = withBase(`/api/groups?user_id=${userId}`);
    console.debug('[GET]', url);
    
    const data = await doFetch(url);
    
    // Filter only subscribed groups
    const subscribedGroups = (Array.isArray(data) ? data : []).filter(
      group => group.subscription_status === 'true' || group.subscription_status === true
    );
    
    console.log(`📊 Found ${subscribedGroups.length} subscribed groups`);
    return subscribedGroups;
  },
};