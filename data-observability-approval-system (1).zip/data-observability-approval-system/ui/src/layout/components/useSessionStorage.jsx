import { useState, useEffect, useCallback, useRef } from 'react';

function useSessionStorage(key) {
  const [value, setValue] = useState(() => {
    try {
      const item = window.sessionStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error(`Error parsing sessionStorage key "${key}":`, error);
      return null;
    }
  });

  // Use a ref to hold the current value without causing re-renders
  const lastValue = useRef(value);

  const setSessionValue = useCallback((newValue) => {
    try {
      const valueToStore = newValue instanceof Function ? newValue(lastValue.current) : newValue;
      
      setValue(valueToStore);
      lastValue.current = valueToStore; // Update the ref immediately
      window.sessionStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(`Error setting sessionStorage key "${key}":`, error);
    }
  }, [key]);

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const item = window.sessionStorage.getItem(key);
        const newValue = item ? JSON.parse(item) : null;

        // Compare using a different method if the stringify approach is an issue,
        // but for a simple array of strings, it's usually fine.
        // A better deep comparison function would be more robust.
        if (JSON.stringify(newValue) !== JSON.stringify(lastValue.current)) {
          setValue(newValue);
          lastValue.current = newValue; // Update the ref to the new value
        }
      } catch (error) {
        console.error(`Error handling sessionStorage change for key "${key}":`, error);
      }
    };

    const intervalId = setInterval(handleStorageChange, 500);
    return () => clearInterval(intervalId);
  }, [key]); // No dependency on 'value' here

  return [value, setSessionValue];
}

export default useSessionStorage;