// src/layout/components/Footer.jsx
import React from "react";
import { Box, Typography } from "@mui/material";

const Footer = () => {
  return (
    <Box
      component="footer"
      sx={{
        textAlign: "center",
        p: 0.5,
        backgroundColor: "#F5F5F5",
      }}
    >
      <Typography variant="body2" color="text.secondary">
        © 2025, LatentView Analytics
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Powered by Databricks CoE Innovation Hub @ LatentView
      </Typography>
    </Box>
  );
};

export default Footer;
