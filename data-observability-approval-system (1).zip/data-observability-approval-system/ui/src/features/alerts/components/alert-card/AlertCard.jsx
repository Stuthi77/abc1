// src/features/alert-management/components/alert-card/AlertCard.jsx
import React from "react";

const sentStatusColors = {
  Sent: "#27ae60",
  Pending: "#f39c12",
  Failed: "#c0392b",
};

const styles = {
card: {
  width: "100%",
  maxWidth: "100%",
  marginBottom: "12px",
  boxShadow: "0 1px 4px rgba(0,0,0,0.1)",
  borderRadius: "8px",
  padding: "12px 16px",
  fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  backgroundColor: "#fff",
  display: "flex",
  flexDirection: "column",
  gap: "8px",
  boxSizing: "border-box",
},

  heading: {
    fontWeight: 600,
    fontSize: "1rem",
    color: "#2c3e50",
    borderBottom: "1px solid #eee",
    paddingBottom: "4px",
    marginBottom: "6px",
  },
  row: {
    display: "flex",
    flexWrap: "wrap",
    gap: "16px",
  },
  pair: {
    display: "flex",
    alignItems: "center",
    flex: "1 1 300px",
  },
  label: {
    fontWeight: 500,
    color: "#34495e",
    fontSize: "0.85rem",
    minWidth: "120px",
    marginRight: "4px",
  },
  value: {
    fontSize: "0.85rem",
    color: "#2c3e50",
  },
  statusBox: (status) => ({
    backgroundColor: sentStatusColors[status] || "#777",
    color: "#fff",
    borderRadius: "12px",
    padding: "4px 10px",
    fontSize: "0.75rem",
    fontWeight: 600,
    minWidth: "70px",
    textAlign: "center",
  }),
  diffContainer: {
    display: "flex",
    flexWrap: "wrap",
    gap: "12px",
    marginTop: "8px",
  },
};

const InfoPair = ({ label, value }) => (
  <div style={styles.pair}>
    <span style={styles.label}>{label}:</span>
    <span style={styles.value}>{value}</span>
  </div>
);

const normalizeValue = (val) => {
  if (typeof val === "string") {
    try {
      return JSON.parse(val);
    } catch {
      return val;
    }
  }
  return val;
};

const ModificationSummary = ({ previousData, currentData }) => {
  if (!previousData || !currentData) return null;

  const changedKeys = Object.keys(previousData).filter(
    (key) => JSON.stringify(previousData[key]) !== JSON.stringify(currentData[key])
  );

  if (changedKeys.length === 0) return null;

  return (
    <div>
      <div style={styles.pair}>
        <span style={styles.label}>Rule Modification Summary:</span>
      </div>
      {changedKeys.map((key) => {
        const prev = normalizeValue(previousData[key]);
        const curr = normalizeValue(currentData[key]);

        const displayPrev = Array.isArray(prev)
          ? prev.join(", ")
          : typeof prev === "object"
          ? JSON.stringify(prev)
          : prev;

        const displayCurr = Array.isArray(curr)
          ? curr.join(", ")
          : typeof curr === "object"
          ? JSON.stringify(curr)
          : curr;

        return (
          <div key={key} style={styles.diffContainer}>
            <div>
              <strong style={{ color: "#7f8c8d" }}>{key}:</strong>{" "}
              <span>{displayPrev}</span>
            </div>
            <span style={{ fontSize: "1rem", color: "#aaa" }}>➡️</span>
            <div>
              <strong style={{ color: "#27ae60" }}>Now:</strong>{" "}
              <span style={{ color: "#145a32" }}>{displayCurr}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const AlertCard = ({
  ruleName,
  ruleId,
  ruleDescription,
  tableName,
  owner,
  modifiedDate,
  sentStatus,
  previousData,
  currentData,
}) => {
  return (
    <div style={{ ...styles.card, borderLeft: `6px solid ${sentStatusColors[sentStatus]}` }}>
      <div style={styles.heading}>{ruleName}</div>

      <div style={styles.row}>
        <InfoPair label="Rule ID" value={ruleId} />
        <InfoPair label="Rule Description" value={ruleDescription} />
      </div>
      <div style={styles.row}>
        <InfoPair label="Table" value={tableName} />
        <InfoPair label="Owner" value={owner} />
      </div>
      <div style={styles.row}>
        <InfoPair label="Modified Date" value={modifiedDate} />
        <div style={styles.pair}>
          <span style={styles.label}>Alert Status:</span>
          <span style={styles.statusBox(sentStatus)}>{sentStatus}</span>
        </div>
      </div>

      <ModificationSummary previousData={previousData} currentData={currentData} />
    </div>
  );
};

export default AlertCard;
