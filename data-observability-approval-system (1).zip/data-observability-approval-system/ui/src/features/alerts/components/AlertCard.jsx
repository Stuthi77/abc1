import React, { useState } from "react";
import {
  Card,
  CardContent,
  Typography,
  Button,
  Box,
  Grid,
  Chip,
  Tooltip,
} from "@mui/material";
import ModificationSummary from "./ModificationSummary";
import { useNavigate } from "react-router-dom";
import TableChartIcon from "@mui/icons-material/TableChart";
import RuleSummary  from "./RuleSummary";


const FONT_STACK = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
// ... (CARD_SX, CARD_CONTENT_SX, TITLE_SX, severityColors remain the same) ...
const CARD_SX = {
  width: "100%",
  boxShadow: 4,
  borderRadius: 2,
  transition: "box-shadow 0.3s ease",
  "&:hover": { boxShadow: 3 },
  overflow: "hidden",
};


const CARD_CONTENT_SX = {
  padding: "8px 16px 12px 16px",
  "&:last-child": { paddingBottom: "12px" },
};


const TITLE_SX = {
  fontFamily: FONT_STACK,
  letterSpacing: 1.2,
  lineHeight: 1.2,
  color: "#1e3a8a",
};


const severityColors = {
  Critical: "#d32f2f",
  Warning: "#f57c00",
  Info: "#1976d2",
  Low: "#388e3c",
};


const AlertCard = ({
  ruleId,
  tableName,
  catalog,
  schema,
  owner,
  modifiedDate,
  severity,
  columns,
  effectiveDateFrom,
  conditionType,
  updatedBy,
}) => {
  const [showSummary, setShowSummary] = useState(false);
  const [modificationData, setModificationData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [latestModifiedDate, setLatestModifiedDate] = useState(null);
  const [showSummaryPopup, setShowSummaryPopup] = useState(false);
  const [summaryType, setSummaryType] = useState(
    modifiedDate ? "Rule Modification Summary" : "Rule Summary"
  );
  const [summaryData, setSummaryData] = useState(null);


  const navigate = useNavigate();


  const columnsArr = Array.isArray(columns)
    ? columns
    : typeof columns === "string" && columns.trim().length
      ? columns.split(",").map((s) => s.trim())
      : [];


  const MAX_VISIBLE = 6;
  const hiddenCount = Math.max(0, columnsArr.length - MAX_VISIBLE);
  const displayColumns =
    hiddenCount > 0
      ? `${columnsArr.slice(0, MAX_VISIBLE).join(", ")} +${hiddenCount} more`
      : columnsArr.join(", ");


  const fetchSummary = async () => {
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/api/alerts/${ruleId}/${tableName}/rulesummary`
      );
      const data = await res.json();
      if (data) {
        setSummaryData(data);
        setSummaryType("Rule Summary");
      } else {
        console.warn("⚠️ No summary data found.");
      }
    } catch (error) {
      console.error("❌ Failed to fetch summary:", error);
    }
  };


  const handleToggleSummary = async () => {
    // Note: The button now only toggles 'showSummary' before fetching.
    const nextShow = !showSummary;
    setShowSummary(nextShow);

    // Only fetch/process data when opening the summary AND data isn't already loaded
    if (nextShow && !modificationData) {
      setLoading(true);
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_URL}/api/alerts/${ruleId}/${tableName}/modifications?modified_date=${encodeURIComponent(modifiedDate)}`
        );
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          const modificationsArray = data.map((mod) => ({
            previousData: {
              column_name: mod.old_column_name,
              condition_criteria: mod.old_condition_criteria,
              severity: mod.old_severity,
              violation_threshold: mod.old_violation_threshold,
            },
            currentData: {
              column_name: mod.new_column_name,
              condition_criteria: mod.new_condition_criteria,
              severity: mod.new_severity,
              violation_threshold: mod.new_violation_threshold,
            },
            modifiedDate: mod.modified_date,
          }));
          setModificationData(modificationsArray);
          setSummaryType("Rule Modification Summary")
          const latestDate = modificationsArray.reduce(
            (max, mod) => new Date(mod.modifiedDate) > new Date(max) ? mod.modifiedDate : max,
            modificationsArray[0].modifiedDate
          );
          setLatestModifiedDate(latestDate);
        } else {
          setModificationData([]);
          setSummaryType("Rule Summary");  
          await fetchSummary();
        }
      } catch (error) {
        console.error("❌ Failed to fetch modification summary:", error);
      } finally {
        setLoading(false);
      }
    }
  };
 
  // 💡 NEW FUNCTION TO CLOSE BOTH THE POPUP AND RESET THE BUTTON TEXT STATE
  const handleCloseSummaryPopup = () => {
    setShowSummaryPopup(false); // Close the dialog/popup
    setShowSummary(false);       // Reset the state that controls the button label
  };


  const createdDate = summaryData?.[0]?.created_at;  
  return (
    <Card sx={CARD_SX}>
      <CardContent sx={CARD_CONTENT_SX}>
        {/* ... (Header, Chips, Metadata remain the same) ... */}
        
        {/* Row 1: Table Name + Chips */}
        <Grid container spacing={1} alignItems="center" sx={{ mb: 1 }}>
          <Grid item xs={12} sm={8}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <TableChartIcon sx={{ color: "#1e3a8a70" }} />
              <Typography
                variant="h6"
                sx={{
                  ...TITLE_SX,
                  cursor: "pointer",
                  "&:hover": { textDecoration: "underline" },
                }}
                onClick={() => {
                  const tableId = `${catalog}-${schema}-${tableName}`;
                  navigate(`/rule-management/table/${tableId}`, {
                    state: {
                      tableName,
                      schemaName: `${catalog}.${schema}`,
                      catalogName: catalog
                    }
                  });
                }}
              >
                {tableName}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", justifyContent: { sm: "flex-end", xs: "flex-start" } }}>
              <Chip
                size="small"
                label={conditionType}
                variant="outlined"
                sx={{
                  fontWeight: "bold",
                  fontSize: "10px",
                  borderColor: "#1976d2",
                  color: "#1976d2",
                }}
              />
              <Chip
                size="small"
                label={severity}
                variant="outlined"
                sx={{
                  fontWeight: "bold",
                  fontSize: "10px",
                  borderColor: severityColors[severity],
                  color: severityColors[severity],
                }}
              />
            </Box>
          </Grid>
        </Grid>


        {/* Row 2: catalog.schema */}
        <Grid container sx={{ mb: 1 }}>
          <Grid item xs={12}>
            <Typography variant="body2" sx={{ fontSize: 12, color: "#555" }}>
              {catalog}.{schema}
            </Typography>
          </Grid>
        </Grid>


        {/* Row 3: Columns, Owner, Updated By */}
        <Grid container spacing={2} alignItems="center">
          {/* Columns */}
          <Grid item xs={12} md={6}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, minWidth: 0 }}>
              <Typography component="span" fontSize={13} fontWeight="bold">
                Columns:
              </Typography>
              <Tooltip title={columnsArr.join(", ")} placement="top" arrow>
                <Typography
                  component="span"
                  fontSize={13}
                  sx={{
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    display: "inline-block",
                    maxWidth: "100%",
                  }}
                >
                  {displayColumns}
                </Typography>
              </Tooltip>
            </Box>
          </Grid>


          {/* Owner */}
          <Grid item xs={12} md={3}>
            <Typography fontSize={13} noWrap>
              <b>Owner:</b> {owner || "Unknown"}
            </Typography>
          </Grid>

          {/* Updated By */}

          {modifiedDate && (
            <Grid item xs={12} md={3}>
              <Typography fontSize={13} noWrap>
                <b>Updated By:</b> {updatedBy || "test-user"}
              </Typography>
            </Grid>
          )}
        </Grid>  
       
        {/* Row 4: Toggle + Modified Date */}
        <Grid container justifyContent="space-between" alignItems="center" sx={{ mt: 2 }}>
          <Grid item>
            <Button
              size="small"
              onClick={async () => {
                await handleToggleSummary();         
                setShowSummaryPopup(true);  
              }}

              sx={{
                textTransform: "none",
                fontFamily: FONT_STACK,
                p: 0,
                minWidth: "auto",
                background: "none",
                border: "none",
                boxShadow: "none",
                color: "#1976d2",
                "&:hover": {
                  textDecoration: "underline",
                  color: "#1565c0",
                },
              }}
          >
         
            {showSummary
                ? `Hide ${summaryType || "Summary"}`
                : `Show ${summaryType || "Summary"}`}
           
          </Button>
           


          </Grid>
         
          <Grid item>
            <Typography variant="body2" sx={{ fontSize: 12, color: "#555" }}>
              {( modifiedDate)
                ? `Modified Date: ${ modifiedDate}`
                : createdDate
                ? `Created Date: ${createdDate}`
                : null
              }
             
            </Typography>
          </Grid>
        </Grid>


        {/* Row 5: Collapsible Summary */}
        {showSummaryPopup && (
        Array.isArray(modificationData) && modificationData.length > 0 ? (
          <ModificationSummary
            previousData={modificationData[0].previousData}
            currentData={modificationData[0].currentData}
            modifiedDate={modificationData[0].modifiedDate}
            open={showSummaryPopup}
            onClose={handleCloseSummaryPopup} 
          />
        ) : summaryData && summaryData.length > 0 ? (
          <RuleSummary
            currentData={{
              column_name: summaryData[0].column_name,
              condition: summaryData[0].condition,
              created_at: summaryData[0].created_at,
            }}
            open={showSummaryPopup}
            onClose={handleCloseSummaryPopup} 
          />
        ) : null
      )}

      </CardContent>
    </Card>


  );
};
export default AlertCard;


// import React, { useMemo, useState, useEffect } from "react";
// import {
//   Card,
//   CardContent,
//   Typography,
//   Button,
//   Box,
//   Collapse,
//   Grid,
//   Chip,
//   Tooltip,
// } from "@mui/material";
// import ModificationSummary from "./ModificationSummary";
// import { useNavigate } from "react-router-dom";
// import TableChartIcon from "@mui/icons-material/TableChart";


// import RuleSummary  from "./RuleSummary";


// const FONT_STACK = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";


// const CARD_SX = {
//   width: "100%",
//   boxShadow: 4,
//   borderRadius: 2,
//   transition: "box-shadow 0.3s ease",
//   "&:hover": { boxShadow: 3 },
//   overflow: "hidden",
// };


// const CARD_CONTENT_SX = {
//   padding: "8px 16px 12px 16px",
//   "&:last-child": { paddingBottom: "12px" },
// };


// const TITLE_SX = {
//   fontFamily: FONT_STACK,
//   letterSpacing: 1.2,
//   lineHeight: 1.2,
//   color: "#1e3a8a",
// };


// const severityColors = {
//   Critical: "#d32f2f",
//   Warning: "#f57c00",
//   Info: "#1976d2",
//   Low: "#388e3c",
// };


// const AlertCard = ({
//   ruleId,
//   tableName,
//   catalog,
//   schema,
//   owner,
//   modifiedDate,
//   severity,
//   columns,
//   effectiveDateFrom,
//   conditionType,
//   updatedBy,


// }) => {
//   const [showSummary, setShowSummary] = useState(false);
//   const [modificationData, setModificationData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [latestModifiedDate, setLatestModifiedDate] = useState(null);
//   console.log(ruleId,tableName,modifiedDate,effectiveDateFrom,updatedBy)
//   const [showSummaryPopup, setShowSummaryPopup] = useState(false);
//   const [showModificationSummaryPopup, setShowModificationSummaryPopup] = useState(false);

// //   const hasModifications = useMemo(() => {
// //   return modificationData && modificationData.some(m => m.modifiedDate);
// // }, [modificationData]);
// //   console.log("hasModifications ",hasModifications)


//   const [summaryType, setSummaryType] = useState(
//   modifiedDate ? "Rule Modification Summary" : "Rule Summary"
// );
//   const [summaryData, setSummaryData] = useState(null);


//   const navigate = useNavigate();


//   const columnsArr = Array.isArray(columns)
//     ? columns
//     : typeof columns === "string" && columns.trim().length
//       ? columns.split(",").map((s) => s.trim())
//       : [];


//   const MAX_VISIBLE = 6;
//   const hiddenCount = Math.max(0, columnsArr.length - MAX_VISIBLE);
//   const displayColumns =
//     hiddenCount > 0
//       ? `${columnsArr.slice(0, MAX_VISIBLE).join(", ")} +${hiddenCount} more`
//       : columnsArr.join(", ");




//   const fetchSummary = async () => {
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/alerts/${ruleId}/${tableName}/rulesummary`
//       );
//       const data = await res.json();


//       if (data) {
//         setSummaryData(data);
//         setSummaryType("Rule Summary");
//         console.log(data)
//       } else {
//         console.warn("⚠️ No summary data found.");
//       }
//     } catch (error) {
//       console.error("❌ Failed to fetch summary:", error);
//     }
//   };




//   const handleToggleSummary = async () => {
//     const nextShow = !showSummary;
//     setShowSummary(nextShow);


//     if (nextShow && !modificationData) {
//       setLoading(true);


//       try {
       
//         const res = await fetch(
//           `${import.meta.env.VITE_API_URL}/api/alerts/${ruleId}/${tableName}/modifications?modified_date=${encodeURIComponent(modifiedDate)}`
//         );
//         const data = await res.json();
//         console.log("📡 Modifications fetched:", data);


//         if (Array.isArray(data) && data.length > 0) {
//           const modificationsArray = data.map((mod) => {
//             const previousData = {
//               column_name: mod.old_column_name,
//               condition_criteria: mod.old_condition_criteria,
//               severity: mod.old_severity,
//               violation_threshold: mod.old_violation_threshold,
//             };


//             const currentData = {
//               column_name: mod.new_column_name,
//               condition_criteria: mod.new_condition_criteria,
//               severity: mod.new_severity,
//                violation_threshold: mod.new_violation_threshold,
//             };


//             return {
//               previousData,
//               currentData,
//               modifiedDate: mod.modified_date,
//             };
//           });


//           setModificationData(modificationsArray);
//           setSummaryType("Rule Modification Summary")
//           // Find latest modified date
//           const latestDate = modificationsArray.reduce(
//             (max, mod) =>
//               new Date(mod.modifiedDate) > new Date(max)
//                 ? mod.modifiedDate
//                 : max,
//             modificationsArray[0].modifiedDate
//           );
//           setLatestModifiedDate(latestDate);
//         } else {
//           console.warn("⚠️ No modification data available.");
//           setModificationData([]);
//           setSummaryType("Rule Summary");  
//           await fetchSummary();
//         }
//       } catch (error) {
//         console.error("❌ Failed to fetch modification summary:", error);
//       } finally {
//         setLoading(false);
//       }
//     }
//   };
//   console.log("summaryType", summaryType)
//   console.log("summarydata ",summaryData)
 
//   const createdDate = summaryData?.[0]?.created_at;  
//   return (
//     <Card sx={CARD_SX}>
//       <CardContent sx={CARD_CONTENT_SX}>
//         {/* Row 1: Table Name + Chips */}
//         <Grid container spacing={1} alignItems="center" sx={{ mb: 1 }}>
//           <Grid item xs={12} sm={8}>
//             <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//               <TableChartIcon sx={{ color: "#1e3a8a70" }} />
//               <Typography
//                 variant="h6"
//                 sx={{
//                   ...TITLE_SX,
//                   cursor: "pointer",
//                   "&:hover": { textDecoration: "underline" },
//                 }}


//                 onClick={() => {
                 
//                   const tableId = `${catalog}-${schema}-${tableName}`;
//                   console.log('Navigate to table details:', tableId);
//                   navigate(`/rule-management/table/${tableId}`, {
//                     state: {
//                       tableName,
//                       schemaName: `${catalog}.${schema}`,
//                       catalogName: catalog
//                     }
//                   });
//                 }}


//               >
//                 {tableName}
//               </Typography>
//             </Box>
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", justifyContent: { sm: "flex-end", xs: "flex-start" } }}>
//               <Chip
//                 size="small"
//                 label={conditionType}
//                 variant="outlined"
//                 sx={{
//                   fontWeight: "bold",
//                   fontSize: "10px",
//                   borderColor: "#1976d2",
//                   color: "#1976d2",
//                 }}
//               />
//               <Chip
//                 size="small"
//                 label={severity}
//                 variant="outlined"
//                 sx={{
//                   fontWeight: "bold",
//                   fontSize: "10px",
//                   borderColor: severityColors[severity],
//                   color: severityColors[severity],
//                 }}
//               />
//             </Box>
//           </Grid>
//         </Grid>


//         {/* Row 2: catalog.schema */}
//         <Grid container sx={{ mb: 1 }}>
//           <Grid item xs={12}>
//             <Typography variant="body2" sx={{ fontSize: 12, color: "#555" }}>
//               {catalog}.{schema}
//             </Typography>
//           </Grid>
//         </Grid>


//         {/* Row 3: Columns, Owner, Updated By */}
//         <Grid container spacing={2} alignItems="center">
//           {/* Columns */}
//           <Grid item xs={12} md={6}>
//             <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, minWidth: 0 }}>
//               <Typography component="span" fontSize={13} fontWeight="bold">
//                 Columns:
//               </Typography>
//               <Tooltip title={columnsArr.join(", ")} placement="top" arrow>
//                 <Typography
//                   component="span"
//                   fontSize={13}
//                   sx={{
//                     whiteSpace: "nowrap",
//                     overflow: "hidden",
//                     textOverflow: "ellipsis",
//                     display: "inline-block",
//                     maxWidth: "100%",
//                   }}
//                 >
//                   {displayColumns}
//                 </Typography>
//               </Tooltip>
//             </Box>
//           </Grid>


//           {/* Owner */}
//           <Grid item xs={12} md={3}>
//             <Typography fontSize={13} noWrap>
//               <b>Owner:</b> {owner || "Unknown"}
//             </Typography>
//           </Grid>

//           {/* Updated By */}

//           {modifiedDate && (
//             <Grid item xs={12} md={3}>
//               <Typography fontSize={13} noWrap>
//                 <b>Updated By:</b> {updatedBy || "test-user"}
//               </Typography>
//             </Grid>
//           )}
//         </Grid>  
       
//         {/* Row 4: Toggle + Modified Date */}
//         <Grid container justifyContent="space-between" alignItems="center" sx={{ mt: 2 }}>
//           <Grid item>
           
//             {/* <Button
//             size="small"
//             onClick={() => {
//               console.log("Show summary clicked");
//               setShowSummaryPopup(true)}}
//             // {handleToggleSummary} */}
//             <Button
//               size="small"
//               onClick={async () => {
//                 console.log("Show summary clicked");
//                 await handleToggleSummary();         // load or toggle summary
//                 setShowSummaryPopup(true);  
//                 // handleToggleSummary();        // show popup after data is ready
//               }}

//             sx={{
//               textTransform: "none",
//               fontFamily: FONT_STACK,
//               p: 0,
//               minWidth: "auto",
//               background: "none",
//               border: "none",
//               boxShadow: "none",
//               color: "#1976d2",
//               "&:hover": {
//                 textDecoration: "underline",
//                 color: "#1565c0",
//               },
//             }}
//           >
         
//             {showSummary
//                 ? `Hide ${summaryType || "Summary"}`
//                 : `Show ${summaryType || "Summary"}`}
           
//           </Button>
           


//           </Grid>
         
//           <Grid item>
//             <Typography variant="body2" sx={{ fontSize: 12, color: "#555" }}>
//               {( modifiedDate)
//                 ? `Modified Date: ${ modifiedDate}`
//                 : createdDate
//                 ? `Created Date: ${createdDate}`
//                 : null
//               }
             
//             </Typography>
//           </Grid>
//         </Grid>


//         {/* Row 5: Collapsible Summary */}
//         {showSummaryPopup && (
//         Array.isArray(modificationData) && modificationData.length > 0 ? (
//           <ModificationSummary
//             previousData={modificationData[0].previousData}
//             currentData={modificationData[0].currentData}
//             modifiedDate={modificationData[0].modifiedDate}
//             open={showSummaryPopup}
//             onClose={() => setShowSummaryPopup(false)}
//           />
//         ) : summaryData && summaryData.length > 0 ? (
//           <RuleSummary
//             currentData={{
//               column_name: summaryData[0].column_name,
//               condition: summaryData[0].condition,
//               created_at: summaryData[0].created_at,
//             }}
//             open={showSummaryPopup}
//             onClose={() => setShowSummaryPopup(false)}
//           />
//         ) : null
//       )}

//       </CardContent>
//     </Card>


//   );
// };
// export default AlertCard;