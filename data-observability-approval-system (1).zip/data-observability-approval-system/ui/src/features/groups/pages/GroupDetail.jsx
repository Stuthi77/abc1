// import Autocomplete from '@mui/material/Autocomplete';
// import Box from '@mui/material/Box';
// import Container from '@mui/material/Container';
// import Typography from '@mui/material/Typography';
// import { useState, forwardRef, useEffect } from 'react';
// import PropTypes from 'prop-types';
// import Tabs from '@mui/material/Tabs';
// import Person2Icon from '@mui/icons-material/Person2';
// import Tab from '@mui/material/Tab';
// import TextField from '@mui/material/TextField';
// import Paper from '@mui/material/Paper';
// import Grid from '@mui/material/Grid';
// import { DataGrid } from '@mui/x-data-grid';
// import Button from '@mui/material/Button';
// import IconButton from '@mui/material/IconButton';
// import CloseIcon from '@mui/icons-material/Close';
// import Avatar from '@mui/material/Avatar';
// import Chip from '@mui/material/Chip';
// import Pagination from '@mui/material/Pagination';
// import Dialog from '@mui/material/Dialog';
// import DialogActions from '@mui/material/DialogActions';
// import DialogContent from '@mui/material/DialogContent';
// import DialogContentText from '@mui/material/DialogContentText';
// import DialogTitle from '@mui/material/DialogTitle';
// import Slide from '@mui/material/Slide';
// import CircularProgress from '@mui/material/CircularProgress';
// import { Link, useParams, useNavigate, useLocation } from "react-router-dom"; // Import Link
// import Search from "../../Shared/Components/Search/Search-Feature";
// import { useSearchParams } from 'react-router-dom';
// import GroupIcon from '@mui/icons-material/Group';
// import Skeleton from '@mui/material/Skeleton'; 

// // ----------------- Helpers -----------------
// function CustomTabPanel(props) {
//   const { children, value, index, ...other } = props;
//   return (
//     <div role="tabpanel" hidden={value !== index} {...other}>
//       {value === index && <Box sx={{ mt: 2 }}>{children}</Box>}
//     </div>
//   );
// }
// CustomTabPanel.propTypes = { children: PropTypes.node, index: PropTypes.number.isRequired, value: PropTypes.number.isRequired };
// function a11yProps(index) { return { id: `simple-tab-${index}`, 'aria-controls': `simple-tabpanel-${index}` }; }

// function stringToColor(string) {
//   let hash = 0;
//   for (let i = 0; i < string.length; i += 1) hash = string.charCodeAt(i) + ((hash << 5) - hash);
//   let color = '#';
//   for (let i = 0; i < 3; i += 1) {
//     const value = (hash >> (i * 8)) & 0xff;
//     color += `00${value.toString(16)}`.slice(-2);
//   }
//   return color;
// }
// function stringAvatar(name) {
//   const parts = name.split(' ');
//   let initials = '';
//   if (parts.length === 1) {
//     initials = name[0]?.toUpperCase();
//   } else if (parts.length > 1) {
//     initials = `${parts[0][0].toUpperCase()}${parts[1][0].toUpperCase()}`;
//   }
//   return { sx: { bgcolor: stringToColor(name) }, children: initials };
// }
// const Transition = forwardRef(function Transition(props, ref) {
//   return <Slide direction="up" ref={ref} {...props} />;
// });

// const MemberSkeleton = () => (
//     <Paper elevation={1} sx={{ padding: 1, mb: 1 }}>
//         <Grid container spacing={2} alignItems="center">
//             <Grid item sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
//                 <Skeleton variant="circular" width={40} height={40} />
//                 <Skeleton variant="text" width="60%" />
//             </Grid>
//             <Grid item sx={{ width: 150 }}>
//                 <Skeleton variant="rectangular" width={100} height={24} sx={{ borderRadius: '16px' }} />
//             </Grid>
//             <Grid item sx={{ width: 60, display: "flex", justifyContent: "flex-end" }}>
//                 <Skeleton variant="circular" width={24} height={24} />
//             </Grid>
//         </Grid>
//     </Paper>
// );

// const MembersListSkeleton = () => (
//     <Box sx={{ flex: 1, overflowY: "auto", mt: 2, mb: 2 }}>
//         {[...Array(5)].map((_, index) => <MemberSkeleton key={index} />)}
//     </Box>
// );

// const TableDataGridSkeleton = () => (
//     <Box sx={{ height: "70vh", width: '100%', mt: 2 }}>
//         <Skeleton variant="rectangular" height={40} sx={{ mb: 1, bgcolor: 'grey.300' }} />
//         {[...Array(10)].map((_, index) => (
//             <Skeleton key={index} variant="rectangular" height={52} sx={{ mb: 0.5 }} />
//         ))}
//     </Box>
// );
// // ----------------- Members -----------------
// function Members({ groupId }) {
//   const userData =
//     JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };

//   const [searchMemberText, setSearchMemberText] = useState("");
//   const [members, setMembers] = useState([]);
//   const [allUsers, setAllUsers] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [addMemberOpen, setAddMemberOpen] = useState(false);
//   const [selectedMembers, setSelectedMembers] = useState([]);
//   const [dialogMemberSearch, setDialogMemberSearch] = useState("");
//   const [loadingUsers, setLoadingUsers] = useState(false);
//   const [addingMembers, setAddingMembers] = useState(false);
//   const [removingMemberId, setRemovingMemberId] = useState(null);
//   const [page, setPage] = useState(1);
//   const itemsPerPage = 10;

//   // Fetch members
//   const fetchMembers = async () => {
//     setLoading(true);
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/members`
//       );
//       const data = await res.json();
//       const formatted = (Array.isArray(data) ? data : []).map((m) => ({
//         id: m.user_id,
//         name: m.user_name,
//         role: m.user_role,
//         approved: m.approved_rules || 0,
//         rejected: m.rejected_rules || 0,
//       }));
//       setMembers(formatted);
//     } catch (err) {
//       console.error("Error fetching members:", err);
//       setMembers([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (groupId) fetchMembers();
//   }, [groupId]);

//   // Fetch users for Add dialog
//   const fetchUsers = async () => {
//     setLoadingUsers(true);
//     try {
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/users`);
//       const data = await res.json();
//       const formatted = (Array.isArray(data) ? data : []).map((user) => ({
//         id: user.user_id,
//         name: user.user_name,
//       }));
//       setAllUsers(formatted);
//     } catch (err) {
//       console.error("Error fetching users:", err);
//       setAllUsers([]);
//     } finally {
//       setLoadingUsers(false);
//     }
//   };

//   const handleAddMemberClick = () => {
//     fetchUsers();
//     setAddMemberOpen(true);
//   };

//   // Add members API call
//   const handleAddMembers = async () => {
//     if (selectedMembers.length === 0) return;

//     setAddingMembers(true);
//     try {
//       const user_ids = selectedMembers.map((user) => user.id);

//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`,
//         {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ user_ids }),
//         }
//       );

//       if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
//       await res.json();

//       await fetchMembers();
//       setSelectedMembers([]);
//       setAddMemberOpen(false);
//     } catch (err) {
//       console.error("Error adding members:", err);
//       // alert("Failed to add members. Please try again.");
//     } finally {
//       setAddingMembers(false);
//     }
//   };

//   //  Remove member API call
//   const handleRemoveMember = async (memberId) => {
//     // if (!window.confirm("Are you sure you want to remove this member?")) return;

//     setRemovingMemberId(memberId);
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`,
//         {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ user_ids: [memberId] }),
//         }
//       );

//       if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
//       await res.json();

//       await fetchMembers();
//     } catch (err) {
//       console.error("Error removing member:", err);
//       // alert("Failed to remove member. Please try again.");
//     } finally {
//       setRemovingMemberId(null);
//     }
//   };

//   const filteredMembers = members.filter((m) =>
//     m.name?.toLowerCase().includes(searchMemberText.toLowerCase())
//   );

//   const filteredUsers = allUsers.filter(
//     (user) =>
//       !members.some((m) => m.id === user.id) &&
//       user.name.toLowerCase().includes(dialogMemberSearch.toLowerCase())
//   );

//   const paginatedMembers = filteredMembers.slice(
//     (page - 1) * itemsPerPage,
//     page * itemsPerPage
//   );

//   const handlePageChange = (event, value) => setPage(value);

//   return (
//     <Box>
//       <Grid container spacing={2}>
//         {/* Left Section */}
//         <Grid item sx={{ flexGrow: 1 }}>
//           <Box
//             sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
//           >
//             <Typography variant="h6">Members</Typography>
//             <Box sx={{ display: "flex", gap: 1 }}>
//               <Search
//                 placeholder="Search Member"
//                 searchTerm={searchMemberText}
//                 setSearchTerm={setSearchMemberText}
//                 onSearch={setSearchMemberText}
//               />
//               {userData.role === "data-engineer" && (
//                 <Button
//                   variant="outlined"
//                   color="secondary"
//                   size="small"
//                   sx={{
//                     color: "#29537cff",
//                     borderColor: "#29537cff",
//                     fontWeight: "bold",
//                     "&:hover": {
//                       backgroundColor: "#f7f7faff",
//                       borderColor: "#102a44ff",
//                     },
//                   }}
//                   onClick={handleAddMemberClick}
//                 >
//                   Add Member
//                 </Button>
//               )}
//             </Box>
//           </Box>
//           <hr />

//           <Box sx={{ flex: 1, overflowY: "auto", mt: 2, mb: 2 }}>
//             {loading ? (
//               <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
//                 <MembersListSkeleton />
// {/*                 <CircularProgress /> */}

//               </Box>
//             ) : filteredMembers.length === 0 ? (
//               <Typography sx={{ textAlign: "center", mt: 2 }}>
//                 No members found
//               </Typography>
//             ) : (
//               paginatedMembers.map((member) => (
//                 <Paper key={member.id} elevation={1} sx={{ padding: 1, mb: 1 }}>
//                   <Grid container spacing={2} alignItems="center">
//                     {/* Avatar + Name */}
//                     <Grid item sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
//                       <Avatar {...stringAvatar(member.name)} />
//                       <Typography>{member.name}</Typography>
//                     </Grid>

//                     {/* Role */}
//                     <Grid item sx={{ width: 150 }}>
//                       <Chip
//                         label={<Typography fontSize={14}>{member.role}</Typography>}
//                         size="small"
//                         variant="outlined"
//                       />
//                     </Grid>
//                     {/* Delete Action */}
//                     {userData.role === "data-engineer" && (
//                       <Grid item sx={{ width: 60, display: "flex", justifyContent: "flex-end" }}>
//                         <IconButton
//                           aria-label="delete"
//                           size="small"
//                           onClick={() => handleRemoveMember(member.id)}
//                           disabled={removingMemberId === member.id}
//                         >
//                           {removingMemberId === member.id ? (
//                             //   <MembersListSkeleton />
//                             <CircularProgress size={16} />
//                           ) : (
//                             <CloseIcon fontSize="inherit" />
//                           )}
//                         </IconButton>
//                       </Grid>
//                     )}
//                   </Grid>
//                 </Paper>
//               ))
//             )}
//           </Box>

//           {/* Pagination */}
//           <Box sx={{ display: "flex", justifyContent: "center", mt: 2, mb: 2 }}>
//             <Pagination
//               count={Math.ceil(filteredMembers.length / itemsPerPage) || 1}
//               page={page}
//               onChange={handlePageChange}
//             />
//           </Box>
//         </Grid>

//         {/* Right Section (Total Members) */}
//         <Grid item sx={{ width: 140 }}>
//           <Paper
//             elevation={2}
//             sx={{
//               padding: 2,
//               textAlign: "center",
//               height: 26,
//               display: "flex",
//               flexDirection: "column",
//               alignItems: "center",
//               justifyContent: "center",
//             }}
//           >
//           {loading ? (
//                 <>
//                 <Skeleton variant="text" width="60%" height={30} />
//                 <Skeleton variant="text" width="90%" />
//                 </>
//             ) : (
//             <>
//                 <Typography variant="h5">{members.length}</Typography>
//                     <Typography>Total Members</Typography>
//             </>
//           )}
//           </Paper>
//         </Grid>
//       </Grid>

//       {/* Add Member Dialog */}
//       <Dialog
//         open={addMemberOpen}
//         onClose={() => setAddMemberOpen(false)}
//         maxWidth="sm"
//         fullWidth
//         TransitionComponent={Transition}
//       >
//         <DialogTitle>Add Member</DialogTitle>
//         <DialogContent>
// {/*           <Box
//             sx={{
//               mb: 1,
//               maxWidth: 300,
//               "& input": { height: 35, p: "6px 10px" },
//             }}
//           >
//             <Search
//               placeholder="Search Users"
//               searchTerm={dialogMemberSearch}
//               setSearchTerm={setDialogMemberSearch}
//               onSearch={setDialogMemberSearch}
//             />
//           </Box> */}
//           <Autocomplete
//             multiple
//             size="small"
//             options={filteredUsers}
//             getOptionLabel={(option) => option?.name || ""}
//             value={selectedMembers}
//             onChange={(event, newValue) => setSelectedMembers(newValue)}
//             renderInput={(params) => (
//               <TextField {...params} placeholder="Search or select users" />
//             )}
//             noOptionsText={loadingUsers ? "Loading users..." : "No users found"}
//           />

//           {/* Selected Members List */}
//           <Box
//             mt={2}
//             sx={{
//               minHeight: 300,
//               maxHeight: 300,
//               overflowY: "auto",
//               width: "100%",
//               border: "1px solid #ccc",
//               borderRadius: "4px",
//             }}
//           >
//             {selectedMembers.length > 0 ? (
//               selectedMembers.map((user) => (
//                 <Paper
//                   elevation={0}
//                   key={user.id}
//                   sx={{
//                     padding: 1,
//                     margin: 1,
//                     display: "flex",
//                     justifyContent: "space-between",
//                     alignItems: "center",
//                     "&:hover": { backgroundColor: "#f5f5f5" },
//                   }}
//                 >
//                   <Box
//                     sx={{
//                       width: "100%",
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "space-between",
//                       gap: 1,
//                     }}
//                   >
//                     <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                       <Person2Icon fontSize="20" />
//                       <Typography fontSize={13}>{user.name}</Typography>
//                     </Box>
//                     <IconButton
//                       aria-label="delete"
//                       size="small"
//                       onClick={() =>
//                         setSelectedMembers((prev) =>
//                           prev.filter((u) => u.id !== user.id)
//                         )
//                       }
//                     >
//                       <CloseIcon fontSize="inherit" />
//                     </IconButton>
//                   </Box>
//                 </Paper>
//               ))
//             ) : (
//               <Box sx={{ p: 2, textAlign: "center" }}>
//                 <Typography variant="body2" color="text.secondary">
//                   No members selected
//                 </Typography>
//               </Box>
//             )}
//           </Box>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setAddMemberOpen(false)} disabled={addingMembers}>
//             Cancel
//           </Button>
//           <Button
//             onClick={handleAddMembers}
//             variant="contained"
//             disabled={selectedMembers.length === 0 || addingMembers}
//           >
//             {addingMembers ? (
//               <>
//                 <CircularProgress size={18} sx={{ mr: 1 }} />
//                 Adding...
//               </>
//             ) : (
//               "Add"
//             )}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// }


// // ----------------- Tables -----------------
// function Tables({ groupId }) {
//   const userData = JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };
//   const [tables, setTables] = useState([]);
//   const [allTables, setAllTables] = useState([]);
//   const [searchText, setSearchText] = useState("");
//   const [dialogSearchText, setDialogSearchText] = useState("");
//   const [loading, setLoading] = useState(true);
//   const [loadingAllTables, setLoadingAllTables] = useState(false);
//   const [open, setOpen] = useState(false);
//   const [selectedTables, setSelectedTables] = useState([]);
//   const [submitting, setSubmitting] = useState(false);

//   const columns = [
//     { field: "table_name", headerName: "Tables", flex: 1 },
//     { field: "catalog_name", headerName: "Catalog", flex: 1 },
//     { field: "schema_name", headerName: "Schema", flex: 1 },
//   ];

//   // Fetch group tables
//   useEffect(() => {
//     const fetchTables = async () => {
//       setLoading(true);
//       try {
//         const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables`);
//         const data = await res.json();
//         const formatted = (Array.isArray(data) ? data : []).map((t) => ({
//           ...t,
//           id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
//         }));
//         setTables(formatted);
//       } catch (err) {
//         console.error("Error fetching tables:", err);
//         setTables([]);
//       } finally {
//         setLoading(false);
//       }
//     };
//     if (groupId) fetchTables();
//   }, [groupId]);

//   // Fetch all tables for adding
//   const fetchAllTables = async () => {
//     setLoadingAllTables(true);
//     try {
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/all_tables`);
//       const data = await res.json();
//       const formatted = (Array.isArray(data.tables) ? data.tables : []).map((t) => ({
//         ...t,
//         id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
//       }));
//       setAllTables(formatted);
//     } catch (err) {
//       console.error("Error fetching all tables:", err);
//       setAllTables([]);
//     } finally {
//       setLoadingAllTables(false);
//     }
//   };

//   const handleAddTableClick = () => {
//     setSelectedTables([]);
//     fetchAllTables();
//     setOpen(true);
//   };

//   const handleAddTables = async () => {
//     console.log("Selected IDs before submit:", selectedTables);
//     const newTables = selectedTables
//       .map((id) => allTables.find((t) => t.id === id))
//       .filter(Boolean);
//     console.log("New tables to submit:", newTables);

//     if (newTables.length === 0) {
//       setOpen(false);
//       return;
//     }

//     setSubmitting(true);
//     try {
//       // Call backend API
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables/add`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           tables: newTables.map(({ catalog_name, schema_name, table_name }) => ({
//             catalog_name,
//             schema_name,
//             table_name
//           }))
//         }),
//       });

//       if (!res.ok) throw new Error("Failed to add tables");
//       const result = await res.json();
//       console.log("Add tables response:", result);

//       // Update frontend state
//       const existingTableIds = new Set(tables.map((t) => t.id));
//       const uniqueNewTables = newTables.filter((t) => !existingTableIds.has(t.id));
//       setTables((prev) => [...prev, ...uniqueNewTables]);
//     } catch (err) {
//       console.error("Error adding tables:", err);
//     } finally {
//       setSubmitting(false);
//       setSelectedTables([]);
//       setOpen(false);
//     }
//   };

//   const filteredRows = tables.filter((row) =>
//     Object.values(row).some((val) =>
//       String(val).toLowerCase().includes(searchText.toLowerCase())
//     )
//   );

//   const filteredAllTables = allTables.filter(
//     (t) =>
//       !tables.some((groupTable) => groupTable.id === t.id) &&
//       Object.values(t).some((val) =>
//         String(val).toLowerCase().includes(dialogSearchText.toLowerCase())
//       )
//   );

//   return (
//     <Box>
//       {/* Search + Add Button */}
//       <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
//         <Search
//           placeholder="Search Table"
//           searchTerm={searchText}
//           setSearchTerm={setSearchText}
//           onSearch={setSearchText}
//         />
//         {userData.role === "data-engineer" && (
//           <Button
//             variant="outlined"
//             color="secondary"
//             size="small"
//             sx={{
//               color: "#29537cff",
//               borderColor: "#29537cff",
//               fontWeight: "bold",
//               "&:hover": { backgroundColor: "#f7f7faff", borderColor: "#102a44ff" },
//             }}
//             onClick={handleAddTableClick}
//           >
//             Add Table
//           </Button>
//         )}
//       </Box>

//       {/* Main DataGrid */}

// {/*       {loading ? (
//         <Box sx={{ 
//             display: "flex", 
//             justifyContent: "center", 
//             alignItems: "center", 
//             height: "70vh" 
//         }}>
//         <CircularProgress />
//         </Box>
//       ) : ( */}
//       {loading ? (
//         <TableDataGridSkeleton /> // <-- NEW SKELETON
//       ) : (
//         <DataGrid
//           sx={{
//             height: "70vh",
//             border: "none",
//             "& .MuiDataGrid-row:hover": { backgroundColor: "#f7f7faff" },
//             "& .MuiDataGrid-columnHeaders": { backgroundColor: "#000000", height: 40 },
//           }}
//           rows={filteredRows || []}
//           columns={columns}
//           getRowId={(row) => row.id || Math.random()}
//           disableRowSelectionOnClick
//           pagination
//           initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
//           pageSizeOptions={[10, 20]}
//         />
//       )}

//       {/* Add Tables Dialog */}
//       <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
//         <DialogTitle>Add Tables</DialogTitle>
//         <DialogContent>
//           <Search
//             placeholder="Search Tables"
//             searchTerm={dialogSearchText}
//             setSearchTerm={setDialogSearchText}
//             onSearch={setDialogSearchText}
//           />
// {/*           {loadingAllTables ? (
//             <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
//               <CircularProgress />
//             </Box>
//           ) : ( */}
//           {loadingAllTables ? (
//             <Box sx={{ minHeight: "70vh" }}>
//               <TableDataGridSkeleton /> {/* <-- USE THE TABLE SKELETON HERE */}
//             </Box>
//           ) : (
//             <DataGrid
//               sx={{ height: "70vh", border: "none", mt: 2 }}
//               rows={filteredAllTables}
//               columns={columns}
//               getRowId={(row) => `${row.catalog_name}-${row.schema_name}-${row.table_name}`}
//               checkboxSelection
//               disableRowSelectionOnClick
//               //rowSelectionModel={selectedTables} // <- controlled
//               onRowSelectionModelChange={(selectionModel) => {
//                 // If it's an object with ids, convert Set -> Array
//                 const ids = selectionModel?.ids
//                   ? Array.from(selectionModel.ids)
//                   : Array.isArray(selectionModel)
//                     ? selectionModel
//                     : [];

//                 console.log("Clean IDs:", ids);
//                 setSelectedTables(ids);
//               }}
//               initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
//               pageSizeOptions={[10, 20]}
//             />
//           )}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => {
//             setOpen(false);
//             setSelectedTables([]);
//           }}>
//             Cancel
//           </Button>
//           <Button
//             onClick={handleAddTables}
//             variant="contained"
//             disabled={selectedTables.length === 0 || submitting}
//           >
//             {submitting ? "Submitting..." : "Submit"}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// }
// const formatGroupName = (name) => {
//   if (!name) return "";
//   // Replaces hyphens with spaces and capitalizes each word
//   return name
//     .split("-")
//     .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
//     .join(" ");
// };

// function GroupDetail() {
//   const [value, setValue] = useState(0);
//   const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
//   const [deleting, setDeleting] = useState(false);
//   const [groupDetails, setGroupDetails] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [isProcessing, setIsProcessing] = useState(false);

//   const { groupId } = useParams();
//   const location = useLocation();
//   const navigate = useNavigate(); // Initialize useNavigate
//   const [searchParams] = useSearchParams();
//   const { groupName: nameFromState } = location.state || {};
//   const formattedName = formatGroupName(nameFromState);
//   useEffect(() => {
//     const tabParam = searchParams.get('tab');
//     if (tabParam === 'members') {
//       setValue(1);
//     } else {
//       // Default to 'tables' (index 0) if param is 'tables', null, or invalid
//       setValue(0);
//     }
//   }, [searchParams]);
// //   useEffect(() => {
// //     const tabParam = searchParams.get('tab');
// //     if (tabParam === 'tables') {
// //       setValue(0);
// //     } else if (tabParam === 'members') {
// //       setValue(1);
// //     }
// //   }, [searchParams]); // Re-run effect when search params change

//   const userData = JSON.parse(sessionStorage.getItem("userData")) || {
//     role: "data-engineer",
//     userId: "mock_user_id"
//   };
//   const userId = userData.userId;

//   // Function to fetch group details
//   const fetchGroupDetails = async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const url = new URL(`${import.meta.env.VITE_API_URL}/api/groups`, window.location.origin);
//       url.searchParams.append('user_id', userId);

//       const response = await fetch(url.toString());
//       if (!response.ok) {
//         throw new Error('Failed to fetch group details.');
//       }

//       const data = await response.json();
//       const groupData = data.find(group => group.group_id === groupId);

//       if (!groupData) {
//         throw new Error("Group not found.");
//       }

//       setGroupDetails({
//         ...groupData,
//         subscription_status: groupData.subscription_status === 'true'
//       });
//     } catch (err) {
//       setError(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchGroupDetails();
//   }, [groupId, userId]);

//   // Handler for dynamic subscribe/unsubscribe button
//   const handleSubscriptionChange = async () => {
//     if (!userId) {
//       console.error("User not authenticated. Cannot perform action.");
//       return;
//     }

//     setIsProcessing(true);
//     const endpoint = groupDetails.subscription_status
//       ? `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`
//       : `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`;

//     try {
//       const res = await fetch(endpoint, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ user_ids: [userId] }),
//       });

//       if (!res.ok) {
//         throw new Error(`Failed to update subscription: ${res.statusText}`);
//       }

//       console.log("Subscription status updated. Re-fetching group details...");
//       await fetchGroupDetails();
//     } catch (err) {
//       console.error("Error updating subscription:", err);
//     } finally {
//       setIsProcessing(false);
//     }
//   };

//   const handleDeleteGroup = async () => {
//     setDeleting(true);
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}`,
//         {
//           method: "DELETE",
//         }
//       );
//       if (!res.ok) throw new Error("Failed to delete group");

//       console.log("Group deleted");
//       // 👉 redirect or refresh depending on your flow
//       window.location.href = "/groups";
//     } catch (err) {
//       console.error("Error deleting group:", err);
//     } finally {
//       setDeleting(false);
//       setDeleteDialogOpen(false);
//     }
//   };

// //   if (loading) {
// //     return (
// //       <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '70vh' }}>
// //         <CircularProgress />
// //       </Box>
// //     );
// //   }
// // NEW CODE for GroupDetail loading state
//   if (loading) {
//     return (
//       <Container maxWidth="lg" sx={{ mt: 2 }}>
//             {/* Header Skeleton: Breadcrumbs, Buttons */}
//             <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
//                 <Skeleton variant="text" width="20%" />
//                 <Box sx={{ display: "flex", gap: 1 }}>
//                     <Skeleton variant="rectangular" width={100} height={30} />
//                     {userData.role === "data-engineer" && <Skeleton variant="rectangular" width={120} height={30} />}
//                 </Box>
//             </Box>
//             {/* Header Skeleton: Title */}
//             <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, my: 2 }}>
//                 <Skeleton variant="circular" width={32} height={32} />
//                 <Skeleton variant="text" width="30%" height={36} />
//             </Box>

//             {/* Tabs Skeleton */}
//             <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
//                 <Box sx={{ display: 'flex', gap: 4 }}>
//                     <Skeleton variant="text" width={80} height={48} />
//                     <Skeleton variant="text" width={80} height={48} />
//                 </Box>
//             </Box>

//             {/* Content Area Skeleton (Use Tables skeleton by default) */}
//             <Box sx={{ mt: 2 }}>
//                 <TableDataGridSkeleton />
//             </Box>
//       </Container>
//     );
//   }

//   if (error) {
//     return (
//       <Typography color="error" sx={{ textAlign: 'center', mt: 4 }}>
//         Error: {error}
//       </Typography>
//     );
//   }
//   return (
//     <Box>
//       <Container maxWidth="lg">
//         <Box
//           sx={{
//             mt: 2,
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "space-between",
//             alignItems: "flex-start",
//           }}
//         >
//           <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
//             <Typography sx={{ color: 'grey.600' }}>
//               <Box component="span" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }} onClick={() => navigate('/groups')}>
//                 Groups
//               </Box>
//               <span> / {formattedName || groupDetails?.group_name || groupId}</span>
//             </Typography>
//             <Box sx={{ display: "flex", gap: 1 }}>
//               <Button
//                 size="small"
//                 color={groupDetails.subscription_status ? "error" : "success"}
//                 onClick={handleSubscriptionChange}
//                 disabled={isProcessing || !userId}
//               >
//                 {isProcessing ? (
//                   <CircularProgress size={18} sx={{ mr: 1 }} />
//                 ) : (
//                   groupDetails.subscription_status ? 'Unsubscribe' : 'Subscribe'
//                 )}
//               </Button>
//               {userData.role === "data-engineer" && (
//                 <Button
//                   size="small"
//                   variant="contained"
//                   color="error"
//                   onClick={() => setDeleteDialogOpen(true)}
//                   disabled={deleting}
//                 >
//                   Delete Group
//                 </Button>
//               )}
//             </Box>
//           </Box>
//           <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
//             <GroupIcon sx={{fontSize: '2rem', color: '#1a75c2' }} />
//             <Typography variant="h6">
              
//               {formattedName || groupDetails?.group_name || groupId}
//             </Typography>
//           </Box>
//         </Box>

//         {/* Tabs + Content */}
// {/*         <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
//           <Tabs value={value} onChange={(e, newValue) => setValue(newValue)}>
//             <Tab label="Tables" {...a11yProps(0)} />
//             <Tab label="Members" {...a11yProps(1)} />
//           </Tabs>
//         </Box> */}
//         <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
//           <Tabs 
//             value={value} 
//             onChange={(e, newValue) => {
//               setValue(newValue); // Update local state for immediate UI change
//               
//               // Determine the new URL parameter value
//               const tabParam = newValue === 1 ? 'members' : 'tables';
//               
//               // Update the URL using react-router's navigate
//               navigate(`?tab=${tabParam}`, { replace: true });
//             }}
//           >
//             <Tab label="Tables" {...a11yProps(0)} />
//             <Tab label="Members" {...a11yProps(1)} />
//           </Tabs>
//         </Box>
//         <CustomTabPanel value={value} index={0}>
//           <Tables groupId={groupId} />
//         </CustomTabPanel>
//         <CustomTabPanel value={value} index={1}>
//           <Members groupId={groupId} />
//         </CustomTabPanel>
//       </Container>

//       {/* Delete Dialog */}
//       <Dialog
//         open={deleteDialogOpen}
//         onClose={() => !deleting && setDeleteDialogOpen(false)}
//       >
//         <DialogTitle>Delete Group</DialogTitle>
//         <DialogContent>
//           <DialogContentText>
//             Are you sure you want to delete this group? This action cannot be
//             undone.
//           </DialogContentText>
//         </DialogContent>
//         <DialogActions>
//           <Button
//             onClick={() => setDeleteDialogOpen(false)}
//             disabled={deleting}
//           >
//             Cancel
//           </Button>
//           <Button
//             onClick={handleDeleteGroup}
//             color="error"
//             variant="contained"
//             disabled={deleting}
//           >
//             {deleting ? (
//               <>
//                 <CircularProgress size={18} sx={{ mr: 1 }} /> Deleting...
//               </>
//             ) : (
//               "Delete"
//             )}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// }
// export default GroupDetail;

import Autocomplete from '@mui/material/Autocomplete';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import { useState, forwardRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Person2Icon from '@mui/icons-material/Person2';
import Tab from '@mui/material/Tab';
import TextField from '@mui/material/TextField';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { DataGrid } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import Pagination from '@mui/material/Pagination';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import CircularProgress from '@mui/material/CircularProgress';
import { Link, useParams, useNavigate, useLocation } from "react-router-dom"; // Import Link
import Search from "../../Shared/Components/Search/Search-Feature";
import { useSearchParams } from 'react-router-dom';
import GroupIcon from '@mui/icons-material/Group';
import Skeleton from '@mui/material/Skeleton'; 

// ----------------- Helpers -----------------
function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ mt: 2 }}>{children}</Box>}
    </div>
  );
}
CustomTabPanel.propTypes = { children: PropTypes.node, index: PropTypes.number.isRequired, value: PropTypes.number.isRequired };
function a11yProps(index) { return { id: `simple-tab-${index}`, 'aria-controls': `simple-tabpanel-${index}` }; }

function stringToColor(string) {
  let hash = 0;
  for (let i = 0; i < string.length; i += 1) hash = string.charCodeAt(i) + ((hash << 5) - hash);
  let color = '#';
  for (let i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  return color;
}
function stringAvatar(name) {
  const parts = name.split(' ');
  let initials = '';
  if (parts.length === 1) {
    initials = name[0]?.toUpperCase();
  } else if (parts.length > 1) {
    initials = `${parts[0][0].toUpperCase()}${parts[1][0].toUpperCase()}`;
  }
  return { sx: { bgcolor: stringToColor(name) }, children: initials };
}
const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const MemberSkeleton = () => (
    <Paper elevation={1} sx={{ padding: 1, mb: 1 }}>
        <Grid container spacing={2} alignItems="center">
            <Grid item sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
                <Skeleton variant="circular" width={40} height={40} />
                <Skeleton variant="text" width="60%" />
            </Grid>
            <Grid item sx={{ width: 150 }}>
                <Skeleton variant="rectangular" width={100} height={24} sx={{ borderRadius: '16px' }} />
            </Grid>
            <Grid item sx={{ width: 60, display: "flex", justifyContent: "flex-end" }}>
                <Skeleton variant="circular" width={24} height={24} />
            </Grid>
        </Grid>
    </Paper>
);

const MembersListSkeleton = () => (
    <Box sx={{ flex: 1, overflowY: "auto", mt: 2, mb: 2 }}>
        {[...Array(5)].map((_, index) => <MemberSkeleton key={index} />)}
    </Box>
);

const TableDataGridSkeleton = () => (
    <Box sx={{ height: "70vh", width: '100%', mt: 2 }}>
        <Skeleton variant="rectangular" height={40} sx={{ mb: 1, bgcolor: 'grey.300' }} />
        {[...Array(10)].map((_, index) => (
            <Skeleton key={index} variant="rectangular" height={52} sx={{ mb: 0.5 }} />
        ))}
    </Box>
);
// // ----------------- Members -----------------
// function Members({ groupId }) {
//   const userData =
//     JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };

//   const [searchMemberText, setSearchMemberText] = useState("");
//   const [members, setMembers] = useState([]);
//   const [allUsers, setAllUsers] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [addMemberOpen, setAddMemberOpen] = useState(false);
//   const [selectedMembers, setSelectedMembers] = useState([]);
//   const [dialogMemberSearch, setDialogMemberSearch] = useState("");
//   const [loadingUsers, setLoadingUsers] = useState(false);
//   const [addingMembers, setAddingMembers] = useState(false);
//   const [removingMemberId, setRemovingMemberId] = useState(null);
//   const [page, setPage] = useState(1);
//   const itemsPerPage = 10;
//   const [groupName, setGroupName] = useState(null);

//     // Helper flag for conditional rendering/disabling
//   const isApproversGroup = groupName === 'Approvers';

//     // 2. NEW: Function to fetch the group name 
//     // This is necessary because the check is based on the name, not the ID.
//   const fetchGroupName = async () => {
//         try {
//             // NOTE: This assumes you have an API endpoint to fetch a single group's details by ID.
//             // If not, you must adapt to use the /api/groups endpoint and search the result array.
//             const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}`);
//             if (res.ok) {
//                 const data = await res.json();
//                 setGroupName(data.group_name);
//             } else {
//                 console.error("Failed to fetch group name.");
//             }
//         } catch (err) {
//             console.error("Error fetching group name:", err);
//         }
//     };

//   // Fetch members
//   const fetchMembers = async () => {
//     setLoading(true);
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/members`
//       );
//       const data = await res.json();
//       const formatted = (Array.isArray(data) ? data : []).map((m) => ({
//         id: m.user_id,
//         name: m.user_name,
//         role: m.user_role,
//         approved: m.approved_rules || 0,
//         rejected: m.rejected_rules || 0,
//       }));
//       setMembers(formatted);
//     } catch (err) {
//       console.error("Error fetching members:", err);
//       setMembers([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (groupId) fetchMembers();fetchGroupName();
//   }, [groupId]);

//   // Fetch users for Add dialog
//   const fetchUsers = async () => {
//     setLoadingUsers(true);
//     try {
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/users`);
//       const data = await res.json();
//       const formatted = (Array.isArray(data) ? data : []).map((user) => ({
//         id: user.user_id,
//         name: user.user_name,
//       }));
//       setAllUsers(formatted);
//     } catch (err) {
//       console.error("Error fetching users:", err);
//       setAllUsers([]);
//     } finally {
//       setLoadingUsers(false);
//     }
//   };

//   const handleAddMemberClick = () => {
//     fetchUsers();
//     setAddMemberOpen(true);
//   };

//   // Add members API call
//   const handleAddMembers = async () => {
//     if (selectedMembers.length === 0) return;

//     setAddingMembers(true);
//     try {
//       const user_ids = selectedMembers.map((user) => user.id);

//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`,
//         {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ user_ids }),
//         }
//       );

//       if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
//       await res.json();

//       await fetchMembers();
//       setSelectedMembers([]);
//       setAddMemberOpen(false);
//     } catch (err) {
//       console.error("Error adding members:", err);
//       // alert("Failed to add members. Please try again.");
//     } finally {
//       setAddingMembers(false);
//     }
//   };

//   //  Remove member API call
//   const handleRemoveMember = async (memberId) => {
//     // if (!window.confirm("Are you sure you want to remove this member?")) return;

//     setRemovingMemberId(memberId);
//     try {
//       const res = await fetch(
//         `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`,
//         {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ user_ids: [memberId] }),
//         }
//       );

//       if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
//       await res.json();

//       await fetchMembers();
//     } catch (err) {
//       console.error("Error removing member:", err);
//       // alert("Failed to remove member. Please try again.");
//     } finally {
//       setRemovingMemberId(null);
//     }
//   };

//   const filteredMembers = members.filter((m) =>
//     m.name?.toLowerCase().includes(searchMemberText.toLowerCase())
//   );

//   const filteredUsers = allUsers.filter(
//     (user) =>
//       !members.some((m) => m.id === user.id) &&
//       user.name.toLowerCase().includes(dialogMemberSearch.toLowerCase())
//   );

//   const paginatedMembers = filteredMembers.slice(
//     (page - 1) * itemsPerPage,
//     page * itemsPerPage
//   );

//   const handlePageChange = (event, value) => setPage(value);

//   return (
//     <Box>
//       <Grid container spacing={2}>
//         {/* Left Section */}
//         <Grid item sx={{ flexGrow: 1 }}>
//           <Box
//             sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
//           >
//             <Typography variant="h6">Members</Typography>
//             <Box sx={{ display: "flex", gap: 1 }}>
//               <Search
//                 placeholder="Search Member"
//                 searchTerm={searchMemberText}
//                 setSearchTerm={setSearchMemberText}
//                 onSearch={setSearchMemberText}
//               />
//               {userData.role === "data-engineer" && (
//                 <Button
//                   variant="outlined"
//                   color="secondary"
//                   size="small"
//                   sx={{
//                         color: isApproversGroup ? 'text.disabled' : "#29537cff", // Styles for disabled state
//                         borderColor: isApproversGroup ? 'grey.300' : "#29537cff",
//                         fontWeight: "bold",
//                         "&:hover": {
//                             backgroundColor: isApproversGroup ? 'grey.100' : "#f7f7faff",
//                             borderColor: isApproversGroup ? 'grey.300' : "#102a44ff",
//                         },
//                     }}
// //                   sx={{
// //                     color: "#29537cff",
// //                     borderColor: "#29537cff",
// //                     fontWeight: "bold",
// //                     "&:hover": {
// //                       backgroundColor: "#f7f7faff",
// //                       borderColor: "#102a44ff",
// //                     },
// //                   }}
//                   onClick={handleAddMemberClick}
//                   disabled={isApproversGroup|| loading ||loadingUsers} 
//                 >
//                   Add Member
//                 </Button>
//               )}
//             </Box>
//           </Box>
//           <hr />

//           <Box sx={{ flex: 1, overflowY: "auto", mt: 2, mb: 2 }}>
//             {loading ? (
//               <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
//                 <MembersListSkeleton />
// {/*                 <CircularProgress /> */}

//               </Box>
//             ) : filteredMembers.length === 0 ? (
//               <Typography sx={{ textAlign: "center", mt: 2 }}>
//                 No members found
//               </Typography>
//             ) : (
//               paginatedMembers.map((member) => (
//                 <Paper key={member.id} elevation={1} sx={{ padding: 1, mb: 1 }}>
//                   <Grid container spacing={2} alignItems="center">
//                     {/* Avatar + Name */}
//                     <Grid item sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
//                       <Avatar {...stringAvatar(member.name)} />
//                       <Typography>{member.name}</Typography>
//                     </Grid>

//                     {/* Role */}
//                     <Grid item sx={{ width: 150 }}>
//                       <Chip
//                         label={<Typography fontSize={14}>{member.role}</Typography>}
//                         size="small"
//                         variant="outlined"
//                       />
//                     </Grid>
//                     {/* Delete Action */}
//                     {userData.role === "data-engineer" && (
//                       <Grid item sx={{ width: 60, display: "flex", justifyContent: "flex-end" }}>
//                         <IconButton
//                           aria-label="delete"
//                           size="small"
//                           onClick={() => handleRemoveMember(member.id)}
//                           disabled={removingMemberId === member.id}
//                         >
//                           {removingMemberId === member.id ? (
//                             //   <MembersListSkeleton />
//                             <CircularProgress size={16} />
//                           ) : (
//                             <CloseIcon fontSize="inherit" />
//                           )}
//                         </IconButton>
//                       </Grid>
//                     )}
//                   </Grid>
//                 </Paper>
//               ))
//             )}
//           </Box>

//           {/* Pagination */}
//           <Box sx={{ display: "flex", justifyContent: "center", mt: 2, mb: 2 }}>
//             <Pagination
//               count={Math.ceil(filteredMembers.length / itemsPerPage) || 1}
//               page={page}
//               onChange={handlePageChange}
//             />
//           </Box>
//         </Grid>

//         {/* Right Section (Total Members) */}
//         <Grid item sx={{ width: 140 }}>
//           <Paper
//             elevation={2}
//             sx={{
//               padding: 2,
//               textAlign: "center",
//               height: 26,
//               display: "flex",
//               flexDirection: "column",
//               alignItems: "center",
//               justifyContent: "center",
//             }}
//           >
//           {loading ? (
//                 <>
//                 <Skeleton variant="text" width="60%" height={30} />
//                 <Skeleton variant="text" width="90%" />
//                 </>
//             ) : (
//             <>
//                 <Typography variant="h5">{members.length}</Typography>
//                     <Typography>Total Members</Typography>
//             </>
//           )}
//           </Paper>
//         </Grid>
//       </Grid>

//       {/* Add Member Dialog */}
//       <Dialog
//         open={addMemberOpen}
//         onClose={() => setAddMemberOpen(false)}
//         maxWidth="sm"
//         fullWidth
//         TransitionComponent={Transition}
//       >
//         <DialogTitle>Add Member</DialogTitle>
//         <DialogContent>
// {/*           <Box
//             sx={{
//               mb: 1,
//               maxWidth: 300,
//               "& input": { height: 35, p: "6px 10px" },
//             }}
//           >
//             <Search
//               placeholder="Search Users"
//               searchTerm={dialogMemberSearch}
//               setSearchTerm={setDialogMemberSearch}
//               onSearch={setDialogMemberSearch}
//             />
//           </Box> */}
//           <Autocomplete
//             multiple
//             size="small"
//             options={filteredUsers}
//             getOptionLabel={(option) => option?.name || ""}
//             value={selectedMembers}
//             onChange={(event, newValue) => setSelectedMembers(newValue)}
//             renderInput={(params) => (
//               <TextField {...params} placeholder="Search or select users" />
//             )}
//             noOptionsText={loadingUsers ? "Loading users..." : "No users found"}
//           />

//           {/* Selected Members List */}
//           <Box
//             mt={2}
//             sx={{
//               minHeight: 300,
//               maxHeight: 300,
//               overflowY: "auto",
//               width: "100%",
//               border: "1px solid #ccc",
//               borderRadius: "4px",
//             }}
//           >
//             {selectedMembers.length > 0 ? (
//               selectedMembers.map((user) => (
//                 <Paper
//                   elevation={0}
//                   key={user.id}
//                   sx={{
//                     padding: 1,
//                     margin: 1,
//                     display: "flex",
//                     justifyContent: "space-between",
//                     alignItems: "center",
//                     "&:hover": { backgroundColor: "#f5f5f5" },
//                   }}
//                 >
//                   <Box
//                     sx={{
//                       width: "100%",
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "space-between",
//                       gap: 1,
//                     }}
//                   >
//                     <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                       <Person2Icon fontSize="20" />
//                       <Typography fontSize={13}>{user.name}</Typography>
//                     </Box>
//                     <IconButton
//                       aria-label="delete"
//                       size="small"
//                       onClick={() =>
//                         setSelectedMembers((prev) =>
//                           prev.filter((u) => u.id !== user.id)
//                         )
//                       }
//                     >
//                       <CloseIcon fontSize="inherit" />
//                     </IconButton>
//                   </Box>
//                 </Paper>
//               ))
//             ) : (
//               <Box sx={{ p: 2, textAlign: "center" }}>
//                 <Typography variant="body2" color="text.secondary">
//                   No members selected
//                 </Typography>
//               </Box>
//             )}
//           </Box>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setAddMemberOpen(false)} disabled={addingMembers}>
//             Cancel
//           </Button>
//           <Button
//             onClick={handleAddMembers}
//             variant="contained"
//             disabled={selectedMembers.length === 0 || addingMembers}
//           >
//             {addingMembers ? (
//               <>
//                 <CircularProgress size={18} sx={{ mr: 1 }} />
//                 Adding...
//               </>
//             ) : (
//               "Add"
//             )}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// }

// ----------------- Members -----------------
function Members({ groupId }) {
  const userData =
    JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };

  // --- CHECK FOR APPROVERS SUBSCRIPTION ---
  // Determines if the user has permission to add members
  const isApproverSubscriber = userData.subscribedGroups?.includes('Approvers') || false;
  
  const [searchMemberText, setSearchMemberText] = useState("");
  const [members, setMembers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [dialogMemberSearch, setDialogMemberSearch] = useState("");
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [addingMembers, setAddingMembers] = useState(false);
  const [removingMemberId, setRemovingMemberId] = useState(null);
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;
  const [groupName, setGroupName] = useState(null);

  // Helper flag (used primarily for styling/visibility)
  const isApproversGroup = groupName === 'Approvers';

  // Function to fetch the group name 
  const fetchGroupName = async () => {
        try {
            const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}`);
            if (res.ok) {
                const data = await res.json();
                setGroupName(data.group_name);
            } else {
                console.error("Failed to fetch group name.");
            }
        } catch (err) {
            console.error("Error fetching group name:", err);
        }
    };

  // Fetch members
  const fetchMembers = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/members`
      );
      const data = await res.json();
      const formatted = (Array.isArray(data) ? data : []).map((m) => ({
        id: m.user_id,
        name: m.user_name,
        role: m.user_role,
        approved: m.approved_rules || 0,
        rejected: m.rejected_rules || 0,
      }));
      setMembers(formatted);
    } catch (err) {
      console.error("Error fetching members:", err);
      setMembers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (groupId) {
        fetchMembers();
        fetchGroupName();
    }
  }, [groupId]);

  // Fetch users for Add dialog
  const fetchUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/users`);
      const data = await res.json();
      const formatted = (Array.isArray(data) ? data : []).map((user) => ({
        id: user.user_id,
        name: user.user_name,
      }));
      setAllUsers(formatted);
    } catch (err) {
      console.error("Error fetching users:", err);
      setAllUsers([]);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleAddMemberClick = () => {
    fetchUsers();
    setAddMemberOpen(true);
  };

  // Add members API call (remains unchanged)
  const handleAddMembers = async () => {
    if (selectedMembers.length === 0) return;

    setAddingMembers(true);
    try {
      const user_ids = selectedMembers.map((user) => user.id);

      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_ids }),
        }
      );

      if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
      await res.json();

      await fetchMembers();
      setSelectedMembers([]);
      setAddMemberOpen(false);
    } catch (err) {
      console.error("Error adding members:", err);
      // alert("Failed to add members. Please try again.");
    } finally {
      setAddingMembers(false);
    }
  };

  // Remove member API call (remains unchanged)
  const handleRemoveMember = async (memberId) => {
    // if (!window.confirm("Are you sure you want to remove this member?")) return;

    setRemovingMemberId(memberId);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_ids: [memberId] }),
        }
      );

      if (!res.ok) throw new Error(`Failed: ${res.statusText}`);
      await res.json();

      await fetchMembers();
    } catch (err) {
      console.error("Error removing member:", err);
      // alert("Failed to remove member. Please try again.");
    } finally {
      setRemovingMemberId(null);
    }
  };

  const filteredMembers = members.filter((m) =>
    m.name?.toLowerCase().includes(searchMemberText.toLowerCase())
  );

  const filteredUsers = allUsers.filter(
    (user) =>
      !members.some((m) => m.id === user.id) &&
      user.name.toLowerCase().includes(dialogMemberSearch.toLowerCase())
  );

  const paginatedMembers = filteredMembers.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  const handlePageChange = (event, value) => setPage(value);

  // --- COMBINED DISABILITY CHECK ---
  // The button is disabled if: 
  // 1. User is NOT subscribed to Approvers (Permission check) OR
  // 2. The main member list is loading OR
  // 3. The list of all users for the dialog is loading
  const isButtonDisabled = !isApproverSubscriber || loading || loadingUsers;

  return (
    <Box>
      <Grid container spacing={2}>
        {/* Left Section */}
        <Grid item sx={{ flexGrow: 1 }}>
          <Box
            sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
          >
            <Typography variant="h6">Members</Typography>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Search
                placeholder="Search Member"
                searchTerm={searchMemberText}
                setSearchTerm={setSearchMemberText}
                onSearch={setSearchMemberText}
              />
              {userData.role === "data-engineer" && (
                <Button
                  variant="outlined"
                  color="secondary"
                  size="small"
                  sx={{
                        // Update styles to use the combined disability flag
                        color: isButtonDisabled ? 'text.disabled' : "#29537cff",
                        borderColor: isButtonDisabled ? 'grey.300' : "#29537cff",
                        fontWeight: "bold",
                        "&:hover": {
                            backgroundColor: isButtonDisabled ? 'grey.100' : "#f7f7faff",
                            borderColor: isButtonDisabled ? 'grey.300' : "#102a44ff",
                        },
                    }}
                  onClick={handleAddMemberClick}
                  // Use the combined disability flag
                  disabled={isButtonDisabled}
                >
                  Add Member
                </Button>
              )}
            </Box>
          </Box>
          <hr />

          <Box sx={{ flex: 1, overflowY: "auto", mt: 2, mb: 2 }}>
            {loading ? (
              <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
                <MembersListSkeleton />
              </Box>
            ) : filteredMembers.length === 0 ? (
              <Typography sx={{ textAlign: "center", mt: 2 }}>
                No members found
              </Typography>
            ) : (
              paginatedMembers.map((member) => (
                <Paper key={member.id} elevation={1} sx={{ padding: 1, mb: 1 }}>
                  <Grid container spacing={2} alignItems="center">
                    {/* Avatar + Name */}
                    <Grid item sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
                      <Avatar {...stringAvatar(member.name)} />
                      <Typography>{member.name}</Typography>
                    </Grid>

                    {/* Role */}
                    <Grid item sx={{ width: 150 }}>
                      <Chip
                        label={<Typography fontSize={14}>{member.role}</Typography>}
                        size="small"
                        variant="outlined"
                      />
                    </Grid>
                    {/* Delete Action */}
                    {userData.role === "data-engineer" && (
                      <Grid item sx={{ width: 60, display: "flex", justifyContent: "flex-end" }}>
                        <IconButton
                          aria-label="delete"
                          size="small"
                          onClick={() => handleRemoveMember(member.id)}
                          disabled={removingMemberId === member.id}
                        >
                          {removingMemberId === member.id ? (
                            <CircularProgress size={16} />
                          ) : (
                            <CloseIcon fontSize="inherit" />
                          )}
                        </IconButton>
                      </Grid>
                    )}
                  </Grid>
                </Paper>
              ))
            )}
          </Box>

          {/* Pagination */}
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2, mb: 2 }}>
            <Pagination
              count={Math.ceil(filteredMembers.length / itemsPerPage) || 1}
              page={page}
              onChange={handlePageChange}
            />
          </Box>
        </Grid>

        {/* Right Section (Total Members) */}
        <Grid item sx={{ width: 140 }}>
          <Paper
            elevation={2}
            sx={{
              padding: 2,
              textAlign: "center",
              height: 26,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
          {loading ? (
                <>
                <Skeleton variant="text" width="60%" height={30} />
                <Skeleton variant="text" width="90%" />
                </>
            ) : (
            <>
                <Typography variant="h5">{members.length}</Typography>
                    <Typography>Total Members</Typography>
            </>
          )}
          </Paper>
        </Grid>
      </Grid>

      {/* Add Member Dialog (remains unchanged) */}
      <Dialog
        open={addMemberOpen}
        onClose={() => setAddMemberOpen(false)}
        maxWidth="sm"
        fullWidth
        TransitionComponent={Transition}
      >
        <DialogTitle>Add Member</DialogTitle>
        <DialogContent>
          <Autocomplete
            multiple
            size="small"
            options={filteredUsers}
            getOptionLabel={(option) => option?.name || ""}
            value={selectedMembers}
            onChange={(event, newValue) => setSelectedMembers(newValue)}
            renderInput={(params) => (
              <TextField {...params} placeholder="Search or select users" />
            )}
            noOptionsText={loadingUsers ? "Loading users..." : "No users found"}
          />

          {/* Selected Members List */}
          <Box
            mt={2}
            sx={{
              minHeight: 300,
              maxHeight: 300,
              overflowY: "auto",
              width: "100%",
              border: "1px solid #ccc",
              borderRadius: "4px",
            }}
          >
            {selectedMembers.length > 0 ? (
              selectedMembers.map((user) => (
                <Paper
                  elevation={0}
                  key={user.id}
                  sx={{
                    padding: 1,
                    margin: 1,
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    "&:hover": { backgroundColor: "#f5f5f5" },
                  }}
                >
                  <Box
                    sx={{
                      width: "100%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: 1,
                    }}
                  >
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <Person2Icon fontSize="20" />
                      <Typography fontSize={13}>{user.name}</Typography>
                    </Box>
                    <IconButton
                      aria-label="delete"
                      size="small"
                      onClick={() =>
                        setSelectedMembers((prev) =>
                          prev.filter((u) => u.id !== user.id)
                        )
                      }
                    >
                      <CloseIcon fontSize="inherit" />
                    </IconButton>
                  </Box>
                </Paper>
              ))
            ) : (
              <Box sx={{ p: 2, textAlign: "center" }}>
                <Typography variant="body2" color="text.secondary">
                  No members selected
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddMemberOpen(false)} disabled={addingMembers}>
            Cancel
          </Button>
          <Button
            onClick={handleAddMembers}
            variant="contained"
            disabled={selectedMembers.length === 0 || addingMembers}
          >
            {addingMembers ? (
              <>
                <CircularProgress size={18} sx={{ mr: 1 }} />
                Adding...
              </>
            ) : (
              "Add"
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
// // ----------------- Tables -----------------
// function Tables({ groupId }) {
//   const userData = JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };
//   const [tables, setTables] = useState([]);
//   const [allTables, setAllTables] = useState([]);
//   const [searchText, setSearchText] = useState("");
//   const [dialogSearchText, setDialogSearchText] = useState("");
//   const [loading, setLoading] = useState(true);
//   const [loadingAllTables, setLoadingAllTables] = useState(false);
//   const [open, setOpen] = useState(false);
//   const [selectedTables, setSelectedTables] = useState([]);
//   const [submitting, setSubmitting] = useState(false);
//   const [groupName, setGroupName] = useState(null); 
//   const columns = [
//     { field: "table_name", headerName: "Tables", flex: 1 },
//     { field: "catalog_name", headerName: "Catalog", flex: 1 },
//     { field: "schema_name", headerName: "Schema", flex: 1 },
//   ];
//   const isApproversGroup = groupName === 'Approvers';
//   const fetchGroupName = async () => {
//     try {
//         // Assumes API endpoint /api/groups/:groupId returns a single group object
//         const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}`);
//         if (res.ok) {
//             const data = await res.json();
//             setGroupName(data.group_name);
//         } else {
//             console.error("Failed to fetch group name.");
//         }
//     } catch (err) {
//         console.error("Error fetching group name:", err);
//     }
//     };

//   // Fetch group tables
//   useEffect(() => {
//     const fetchTables = async () => {
//       setLoading(true);
//       try {
//         const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables`);
//         const data = await res.json();
//         const formatted = (Array.isArray(data) ? data : []).map((t) => ({
//           ...t,
//           id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
//         }));
//         setTables(formatted);
//       } catch (err) {
//         console.error("Error fetching tables:", err);
//         setTables([]);
//       } finally {
//         setLoading(false);
//       }
//     };
//     if (groupId) fetchTables(); fetchGroupName(); 
//   }, [groupId]);

//   // Fetch all tables for adding
//   const fetchAllTables = async () => {
//     setLoadingAllTables(true);
//     try {
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/all_tables`);
//       const data = await res.json();
//       const formatted = (Array.isArray(data.tables) ? data.tables : []).map((t) => ({
//         ...t,
//         id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
//       }));
//       setAllTables(formatted);
//     } catch (err) {
//       console.error("Error fetching all tables:", err);
//       setAllTables([]);
//     } finally {
//       setLoadingAllTables(false);
//     }
//   };

//   const handleAddTableClick = () => {
//     setSelectedTables([]);
//     fetchAllTables();
//     setOpen(true);
//   };

//   const handleAddTables = async () => {
//     console.log("Selected IDs before submit:", selectedTables);
//     const newTables = selectedTables
//       .map((id) => allTables.find((t) => t.id === id))
//       .filter(Boolean);
//     console.log("New tables to submit:", newTables);

//     if (newTables.length === 0) {
//       setOpen(false);
//       return;
//     }

//     setSubmitting(true);
//     try {
//       // Call backend API
//       const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables/add`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           tables: newTables.map(({ catalog_name, schema_name, table_name }) => ({
//             catalog_name,
//             schema_name,
//             table_name
//           }))
//         }),
//       });

//       if (!res.ok) throw new Error("Failed to add tables");
//       const result = await res.json();
//       console.log("Add tables response:", result);

//       // Update frontend state
//       const existingTableIds = new Set(tables.map((t) => t.id));
//       const uniqueNewTables = newTables.filter((t) => !existingTableIds.has(t.id));
//       setTables((prev) => [...prev, ...uniqueNewTables]);
//     } catch (err) {
//       console.error("Error adding tables:", err);
//     } finally {
//       setSubmitting(false);
//       setSelectedTables([]);
//       setOpen(false);
//     }
//   };

//   const filteredRows = tables.filter((row) =>
//     Object.values(row).some((val) =>
//       String(val).toLowerCase().includes(searchText.toLowerCase())
//     )
//   );

//   const filteredAllTables = allTables.filter(
//     (t) =>
//       !tables.some((groupTable) => groupTable.id === t.id) &&
//       Object.values(t).some((val) =>
//         String(val).toLowerCase().includes(dialogSearchText.toLowerCase())
//       )
//   );

//   return (
//     <Box>
//       {/* Search + Add Button */}
//       <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
//         <Search
//           placeholder="Search Table"
//           searchTerm={searchText}
//           setSearchTerm={setSearchText}
//           onSearch={setSearchText}
//         />
//         {userData.role === "data-engineer" && (
//           <Button
//             variant="outlined"
//             color="secondary"
//             size="small"
//             sx={{
//                 // 4. STYLE: Styles for disabled state
//                 color: isApproversGroup ? 'text.disabled' : "#29537cff",
//                 borderColor: isApproversGroup ? 'grey.300' : "#29537cff",
//                 fontWeight: "bold",
//                 "&:hover": { 
//                     backgroundColor: isApproversGroup ? 'grey.100' : "#f7f7faff", 
//                     borderColor: isApproversGroup ? 'grey.300' : "#102a44ff" 
//                 },
//             }}
// //             sx={{
// //               color: "#29537cff",
// //               borderColor: "#29537cff",
// //               fontWeight: "bold",
// //               "&:hover": { backgroundColor: "#f7f7faff", borderColor: "#102a44ff" },
// //             }}
//             onClick={handleAddTableClick}
//             disabled={isApproversGroup }
//           >
//             Add Table
//           </Button>
//         )}
//       </Box>

//       {/* Main DataGrid */}

// {/*       {loading ? (
//         <Box sx={{ 
//             display: "flex", 
//             justifyContent: "center", 
//             alignItems: "center", 
//             height: "70vh" 
//         }}>
//         <CircularProgress />
//         </Box>
//       ) : ( */}
//       {loading ? (
//         <TableDataGridSkeleton /> // <-- NEW SKELETON
//       ) : (
//         <DataGrid
//           sx={{
//             height: "70vh",
//             border: "none",
//             "& .MuiDataGrid-row:hover": { backgroundColor: "#f7f7faff" },
//             "& .MuiDataGrid-columnHeaders": { backgroundColor: "#000000", height: 40 },
//           }}
//           rows={filteredRows || []}
//           columns={columns}
//           getRowId={(row) => row.id || Math.random()}
//           disableRowSelectionOnClick
//           pagination
//           initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
//           pageSizeOptions={[10, 20]}
//         />
//       )}

//       {/* Add Tables Dialog */}
//       <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
//         <DialogTitle>Add Tables</DialogTitle>
//         <DialogContent>
//           <Search
//             placeholder="Search Tables"
//             searchTerm={dialogSearchText}
//             setSearchTerm={setDialogSearchText}
//             onSearch={setDialogSearchText}
//           />
// {/*           {loadingAllTables ? (
//             <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
//               <CircularProgress />
//             </Box>
//           ) : ( */}
//           {loadingAllTables ? (
//             <Box sx={{ minHeight: "70vh" }}>
//               <TableDataGridSkeleton /> {/* <-- USE THE TABLE SKELETON HERE */}
//             </Box>
//           ) : (
//             <DataGrid
//               sx={{ height: "70vh", border: "none", mt: 2 }}
//               rows={filteredAllTables}
//               columns={columns}
//               getRowId={(row) => `${row.catalog_name}-${row.schema_name}-${row.table_name}`}
//               checkboxSelection
//               disableRowSelectionOnClick
//               //rowSelectionModel={selectedTables} // <- controlled
//               onRowSelectionModelChange={(selectionModel) => {
//                 // If it's an object with ids, convert Set -> Array
//                 const ids = selectionModel?.ids
//                   ? Array.from(selectionModel.ids)
//                   : Array.isArray(selectionModel)
//                     ? selectionModel
//                     : [];

//                 console.log("Clean IDs:", ids);
//                 setSelectedTables(ids);
//               }}
//               initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
//               pageSizeOptions={[10, 20]}
//             />
//           )}
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => {
//             setOpen(false);
//             setSelectedTables([]);
//           }}>
//             Cancel
//           </Button>
//           <Button
//             onClick={handleAddTables}
//             variant="contained"
//             disabled={selectedTables.length === 0 || submitting}
//           >
//             {submitting ? "Submitting..." : "Submit"}
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// }
// ----------------- Tables -----------------
function Tables({ groupId }) {
    const userData = JSON.parse(sessionStorage.getItem("userData")) || { role: "data-engineer" };
    
    // --- NEW LOGIC: Check for Approvers subscription ---
    const isApproverSubscriber = userData.subscribedGroups?.includes('Approvers') || false;
    // --- END NEW LOGIC ---

    const [tables, setTables] = useState([]);
    const [allTables, setAllTables] = useState([]);
    const [searchText, setSearchText] = useState("");
    const [dialogSearchText, setDialogSearchText] = useState("");
    const [loading, setLoading] = useState(true);
    const [loadingAllTables, setLoadingAllTables] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedTables, setSelectedTables] = useState([]);
    const [submitting, setSubmitting] = useState(false);
    const [groupName, setGroupName] = useState(null); 
    
    const columns = [
        { field: "table_name", headerName: "Tables", flex: 1 },
        { field: "catalog_name", headerName: "Catalog", flex: 1 },
        { field: "schema_name", headerName: "Schema", flex: 1 },
    ];
    
    const isApproversGroup = groupName === 'Approvers';
    
    const fetchGroupName = async () => {
        // ... (fetchGroupName logic remains unchanged) ...
        try {
            const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}`);
            if (res.ok) {
                const data = await res.json();
                setGroupName(data.group_name);
            } else {
                console.error("Failed to fetch group name.");
            }
        } catch (err) {
            console.error("Error fetching group name:", err);
        }
    };

    // Fetch group tables
    useEffect(() => {
        const fetchTables = async () => {
            setLoading(true);
            try {
                const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables`);
                const data = await res.json();
                const formatted = (Array.isArray(data) ? data : []).map((t) => ({
                    ...t,
                    id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
                }));
                setTables(formatted);
            } catch (err) {
                console.error("Error fetching tables:", err);
                setTables([]);
            } finally {
                setLoading(false);
            }
        };
        if (groupId) {
             fetchTables(); 
             fetchGroupName(); 
        }
    }, [groupId]);

    // Fetch all tables for adding
    const fetchAllTables = async () => {
        setLoadingAllTables(true);
        try {
            const res = await fetch(`${import.meta.env.VITE_API_URL}/api/all_tables`);
            const data = await res.json();
            const formatted = (Array.isArray(data.tables) ? data.tables : []).map((t) => ({
                ...t,
                id: `${t.catalog_name}-${t.schema_name}-${t.table_name}`,
            }));
            setAllTables(formatted);
        } catch (err) {
            console.error("Error fetching all tables:", err);
            setAllTables([]);
        } finally {
            setLoadingAllTables(false);
        }
    };

    const handleAddTableClick = () => {
        setSelectedTables([]);
        fetchAllTables();
        setOpen(true);
    };

    const handleAddTables = async () => {
        // ... (handleAddTables logic remains unchanged) ...
        console.log("Selected IDs before submit:", selectedTables);
        const newTables = selectedTables
            .map((id) => allTables.find((t) => t.id === id))
            .filter(Boolean);
        console.log("New tables to submit:", newTables);

        if (newTables.length === 0) {
            setOpen(false);
            return;
        }

        setSubmitting(true);
        try {
            // Call backend API
            const res = await fetch(`${import.meta.env.VITE_API_URL}/api/groups/${groupId}/tables/add`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    tables: newTables.map(({ catalog_name, schema_name, table_name }) => ({
                        catalog_name,
                        schema_name,
                        table_name
                    }))
                }),
            });

            if (!res.ok) throw new Error("Failed to add tables");
            const result = await res.json();
            console.log("Add tables response:", result);

            // Update frontend state
            const existingTableIds = new Set(tables.map((t) => t.id));
            const uniqueNewTables = newTables.filter((t) => !existingTableIds.has(t.id));
            setTables((prev) => [...prev, ...uniqueNewTables]);
        } catch (err) {
            console.error("Error adding tables:", err);
        } finally {
            setSubmitting(false);
            setSelectedTables([]);
            setOpen(false);
        }
    };

    const filteredRows = tables.filter((row) =>
        Object.values(row).some((val) =>
            String(val).toLowerCase().includes(searchText.toLowerCase())
        )
    );

    const filteredAllTables = allTables.filter(
        (t) =>
            !tables.some((groupTable) => groupTable.id === t.id) &&
            Object.values(t).some((val) =>
                String(val).toLowerCase().includes(dialogSearchText.toLowerCase())
            )
    );

    // Final combined disability check
    const isButtonDisabled = !isApproverSubscriber || loading || loadingAllTables;


    return (
        <Box>
            {/* Search + Add Button */}
            <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
                <Search
                    placeholder="Search Table"
                    searchTerm={searchText}
                    setSearchTerm={setSearchText}
                    onSearch={setSearchText}
                />
                {userData.role === "data-engineer" && (
                    <Button
                        variant="outlined"
                        color="secondary"
                        size="small"
                        sx={{
                            // 1. STYLE: Apply disabled styling when the combined check is true
                            color: isButtonDisabled ? 'text.disabled' : "#29537cff",
                            borderColor: isButtonDisabled ? 'grey.300' : "#29537cff",
                            fontWeight: "bold",
                            "&:hover": { 
                                backgroundColor: isButtonDisabled ? 'grey.100' : "#f7f7faff", 
                                borderColor: isButtonDisabled ? 'grey.300' : "#102a44ff" 
                            },
                        }}
                        onClick={handleAddTableClick}
                        // 2. LOGIC: Use the combined disability check
                        disabled={isButtonDisabled}
                    >
                        Add Table
                    </Button>
                )}
            </Box>

            {/* Main DataGrid ... (remains unchanged) */}
            {loading ? (
                <TableDataGridSkeleton />
            ) : (
                <DataGrid
                    sx={{
                        height: "70vh",
                        border: "none",
                        "& .MuiDataGrid-row:hover": { backgroundColor: "#f7f7faff" },
                        "& .MuiDataGrid-columnHeaders": { backgroundColor: "#000000", height: 40 },
                    }}
                    rows={filteredRows || []}
                    columns={columns}
                    getRowId={(row) => row.id || Math.random()}
                    disableRowSelectionOnClick
                    pagination
                    initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
                    pageSizeOptions={[10, 20]}
                />
            )}

            {/* Add Tables Dialog ... (remains unchanged) */}
             <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
                <DialogTitle>Add Tables</DialogTitle>
                <DialogContent>
                    <Search
                        placeholder="Search Tables"
                        searchTerm={dialogSearchText}
                        setSearchTerm={setDialogSearchText}
                        onSearch={setDialogSearchText}
                    />
                    {loadingAllTables ? (
                        <Box sx={{ minHeight: "70vh" }}>
                            <TableDataGridSkeleton /> 
                        </Box>
                    ) : (
                        <DataGrid
                            sx={{ height: "70vh", border: "none", mt: 2 }}
                            rows={filteredAllTables}
                            columns={columns}
                            getRowId={(row) => `${row.catalog_name}-${row.schema_name}-${row.table_name}`}
                            checkboxSelection
                            disableRowSelectionOnClick
                            onRowSelectionModelChange={(selectionModel) => {
                                const ids = selectionModel?.ids
                                    ? Array.from(selectionModel.ids)
                                    : Array.isArray(selectionModel)
                                        ? selectionModel
                                        : [];

                                console.log("Clean IDs:", ids);
                                setSelectedTables(ids);
                            }}
                            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
                            pageSizeOptions={[10, 20]}
                        />
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => {
                        setOpen(false);
                        setSelectedTables([]);
                    }}>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleAddTables}
                        variant="contained"
                        disabled={selectedTables.length === 0 || submitting}
                    >
                        {submitting ? "Submitting..." : "Submit"}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
}
const formatGroupName = (name) => {
  if (!name) return "";
  // Replaces hyphens with spaces and capitalizes each word
  return name
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

function GroupDetail() {
  const [value, setValue] = useState(0);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [groupDetails, setGroupDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const { groupId } = useParams();
  const location = useLocation();
  const navigate = useNavigate(); // Initialize useNavigate
  const [searchParams] = useSearchParams();
  const { groupName: nameFromState } = location.state || {};
  const formattedName = formatGroupName(nameFromState);
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'members') {
      setValue(1);
    } else {
      // Default to 'tables' (index 0) if param is 'tables', null, or invalid
      setValue(0);
    }
  }, [searchParams]);
//   useEffect(() => {
//     const tabParam = searchParams.get('tab');
//     if (tabParam === 'tables') {
//       setValue(0);
//     } else if (tabParam === 'members') {
//       setValue(1);
//     }
//   }, [searchParams]); // Re-run effect when search params change

  const userData = JSON.parse(sessionStorage.getItem("userData")) || {
    role: "data-engineer",
    userId: "mock_user_id"
  };
  const userId = userData.userId;
  const isApproversGroup = groupDetails?.group_name === 'Approvers';
  const isUserSubscribed = groupDetails?.subscription_status === true; // true or false
  // Function to fetch group details
  const fetchGroupDetails = async () => {
    setLoading(true);
    setError(null);
    try {
      const url = new URL(`${import.meta.env.VITE_API_URL}/api/groups`, window.location.origin);
      url.searchParams.append('user_id', userId);

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error('Failed to fetch group details.');
      }

      const data = await response.json();
      const groupData = data.find(group => group.group_id === groupId);

      if (!groupData) {
        throw new Error("Group not found.");
      }

      setGroupDetails({
        ...groupData,
        subscription_status: groupData.subscription_status === 'true'
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroupDetails();
  }, [groupId, userId]);

  // Handler for dynamic subscribe/unsubscribe button
  const handleSubscriptionChange = async () => {
    if (!userId) {
      console.error("User not authenticated. Cannot perform action.");
      return;
    }

    setIsProcessing(true);
    const endpoint = groupDetails.subscription_status
      ? `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/remove_members`
      : `${import.meta.env.VITE_API_URL}/api/groups/${groupId}/add_members`;

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_ids: [userId] }),
      });

      if (!res.ok) {
        throw new Error(`Failed to update subscription: ${res.statusText}`);
      }

      console.log("Subscription status updated. Re-fetching group details...");
      await fetchGroupDetails();
    } catch (err) {
      console.error("Error updating subscription:", err);
    } finally {
      setIsProcessing(false);
    }
  };
  const isApproverSubscriber = userData.subscribedGroups?.includes('Approvers') || false;

  const disableSubscriptionButton = 
    isProcessing || 
    !userId || 
    (isApproversGroup && !isUserSubscribed);
   const disableDelete = 
    deleting || 
    !isApproverSubscriber;
    // (isApproversGroup && !isUserSubscribed);

  const handleDeleteGroup = async () => {
    setDeleting(true);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_API_URL}/api/groups/${groupId}`,
        {
          method: "DELETE",
        }
      );
      if (!res.ok) throw new Error("Failed to delete group");

      console.log("Group deleted");
      // 👉 redirect or refresh depending on your flow
      window.location.href = "/groups";
    } catch (err) {
      console.error("Error deleting group:", err);
    } finally {
      setDeleting(false);
      setDeleteDialogOpen(false);
    }
  };

//   if (loading) {
//     return (
//       <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '70vh' }}>
//         <CircularProgress />
//       </Box>
//     );
//   }
// NEW CODE for GroupDetail loading state
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 2 }}>
            {/* Header Skeleton: Breadcrumbs, Buttons */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
                <Skeleton variant="text" width="20%" />
                <Box sx={{ display: "flex", gap: 1 }}>
                    <Skeleton variant="rectangular" width={100} height={30} />
                    {userData.role === "data-engineer" && <Skeleton variant="rectangular" width={120} height={30} />}
                </Box>
            </Box>
            {/* Header Skeleton: Title */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, my: 2 }}>
                <Skeleton variant="circular" width={32} height={32} />
                <Skeleton variant="text" width="30%" height={36} />
            </Box>

            {/* Tabs Skeleton */}
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <Box sx={{ display: 'flex', gap: 4 }}>
                    <Skeleton variant="text" width={80} height={48} />
                    <Skeleton variant="text" width={80} height={48} />
                </Box>
            </Box>

            {/* Content Area Skeleton (Use Tables skeleton by default) */}
            <Box sx={{ mt: 2 }}>
                <TableDataGridSkeleton />
            </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Typography color="error" sx={{ textAlign: 'center', mt: 4 }}>
        Error: {error}
      </Typography>
    );
  }
  return (
    <Box>
      <Container maxWidth="lg">
        <Box
          sx={{
            mt: 2,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "flex-start",
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
            <Typography sx={{ color: 'grey.600' }}>
              <Box component="span" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }} onClick={() => navigate('/groups')}>
                Groups
              </Box>
              <span> / {formattedName || groupDetails?.group_name || groupId}</span>
            </Typography>
            
            <Box sx={{ display: "flex", gap: 1 }}>
              <Button
                size="small"
                color={groupDetails.subscription_status ? "error" : "success"}
                onClick={handleSubscriptionChange}
                disabled={disableSubscriptionButton} 

//                 disabled={isProcessing || !userId}
              >
                {isProcessing ? (
                  <CircularProgress size={18} sx={{ mr: 1 }} />
                ) : (
                  groupDetails.subscription_status ? 'Unsubscribe' : 'Subscribe'
                )}
              </Button>
              {userData.role === "data-engineer" && (
                <Button
                  size="small"
                  variant="contained"
                  color="error"
                  onClick={() => setDeleteDialogOpen(true)}
                  disabled={disableDelete}
//                   disabled={deleting}
                >
                  Delete Group
                </Button>
              )}
            </Box>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
            <GroupIcon sx={{fontSize: '2rem', color: '#1a75c2' }} />
            <Typography variant="h6">
              
              {formattedName || groupDetails?.group_name || groupId}
            </Typography>
          </Box>
        </Box>

        {/* Tabs + Content */}
{/*         <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs value={value} onChange={(e, newValue) => setValue(newValue)}>
            <Tab label="Tables" {...a11yProps(0)} />
            <Tab label="Members" {...a11yProps(1)} />
          </Tabs>
        </Box> */}
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs 
            value={value} 
            onChange={(e, newValue) => {
              setValue(newValue); // Update local state for immediate UI change
              
              // Determine the new URL parameter value
              const tabParam = newValue === 1 ? 'members' : 'tables';
              
              // Update the URL using react-router's navigate
              navigate(`?tab=${tabParam}`, { replace: true });
            }}
          >
            <Tab label="Tables" {...a11yProps(0)} />
            <Tab label="Members" {...a11yProps(1)} />
          </Tabs>
        </Box>
        <CustomTabPanel value={value} index={0}>
          <Tables groupId={groupId} />
        </CustomTabPanel>
        <CustomTabPanel value={value} index={1}>
          <Members groupId={groupId} />
        </CustomTabPanel>
      </Container>

      {/* Delete Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => !deleting && setDeleteDialogOpen(false)}
      >
        <DialogTitle>Delete Group</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this group? This action cannot be
            undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDeleteDialogOpen(false)}
            disabled={deleting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDeleteGroup}
            color="error"
            variant="contained"
            disabled={deleting}
          >
            {deleting ? (
              <>
                <CircularProgress size={18} sx={{ mr: 1 }} /> Deleting...
              </>
            ) : (
              "Delete"
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
export default GroupDetail;