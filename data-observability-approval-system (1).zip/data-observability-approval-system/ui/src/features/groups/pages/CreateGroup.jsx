import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import { DataGrid } from '@mui/x-data-grid';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Autocomplete from '@mui/material/Autocomplete';
import Button from '@mui/material/Button';
import { useState, useEffect, useMemo } from 'react';
import Person2Icon from '@mui/icons-material/Person2';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from 'react-router-dom';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';

const columns = [
    { field: 'catalog_name', headerName: 'Catalog', flex: 1 },
    { field: 'schema_name', headerName: 'Schema', flex: 1 },
    { field: 'table_name', headerName: 'Tables', flex: 1 },
    { field: 'Groups', headerName: 'Groups', flex: 1 },
];

const paginationModel = { page: 0, pageSize: 5 };

function CreateGroup() {
    const [groupName, setGroupName] = useState('');
    const [users, setUsers] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [tableRows, setTableRows] = useState([]);
    const [selectedTableRows, setSelectedTableRows] = useState([]);
    const [allUsers, setAllUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');
    const [submitting, setSubmitting] = useState(false);
    const [searchTableText, setSearchTableText] = useState('');


    const navigate = useNavigate();

    const cancelCreateGroup = () => {
        navigate('/groups');
    };

    const removeUser = (userObj) => {
        setUsers(prevUsers => prevUsers.filter(user => user.id !== userObj.id));
    };

    const handleSnackbarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackbarOpen(false);
    };

    const handleCreateGroup = async () => {
        setSubmitting(true);
        const ownerData = JSON.parse(sessionStorage.getItem('userData'));
        if (!groupName) {
            setSnackbarMessage('Group Name is required.');
            setSnackbarSeverity('error');
            setSnackbarOpen(true);
            setSubmitting(false);
            return;
        }
        console.log(selectedTableRows)

        const payload = {
            group_name: groupName,
            owner_name: ownerData.name,
            tables: Array.from(selectedTableRows.ids),
            user_ids: users.map(user => user.id)
        };

        try {
            const response = await fetch(`${import.meta.env.VITE_API_URL}/api/create_group`, {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                setSnackbarMessage('Group created successfully!');
                setSnackbarSeverity('success');
                setSnackbarOpen(true);
                setGroupName('');
                setUsers([]);
                setSelectedTableRows([]);
                setTimeout(() => {
                    window.location.href = "/groups";
                }, 2000);
            } else {
                const errorData = await response.json();
                setSnackbarMessage(`Failed to create group: ${errorData.message || response.statusText}`);
                setSnackbarSeverity('error');
                setSnackbarOpen(true);
            }
        } catch (e) {
            setSnackbarMessage(`An error occurred: ${e.message}`);
            setSnackbarSeverity('error');
            setSnackbarOpen(true);
        } finally {
            setSubmitting(false);
        }
    };

    useEffect(() => {
        const fetchTableData = async () => {
            try {
                const response = await fetch(`${import.meta.env.VITE_API_URL}/api/all_tables`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                const formattedRows = data.tables.map((row) => ({
                    id: `${row.catalog_name}-${row.schema_name}-${row.table_name}`,
                    ...row,
                }));
                setTableRows(formattedRows);
            } catch (e) {
                console.error("Failed to fetch table data:", e);
                setError("Failed to load tables. Please try again later.");
            } finally {
                setLoading(false);
            }
        };

        const fetchUserData = async () => {
            try {
                const response = await fetch(`${import.meta.env.VITE_API_URL}/api/users`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                const formattedUsers = data.map(user => ({
                    id: user.user_id,
                    name: user.user_name,
                }));
                setAllUsers(formattedUsers);
            } catch (e) {
                console.error("Failed to fetch user data:", e);
                setError("Failed to load users. Please try again later.");
            }
        };

        fetchTableData();
        fetchUserData();
    }, []);

    const filteredTableRows = useMemo(() => {
        if (!searchTableText) {
            return tableRows;
        }
        return tableRows.filter(row =>
            Object.values(row).some(value =>
                String(value).toLowerCase().includes(searchTableText.toLowerCase())
            )
        );
    }, [tableRows, searchTableText]);

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <Typography color="error">{error}</Typography>
            </Box>
        );
    }



    return (
        <Box>
            <Container maxWidth="lg">
                <Box sx={{ mt: 2, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 1 }}>
                    <Typography variant="h5">Create Group</Typography>
                </Box>
                <hr />
                <Grid container spacing={2} sx={{ mt: 2, mb: 2 }}>
                    <Grid size={8}>
                        <Box>
                            <TextField
                                size='small'
                                fullWidth
                                id="outlined-basic"
                                label="Group Name"
                                variant="outlined"
                                value={groupName}
                                onChange={(e) => setGroupName(e.target.value)}
                            />
                        </Box>
                    </Grid>
                    <Grid size={4}>
                        <Box>
                            <TextField size='small' disabled defaultValue={JSON.parse(sessionStorage.getItem('userData'))['name']} fullWidth id="outlined-basic" label="Owner" variant="outlined" />
                        </Box>
                    </Grid>
                    <Grid size={8} sx={{ mt: 1, mb: 1 }}>
                        <Box >
                            <Typography variant="h6">Add Table</Typography>
                        </Box>
                        <Box sx={{ mt: 1, mb: 2 }}>
                            <TextField fullWidth id="outlined-basic" size='small' placeholder="Search Table" variant="outlined"  value={searchTableText} onChange={(e) => setSearchTableText(e.target.value)} />
                        </Box>
                        <Box sx={{ mt: 1, mb: 2, height: 400, width: '100%' }}>
                            <DataGrid
                                rows={filteredTableRows}
                                columns={columns}
                                getRowId={(row) => `${row.catalog_name}-${row.schema_name}-${row.table_name}`}
                                initialState={{ pagination: { paginationModel } }}
                                pageSizeOptions={[5, 10]}
                                checkboxSelection
                                sx={{ border: 0 }}
                                // rowSelectionModel={selectedTableRows}
                                //rowSelectionModel={selectedTableRows || []}
                                onRowSelectionModelChange={(selectionModel) => {
                                    setSelectedTableRows(selectionModel);
                                }}

                            />
                        </Box>
                    </Grid>
                    <Grid size={4} sx={{ mt: 1, mb: 1 }}>
                        <Box display="flex" justifyContent="start" width="100%" gap={1}>
                            <Typography margin={0} variant="h6">Add Users</Typography>
                            <Typography alignSelf={"end"} mb={0.5} variant="caption">(Optional)</Typography>
                        </Box>
                        <Box mt={1}>
                            <Autocomplete
                                size='small'
                                getOptionLabel={(option) => option.name}
                                inputValue={inputValue}
                                value={null}
                                onChange={(event, newValue) => {
                                    setUsers(prevUsers => {
                                        if (!newValue) return prevUsers;
                                        const exists = prevUsers.some(user => user.id === newValue.id);
                                        if (exists) return prevUsers;
                                        return [...prevUsers, newValue];
                                    });
                                    setInputValue('');
                                }}
                                options={allUsers}
                                onInputChange={(event, newInputValue, reason) => {
                                    if (reason !== 'reset') {
                                        setInputValue(newInputValue);
                                    }
                                }}
                                getOptionDisabled={(option) => {
                                    const isSelected = users.some(user => user.id === option.id);
                                    return isSelected;
                                }}
                                renderInput={(params) => <TextField {...params} placeholder='Users' />}
                            />
                        </Box>
                        <Box mt={2} sx={{ minHeight: 400, maxHeight: 400, width: '100%', border: '1px solid #ccc', borderRadius: '4px' }}>
                            {users.length > 0 ?
                                <Box>
                                    {users.map((user, index) => (
                                        <Paper elevation={0} key={index} sx={{ padding: 1, margin: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center', '&:hover': { backgroundColor: '#f5f5f5' } }}>
                                            <Box sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1 }}>
                                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                    <Person2Icon fontSize='20' />
                                                    <Typography fontSize={13}>{user.name}</Typography>
                                                </Box>
                                                <Box>
                                                    <IconButton aria-label="delete" size="small" onClick={() => removeUser(user)}>
                                                        <CloseIcon fontSize="inherit" />
                                                    </IconButton>
                                                </Box>
                                            </Box>
                                        </Paper>
                                    ))}
                                </Box> :
                                <Box sx={{ minHeight: 'inherit', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <Typography>No users added yet</Typography>
                                </Box>
                            }
                        </Box>
                    </Grid>
                </Grid>
                <Snackbar
                    open={snackbarOpen}
                    autoHideDuration={6000}
                    onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                >
                    <MuiAlert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
                        {snackbarMessage}
                    </MuiAlert>
                </Snackbar>
                <Box sx={{ display: 'flex', justifyContent: 'end', gap: 2, mt: 2, mb: 4 }}>
                    <Button variant="outlined" sx={{ borderColor: '#5a5f64ff', color: '#5a5f64ff' }} size='medium' onClick={cancelCreateGroup}>Cancel</Button>
                    <Button
                        variant="contained"
                        sx={{ backgroundColor: submitting ? '#a9a9a9' : '#233e58' }}
                        size='medium'
                        onClick={handleCreateGroup}
                        disabled={submitting}
                    >
                        {/* {submitting ? <CircularProgress size={24} color="inherit" /> : 'Create'} */}
                        {submitting ? (
                            <>
                                <CircularProgress size={20} color="inherit" sx={{ mr: 1 }} />
                                Creating...
                            </>
                        ) : (
                            'Create'
                        )}
                    </Button>
                </Box>
            </Container>
        </Box>
    );
}

export default CreateGroup;