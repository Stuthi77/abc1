import React, { useState, useRef, useEffect } from "react";

// ✅ Multi-select dropdown component
const MultiSelectDropdown = ({ placeholder, options, selected, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleOptionClick = (value) => {
    const newSelected = selected.includes(value)
      ? selected.filter(item => item !== value)
      : [...selected, value];
    onChange(newSelected);
  };

  const getDisplayText = () => {
    if (selected.length === 0) return placeholder;
    if (selected.length === 1) return selected[0];
    return `${selected.length} selected`;
  };

  // Styles
  const inputStyle = {
    padding: "8px 12px",
    border: "1px solid #d1d5db",
    borderRadius: "6px",
    fontSize: "14px",
    backgroundColor: "white",
    height: "36px",
    boxSizing: "border-box",
    flex: "1",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    minWidth: "200px",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  };

  const dropdownMenuStyle = {
    position: "absolute",
    top: "100%",
    left: 0,
    right: 0,
    backgroundColor: "white",
    border: "1px solid #d1d5db",
    borderRadius: "6px",
    marginTop: "2px",
    maxHeight: "200px",
    overflowY: "auto",
    zIndex: 1000,
    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
  };

  const optionStyle = {
    display: "flex",
    alignItems: "center",
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: "14px",
    borderBottom: "1px solid #f3f4f6",
  };

  return (
    <div style={{ position: "relative", flex: "1" }} ref={dropdownRef}>
      <div onClick={() => setIsOpen(!isOpen)} style={inputStyle}>
        <span
          style={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {getDisplayText()}
        </span>
        <span
          style={{
            marginLeft: "8px",
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s",
          }}
        >
          ▼
        </span>
      </div>

      {isOpen && (
        <div style={dropdownMenuStyle}>
          {options.map((option) => (
            <label
              key={option}
              style={optionStyle}
              className="dropdown-option"
            >
              <input
                type="checkbox"
                checked={selected.includes(option)}
                onChange={() => handleOptionClick(option)}
                style={{ marginRight: "8px" }}
              />
              {option}
            </label>
          ))}
        </div>
      )}
    </div>
  );
};

// ✅ Filter component
const ApprovalsFilter = ({ filters, onFilterChange, onClearFilters }) => {
  const [filterOptions, setFilterOptions] = useState({
    schema: [],
    table: [],
    user: [],
    status: [],
  });
  const [loadingOptions, setLoadingOptions] = useState(true);

  // Fetch filter options
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        console.log("Running effect Approval filters 1");
        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/approval-filters`);
        if (!response.ok) throw new Error("Failed to fetch filter options");
        const data = await response.json();
        setFilterOptions(data);
      } catch (error) {
        console.error("Error fetching filter options:", error);
      } finally {
        setLoadingOptions(false);
      }
    };
    fetchOptions();
  }, []);

  if (loadingOptions) {
    return <div style={{ minWidth: "200px", textAlign: "center" }}>Loading filters...</div>;
  }

  const buttonStyle = {
    padding: "8px 16px",
    backgroundColor: "#6b7280",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "500",
    minWidth: "80px",
  };

  return (
    <>
      <MultiSelectDropdown
        placeholder="Schema"
        options={filterOptions.schema || []}
        selected={filters.selectedSchema}
        onChange={(values) => onFilterChange("selectedSchema", values)}
      />
      <MultiSelectDropdown
        placeholder="Table"
        options={filterOptions.table || []}
        selected={filters.selectedTables}
        onChange={(values) => onFilterChange("selectedTables", values)}
      />
      <MultiSelectDropdown
        placeholder="User"
        options={filterOptions.user || []}
        selected={filters.selectedOwner}
        onChange={(values) => onFilterChange("selectedOwner", values)}
      />
      <MultiSelectDropdown
        placeholder="Status"
        options={filterOptions.status || []}
        selected={filters.selectedStatus}
        onChange={(values) => onFilterChange("selectedStatus", values)}
      />
      <button onClick={onClearFilters} style={buttonStyle}>
        Clear All
      </button>
    </>
  );
};

export default ApprovalsFilter;
