// D:\Zeba_Workspace\data-observability-approval-system\ui\src\features\Shared\Components\Search\Search-Feature.jsx
import React from "react";
import { TextField, InputAdornment } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const Search = ({
  onSearch,
  searchTerm,
  setSearchTerm,
  placeholder = "Search",
  width = 300,
  inputSx,
}) => {
  const handleChange = (e) => {
    const value = e.target.value;
    if (setSearchTerm) setSearchTerm(value);     
    if (onSearch) onSearch(value);               
  };

  return (
    <TextField
      size="small"
      placeholder={placeholder}
      value={searchTerm}
      onChange={handleChange}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon />
          </InputAdornment>
        ),
      }}
      sx={{
        width,
        backgroundColor: "#fff",
        "& .MuiOutlinedInput-root": {
          fontSize: "14px",
          fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
          height: 33, 
        },
        ...inputSx,
      }}
    />
  );
};

export default Search;
