// // components/Pagination.js
import React from 'react';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';

const MuiPagination = ({ currentPage, totalPages, onPageChange }) => {
  const handleChange = (event, value) => {
    onPageChange(value);
  };

  return (
    <Stack spacing={2} alignItems="center" marginTop={2} marginBottom={2}>
      <Pagination
        count={totalPages}     // e.g., 3
        page={currentPage}     // 2
        onChange={handleChange}
        color="primary"
        siblingCount={0}       // removes extra page numbers
        boundaryCount={0}      // removes first/last numbers
      />
    </Stack>
  );
};

export default MuiPagination;
