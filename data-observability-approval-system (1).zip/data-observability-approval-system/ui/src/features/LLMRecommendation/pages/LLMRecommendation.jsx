import React, { useState, useEffect } from "react";
// #import "./LLMRecommendation.css"; // Optional: Create this if you need custom page styling

const LLMRecommendation = () => {
  const [catalogs, setCatalogs] = useState([]);
  const [schemas, setSchemas] = useState([]);
  const [tables, setTables] = useState([]);

  const [selectedCatalog, setSelectedCatalog] = useState("");
  const [selectedSchema, setSelectedSchema] = useState("");
  const [selectedTable, setSelectedTable] = useState("");

  const [rules, setRules] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // 1. Fetch Catalogs on mount
  useEffect(() => {
    fetch("/api/llm-meta/catalogs")
      .then((res) => res.json())
      .then((data) => setCatalogs(data))
      .catch((err) => console.error("Failed to load catalogs", err));
  }, []);

  // 2. Fetch Schemas when Catalog changes
  // 1. Fetch Catalogs on mount
  useEffect(() => {
    fetch("/api/llm-meta/catalogs")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setCatalogs(data);
        } else {
          setError(data.error || "Failed to load catalogs.");
        }
      })
      .catch((err) => setError("Network error loading catalogs."));
  }, []);

  // 2. Fetch Schemas when Catalog changes
  useEffect(() => {
    setSelectedSchema("");
    setSelectedTable("");
    setSchemas([]);
    if (selectedCatalog) {
      fetch(`/api/llm-meta/schemas?catalog=${selectedCatalog}`)
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data)) setSchemas(data);
        })
        .catch((err) => console.error(err));
    }
  }, [selectedCatalog]);

  // 3. Fetch Tables when Schema changes
  useEffect(() => {
    setSelectedTable("");
    setTables([]);
    if (selectedCatalog && selectedSchema) {
      fetch(`/api/llm-meta/tables?catalog=${selectedCatalog}&schema=${selectedSchema}`)
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data)) setTables(data);
        })
        .catch((err) => console.error(err));
    }
  }, [selectedCatalog, selectedSchema]);

  // 4. Handle "Generate" button click
  const handleGenerate = async () => {
    setIsLoading(true);
    setError(null);
    setRules([]);

    try {
      const response = await fetch("/api/rules/recommend-direct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          catalog: selectedCatalog,
          schema: selectedSchema,
          table: selectedTable,
        }),
      });

      const data = await response.json();

      if (data.results) {
        setRules(data.results);
      } else {
        setError(data.error || "No recommendations generated.");
      }
    } catch (err) {
      setError("Failed to communicate with the AI engine.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="main-content" style={{ padding: "30px", width: "100%" }}>
      <h2 style={{ marginBottom: "20px", color: "#1e293b" }}>
        Generate AI Recommendations
      </h2>

      <div
        className="card"
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "8px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
        }}
      >
        <div style={{ display: "flex", gap: "16px", marginBottom: "24px", alignItems: "flex-end" }}>
          <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
            <label style={{ marginBottom: "8px", fontSize: "14px", color: "#64748b" }}>Catalog *</label>
            <select
              value={selectedCatalog}
              onChange={(e) => setSelectedCatalog(e.target.value)}
              style={{ padding: "10px", borderRadius: "4px", border: "1px solid #cbd5e1" }}
            >
              <option value="">Select Catalog</option>
              {catalogs.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
            <label style={{ marginBottom: "8px", fontSize: "14px", color: "#64748b" }}>Schema *</label>
            <select
              value={selectedSchema}
              onChange={(e) => setSelectedSchema(e.target.value)}
              disabled={!selectedCatalog}
              style={{ padding: "10px", borderRadius: "4px", border: "1px solid #cbd5e1" }}
            >
              <option value="">Select Schema</option>
              {schemas.map((sch) => (
                <option key={sch} value={sch}>{sch}</option>
              ))}
            </select>
          </div>

          <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
            <label style={{ marginBottom: "8px", fontSize: "14px", color: "#64748b" }}>Table *</label>
            <select
              value={selectedTable}
              onChange={(e) => setSelectedTable(e.target.value)}
              disabled={!selectedSchema}
              style={{ padding: "10px", borderRadius: "4px", border: "1px solid #cbd5e1" }}
            >
              <option value="">Select Table</option>
              {tables.map((tbl) => (
                <option key={tbl} value={tbl}>{tbl}</option>
              ))}
            </select>
          </div>

          <button
            onClick={handleGenerate}
            disabled={!selectedTable || isLoading}
            style={{
              padding: "10px 24px",
              height: "41px",
              background: !selectedTable || isLoading ? "#94a3b8" : "#0284c7",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: !selectedTable || isLoading ? "not-allowed" : "pointer",
              fontWeight: "bold",
            }}
          >
            {isLoading ? "Generating..." : "Generate"}
          </button>
        </div>

        {isLoading && <div style={{ color: "#0284c7", marginTop: "10px" }}>⏳ Profiling target table and communicating with LLM...</div>}
        {error && <div style={{ color: "red", marginTop: "10px" }}>{error}</div>}

        {rules.length > 0 && (
          <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
            <thead>
              <tr style={{ background: "#f8fafc", textAlign: "left" }}>
                <th style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>Column</th>
                <th style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>Rule Description</th>
                <th style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>Category</th>
                <th style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>Condition Type</th>
                <th style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>Severity</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((rule, index) => (
                <tr key={index}>
                  <td style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}><b>{rule.column_name}</b></td>
                  <td style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>{rule.rule_description}</td>
                  <td style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>{rule.condition_category}</td>
                  <td style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}><code>{rule.condition_type}</code></td>
                  <td style={{ padding: "12px", borderBottom: "1px solid #e2e8f0" }}>{rule.severity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default LLMRecommendation;