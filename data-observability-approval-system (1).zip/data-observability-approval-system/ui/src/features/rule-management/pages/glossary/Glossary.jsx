import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Divider,
  Box,
  Typography,
  TextField,
  Grid,
  Button
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import GlossaryTable from "../../components/glossary-table/GlossaryTable";
import Filter from '../../../Shared/Components/Filters/Filters';

const Glossary = ({ open, onClose }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedTypes, setSelectedTypes] = useState([]);

  const [openFilter, setOpenFilter] = useState(null);

  const conditionCategories = [
    "Completeness Rules",
    "Format & Pattern Validation",
    "Range & Threshold Rules",
    "Uniqueness & Duplicate Checks",
    "Business Logic Rules",
    "Consistency & Standardization Checks",
    "Anomaly Detection",
    "Time-based Validations",
    "Trend Analysis",
    "KPI Statistics"
  ];

  const conditionTypes = [
    "NOT_NULL",
    "BLANK",
    "MUST_HAVE_VALUE",
    "NOT_NULL_LENGTH_CHECK",
    "REGEX_MATCH",
    "LENGTH_CHECK",
    "FORMAT_CHECK",
    "RANGE_CHECK",
    "VALUE_THRESHOLD",
    "DATE_RANGE",
    "UNIQUE",
    "DUPLICATE",
    "CUSTOM_RULE",
    "CASE_STANDARDIZATION",
    "MAPPING_CHECK",
    "OUTLIER_DETECTION",
    "TIME_STAMP_CHECK",
    "ROW_COUNT_TREND",
    "KPI_CHECK"
  ];

  const toggleCategory = (option) => {
    setSelectedCategories((prev) =>
      prev.includes(option) ? prev.filter((o) => o !== option) : [...prev, option]
    );
  };

  const toggleType = (option) => {
    setSelectedTypes((prev) =>
      prev.includes(option) ? prev.filter((o) => o !== option) : [...prev, option]
    );
  };

  const clearAllFilters = () => {
    setSelectedCategories([]);
    setSelectedTypes([]);
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
      <DialogTitle
        sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
      >
        <Typography variant="h6" sx={{ fontFamily: "'Segoe UI', sans-serif" }}>
          Glossary
        </Typography>
        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <Divider />
      <DialogContent>
        {/* Search + Filters Row */}
        <Box mb={2}>
          <Grid container pl={1} spacing={2} alignItems="center">
            <Grid size xs={12} md={6}>
              <TextField
                label="Search"
                variant="outlined"
                size="small"
                fullWidth
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                sx={{ fontSize: "0.75rem", height: 32 }}
              />
            </Grid>

            <Grid size xs={12} md={3} pt={0.30}>

              <Filter
                  label="Condition Category"
                  options={conditionCategories}
                  selectedOptions={selectedCategories}
                  onToggleOption={toggleCategory}
                  isOpen={openFilter === "Condition Category"}
                  onToggleOpen={() =>
                    setOpenFilter(openFilter === "Condition Category" ? null : "Condition Category")
                  }
                  onClose={() => setOpenFilter(false)}
                  />
                              </Grid>

            <Grid size xs={12} md={3} pt={0.30}>
<Filter
  label="Condition Type"
  options={conditionTypes}
  selectedOptions={selectedTypes}
  onToggleOption={toggleType}
  isOpen={openFilter === "Condition Type"}
  onToggleOpen={() =>
    setOpenFilter(openFilter === "Condition Type" ? null : "Condition Type")
  }
   onClose={() => setOpenFilter(false)}
/>

            </Grid>

            <Grid size xs={12} md={3} pt={0.30}>
              <Button
                style={{
                  textTransform: 'none', 
                  minWidth: '83px',
                  backgroundColor: 'white',
                  color: 'rgb(53, 53, 53)',
                  border: '1px solid rgba(0, 0, 0, 0.23)',
                  fontWeight: 400,
                  justifyContent: 'center',
                  padding: '6px 12px',
                  cursor: 'pointer',
                  borderRadius: '4px',
                  height: 35,
                }}

                onMouseOver={(e) => {
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.backgroundColor = 'rgb(97, 97, 97)';
                }}

                onMouseOut={(e) => {
                  e.currentTarget.style.color = 'rgb(53, 53, 53)';
                  e.currentTarget.style.backgroundColor = 'white';
                }}

                onClick={clearAllFilters}
                disabled={selectedCategories.length === 0 && selectedTypes.length === 0}
              >
                Reset
              </Button>

            </Grid>

          </Grid>
        </Box>

        {/* Table */}
        <Box p={1}>
          <GlossaryTable
            searchTerm={searchTerm}
            categories={selectedCategories}
            types={selectedTypes}
          />
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default Glossary;
