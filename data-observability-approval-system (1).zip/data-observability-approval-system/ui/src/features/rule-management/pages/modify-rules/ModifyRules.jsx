import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  TextField,
  Grid,
  CircularProgress
} from "@mui/material";
import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';




const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});


const ModifyRules = ({ open, rule, allColumns, onClose, onSave, columnsLoading })=> {
  const [editedRule, setEditedRule] = React.useState(rule || {});
  const [saving, setSaving] = React.useState(false);
  const [snackbarOpen, setSnackbarOpen] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState('success');


  React.useEffect(() => {
    if (rule) {
      setEditedRule({
        ...rule,
        rule_id: rule.rule_id || rule.Rule_id || rule.id, // handle naming mismatch
        columns: rule.column_name ? rule.column_name.split(", ") : [],
    });
  }
}, [rule]);

  const handleChange = (field, value) => {
    setEditedRule({ ...editedRule, [field]: value });
  };

  const handleSnackbarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackbarOpen(false);
    };

const handleSave = async () => {
  if (!editedRule || !editedRule.rule_id) { return; }

  const criteriaToSave = JSON.parse(JSON.stringify(editedRule.conditionCriteria || {}));

  for (const key in criteriaToSave) {
    const value = Number(criteriaToSave[key]);
    if (!isNaN(value)) {
      console.log(`Wrapping '${key}' with value ${value} in a special placeholder.`);
      criteriaToSave[key] = `__NUMBER__${value}__`; 
    }
  }

  const payload = {
    column_name: (editedRule.columns || []).join(", "),
    rule_description: editedRule.description || "",
    severity: editedRule.severity,
    violation_threshold: editedRule.violationThreshold,
    condition_criteria: criteriaToSave,
  };
  
  console.log("Hacked payload being sent:", payload);

  setSaving(true);
  try {
    const response = await fetch(`${import.meta.env.VITE_API_URL}/api/rules/${editedRule.rule_id}/save_request`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (response.ok) {
      onSave();
      onClose();
    } else {
      console.error("Failed to save:", result.error);
    }
  } catch (error) {
    console.error("An error occurred during save:", error);
  } finally {
    setSaving(false);
  }
};

  return (


<Box p={1}>
<Dialog
  open={open}
  onClose={onClose}
  maxWidth={false}
  sx={{
    "& .MuiDialog-paper": {
      width: "355px",  
      maxWidth: "90%",  
    },
  }}
>
      <DialogTitle>Edit Rule - {editedRule.conditionType}</DialogTitle>
      <DialogContent dividers>
        <Box display="flex" flexDirection="column" gap={2}>
          {/* Columns */}


          <Box>


          <FormControl fullWidth size="small">
            <InputLabel>Columns</InputLabel>
            <Select
              multiple
              value={editedRule.columns || []}
              onChange={(e) => handleChange("columns", e.target.value)}
              input={<OutlinedInput label="Columns" />}
              renderValue={(selected) => selected.join(", ")}
              disabled={columnsLoading}
            >
              {columnsLoading ? (
                <MenuItem disabled>Loading columns...</MenuItem>
              ) : (
                allColumns.map((col) => (
                  <MenuItem key={col} value={col}>
                    <Checkbox checked={editedRule.columns?.includes(col)} />
                    <ListItemText primary={col} />
                  </MenuItem>
                ))
              )}
            </Select>
          </FormControl>
         
          </Box>


          <Box>
          <textarea
            value={editedRule.description || ""}
            onChange={(e) => handleChange("description", e.target.value)}
            placeholder="Enter Rule description"
            rows={4}
            style={{
              width: '100%',
              padding: '10px 14px',
              fontSize: '0.85rem',
              borderRadius: '4px',
              border: '1px solid rgba(0, 0, 0, 0.23)',
              backgroundColor: '#fff',
              fontFamily: 'Segeo-UI, Helvetica, Arial, sans-serif',
              boxSizing: 'border-box',
              transition: 'border-color 0.2s, box-shadow 0.2s',
              outline: 'none',
              resize: 'none',
              lineHeight: 1.2,
            }}
            onFocus={(e) => {
              e.target.style.border = '1px solid #1976d2';
              e.target.style.boxShadow = '0 0 0 1px #1976d2';
            }}
            onBlur={(e) => {
              e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
              e.target.style.boxShadow = 'none';
            }}
          />
        </Box>


          {/* Condition Parameters (Dynamic Fields) */}
          <DynamicConditionFields
            category={editedRule.conditionCategory}
            type={editedRule.conditionType}
            columns={editedRule.columns}
            onCriteriaChange={(updated) => handleChange("conditionCriteria", updated)}
          />


    <Grid container spacing={2} mt={1} justifyContent={"space-between"}>


        <Grid size={{ xs: 12, md: 6 }} justifyContent={"space-between"}>
            <Box>
          {/* Severity */}
          <FormControl size="small" sx={{width: 145}}>
            <InputLabel>Severity</InputLabel>
            <Select
              value={editedRule.severity || ""}
              onChange={(e) => handleChange("severity", e.target.value)}
              label="Severity"
            >
              <MenuItem value="Warning">Warning</MenuItem>
              <MenuItem value="Critical">Critical</MenuItem>
            </Select>
          </FormControl>
                         
            </Box>
        </Grid>


        <Grid size={{ xs: 12, md: 6 }} justifyContent={"space-between"}>
        <Box>
          {/* Threshold */}
          <TextField
            label="Violation Threshold (%)"
            type="number"
            size="small"
            value={editedRule.violationThreshold || ""}
            onChange={(e) => handleChange("violationThreshold", e.target.value)}
            sx={{width: 145}}
          />
          </Box>
          </Grid>
          </Grid>
          </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="inherit" disabled={saving}>
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          variant="contained"
          color="primary"
          disabled={saving}
        >
          {saving ? <CircularProgress size={20} /> : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
    <Snackbar
      open={snackbarOpen}
      autoHideDuration={3000}
      onClose={() => setSnackbarOpen(false)}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
    >
      <Alert
        onClose={() => setSnackbarOpen(false)}
        severity={snackbarSeverity}
        sx={{ width: '100%' }}
      >
        {snackbarMessage}
      </Alert>
    </Snackbar>
    </Box>
   
  );
};


export default ModifyRules;

