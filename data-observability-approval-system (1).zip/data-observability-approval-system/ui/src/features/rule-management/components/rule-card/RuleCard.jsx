import React, { useState, useMemo, useEffect } from 'react';
import {
  Box,
  Card,
  Chip,
  CardContent,
  Typography,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Button,
  Collapse,
  CircularProgress,
  Tooltip
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import CloseIcon from '@mui/icons-material/Close';
import { DataGrid } from '@mui/x-data-grid';
import { useNavigate } from 'react-router-dom';
import TableChartIcon from '@mui/icons-material/TableChart';
import { ruleManagementApi } from "../../../../services/ruleManagementApi";




const MAX_CHAR = 40;
const MAX_COLUMN_CHAR = 100;


const FONT_STACK = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";


const CARD_SX = {
  width: '100%',
  boxShadow: 4,
  borderRadius: 2,
  transition: 'box-shadow 0.3s ease',
  '&:hover': { boxShadow: 3 },
  overflow: 'visible',
};


const CARD_CONTENT_SX = {
  padding: '8px 16px 12px 16px',
  '&:last-child': { paddingBottom: '12px' },
  m: 0,
  '&>*:first-of-type': { marginTop: 0 },
};


const TITLE_SX = {
  fontFamily: FONT_STACK,
  letterSpacing: 1.2,
  lineHeight: 1.2,
  color: '#1e3a8a',
  m: 0,
  p: 0,
};


const severityColors = {
  Critical: '#d32f2f',
  Warning: '#f57c00',
  Info: '#1976d2',
  Low: '#388e3c',
};


const renderStatusChip = (status) =>
  status === 'Approved' ? (
    <Chip
      icon={<CheckCircleIcon />}
      label="Approved"
      color="success"
      variant="outlined"
      sx={{ fontWeight: 'bold' }}
    />
  ) : (
    <Chip
      icon={<HourglassEmptyIcon />}
      label="Yet to Approve"
      sx={{
        bgcolor: '#fff3cd',
        color: '#856404',
        fontWeight: 'bold',
        border: '1px solid #ffeeba',
      }}
    />
  );




// const transformApiData = (apiRules) => {
//   return apiRules.map((rule) => ({
//     ruleName: rule.Rule_name || '',
//     columnName: rule.Column_name || '',
//     description: rule.Rule_description || '',
//     severity: rule.Severity || '',
//     effectiveDate: '2025-08-01',
//     status: 'Approved',
//     conditionCategory: rule.Condition_category || '',
//     conditionType: rule.Condition_type || '',
//     conditionCriteria: rule.Condition_criteria ? JSON.stringify(rule.Condition_criteria) : 'null',
//   }));
// };


const transformApiData = (apiRules) => {
  return apiRules.map((rule) => ({
    ruleName: (rule.Rule_name || '').trim(),
    columnName: (rule.Column_name || '').trim(),
    description: (rule.Rule_description || '').trim(),
    severity: (rule.Severity || '').trim(),
    effectiveDate: '2025-08-01',
    status: 'Approved',
    conditionCategory: (rule.Condition_category || '').trim(),
    conditionType: (rule.Condition_type || '').trim(),
    // conditionCriteria: rule.Condition_criteria || 'null',
    conditionCriteria: rule.Condition_criteria || rule.condition_criteria || "",

  }));
};


const ExpandableCell = ({ text, maxLength = MAX_CHAR }) => {
  if (!text || text.length <= maxLength) return text || '';

  return (
    <Tooltip title={text} arrow placement="bottom">
      <span style={{ cursor: 'pointer' }}>
        {text.slice(0, maxLength)}...
      </span>
    </Tooltip>
  );
};


const createGridColumns = () => [
  {
    field: 'columnName',
    headerName: 'Column Name',
    flex: 1,
    sortable: true,
    headerClassName: 'bold-header',
    renderCell: (params) => (
      <Tooltip title={params.value || ''} arrow placement="bottom">
        <span style={{ cursor: 'pointer' }}>{params.value || ''}</span>
      </Tooltip>
    ),
  },
  {
    field: 'conditionCriteria',
    headerName: 'Condition Criteria',
    flex: 1.5,
    sortable: false,
    headerClassName: 'bold-header',
    renderCell: (params) => {
      const val = params.value ?? '';
      return (
        <Tooltip title={val} arrow placement="bottom">
          <div
            style={{
              width: '100%',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              cursor: 'pointer'
            }}
          >
            {val}
          </div>
        </Tooltip>
      );
    },
  },
  {
    field: 'conditionType',
    headerName: 'Condition Type',
    flex: 1,
    sortable: true,
    headerClassName: 'bold-header',
    renderCell: (params) => (
      <Tooltip title={params.value || ''} arrow placement="bottom">
        <span style={{ cursor: 'pointer' }}>{params.value || ''}</span>
      </Tooltip>
    ),
  },
  {
    field: 'description',
    headerName: 'Description',
    flex: 2,
    sortable: false,
    headerClassName: 'bold-header',
    renderCell: (params) => {
      const val = params.value ?? '';
      return (
        <Tooltip title={val} arrow placement="bottom">
          <div
            style={{
              width: '100%',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              cursor: 'pointer'
            }}
          >
            {val}
          </div>
        </Tooltip>
      );
    },
  },
  {
    field: 'severity',
    headerName: 'Severity',
    flex: 0.7,
    sortable: true,
    headerClassName: 'bold-header',
    renderCell: (params) => {
      const color = severityColors[params.value] || '#616161';
      return (
        <Tooltip title={params.value} arrow placement="bottom">
          <Chip
            label={params.value}
            variant="outlined"
            sx={{
              color,
              borderColor: color,
              backgroundColor: 'transparent',
              fontWeight: 'bold',
              width: '100%',
              textAlign: 'center',
              cursor: 'pointer',
            }}
          />
        </Tooltip>
      );
    },
  }
];


const Stat = ({ value, label, onClick }) => (
  <Box
    sx={{
      minWidth: 96,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      lineHeight: 1.1,
      fontFamily: FONT_STACK,
      cursor: onClick ? 'pointer' : 'default',
      '&:hover': onClick ? {
        backgroundColor: '#f5f5f5',
        borderRadius: '4px',
      } : {},
      transition: 'background-color 0.2s ease',
      padding: '4px 8px',
      margin: '-4px -8px',
    }}
    onClick={onClick}
  >
    <Typography sx={{ 
      fontSize: '1.1rem', 
      fontWeight: 700, 
      color: '#1976d2', 
      m: 0,
      '&:hover': onClick ? {
        textDecoration: 'underline',
      } : {},
    }}>
      {value}
    </Typography>
    <Typography sx={{ fontSize: '0.8rem', color: '#555', m: 0, whiteSpace: 'nowrap' }}>
      {label}
    </Typography>
  </Box>
);


const RuleDetailsGrid = ({ ruleDetails }) => {
  const rows = ruleDetails.map((rule, idx) => ({ id: idx, ...rule }));
  const columns = useMemo(() => createGridColumns(), []);
  return (
    <div style={{ width: '100%', height: 400 }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
        disableRowSelectionOnClick
        autoHeight={false}
        // sx={{
        //   borderRadius: 1,
        //   fontSize: '13px',
        //   fontFamily: FONT_STACK,
        //   border: '1px solid #eee',
        //   '& .MuiDataGrid-cell': { py: 1, borderBottom: '1px solid #eee' },
        //   '& .bold-header': {
        //     fontWeight: 700,
        //     fontFamily: FONT_STACK,
        //     backgroundColor: '#f8f9fa',
        //     borderBottom: '2px solid #dee2e6',
        //     fontSize: '13px',
        //   },
        //   '& .MuiDataGrid-row:hover': { backgroundColor: '#f8f9fa' },
        // }}
        sx={{
          borderRadius: 1,
          fontSize: '13px',
          fontFamily: FONT_STACK,
          border: '1px solid #eee',
          '& .MuiDataGrid-cell': { 
            py: 1, 
            borderBottom: '1px solid #eee',
            display: 'flex',
            alignItems: 'center'
          },
          '& .bold-header': {
            fontWeight: 700,
            fontFamily: FONT_STACK,
            backgroundColor: '#f8f9fa',
            borderBottom: '2px solid #dee2e6',
            fontSize: '13px',
            display: 'flex',
            alignItems: 'center'
          },
          '& .MuiDataGrid-row:hover': { backgroundColor: '#f8f9fa' },
        }}

      />
    </div>
  );
};




const RuleCard = ({
  rulesData = [],
  onViewApprovedRules,
  expandedTableId,
  approvedRulesData = {},
  loadingApprovedRules = {}
}) => {
  const [searchTerms, setSearchTerms] = useState({});
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogTable, setDialogTable] = useState(null);
  const [processingTables, setProcessingTables] = useState(new Set());
  const [severityFilters, setSeverityFilters] = useState({});
  const [severityOptions, setSeverityOptions] = useState({});


  const navigate = useNavigate();


  const handleSearchChange = (tableId, value) => {
    setSearchTerms((prev) => ({ ...prev, [tableId]: value }));
  };


  const handleSeverityChange = (tableId, severity) => {
    setSeverityFilters(prev => ({ ...prev, [tableId]: severity }));
  };


  const filterRules = (rules, searchTerm, severityFilter) => {
    let filtered = rules;

    if (searchTerm?.trim()) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter((rule) =>
        Object.values(rule).some(
          (val) => typeof val === 'string' && val.toLowerCase().includes(search)
        )
      );
    }

    if (severityFilter && severityFilter !== '') {
      filtered = filtered.filter((rule) => rule.severity === severityFilter);
    }

    return filtered;
  };


  const handleOpenDialog = (table) => {
    setDialogTable(table);
    setOpenDialog(true);
  };


  const handleCloseDialog = () => {
    setOpenDialog(false);
    setDialogTable(null);
  };



  const handleApprovedRulesClick = async (tableId) => {

    if (expandedTableId === tableId) {
      if (onViewApprovedRules) {
        onViewApprovedRules(tableId);
      }
      return;
    }

    if (processingTables.has(tableId)) {
      console.log('Already processing table:', tableId);
      return;
    }


    setProcessingTables(prev => new Set([...prev, tableId]));

    if (onViewApprovedRules) {
      await onViewApprovedRules(tableId);


    //   if (!severityOptions[tableId]) {
    //     try {
    //       const filters = await ruleManagementApi.getTableFilters(tableId);
    //       setSeverityOptions(prev => ({
    //         ...prev,
    //         [tableId]: filters.severity || []
    //       }));
    //     } catch (error) {
    //       console.error('Failed to fetch severity options:', error);
    //       setSeverityOptions(prev => ({
    //         ...prev,
    //         [tableId]: ['Warning', 'Critical']
    //       }));
    //     }
    //   }
    // }

    if (!severityOptions[tableId]) {
      try {
        const filters = await ruleManagementApi.getTableFilters(tableId);
        setSeverityOptions(prev => ({
          ...prev,
          [tableId]: (filters?.severity || []).filter(v => ["Warning", "Critical"].includes(v)).length
            ? (filters?.severity || []).filter(v => ["Warning", "Critical"].includes(v))
            : ["Warning", "Critical"]
        }));
      } catch (error) {
        console.error('Failed to fetch severity options:', error);
        setSeverityOptions(prev => ({
          ...prev,
          [tableId]: ["Warning", "Critical"]
        }));
      }
    }
  }


    setProcessingTables(prev => {
      const newSet = new Set(prev);
      newSet.delete(tableId);
      return newSet;
    });
  };


  // const handleApprovedRulesClick = async (tableId) => {
  //   if (processingTables.has(tableId)) {
  //     console.log('Already processing table:', tableId);
  //     return;
  //   }


  //   setProcessingTables(prev => new Set([...prev, tableId]));

  //   // Make both API calls in parallel
  //   const promises = [];

  //   if (onViewApprovedRules) {
  //     promises.push(onViewApprovedRules(tableId));
  //   }

  //   promises.push(
  //     ruleManagementApi.getTableFilters(tableId)
  //       .then(filters => {
  //         console.log('API severity options:', filters.severity);
  //         console.log('Using options:', filters.severity || ['Warning', 'Critical']);
  //         setSeverityOptions(prev => ({
  //           ...prev,
  //           [tableId]: filters.severity || ['Warning', 'Critical']
  //         }));
  //       })
  //       .catch(error => {
  //         console.error('Failed to fetch severity options:', error);
  //         setSeverityOptions(prev => ({
  //           ...prev,
  //           [tableId]: ['Warning', 'Critical']
  //         }));
  //       })
  //   );

  //   // Wait for both to complete
  //   await Promise.all(promises);


  //   setTimeout(() => {
  //     setProcessingTables(prev => {
  //       const newSet = new Set(prev);
  //       newSet.delete(tableId);
  //       return newSet;
  //     });
  //   }, 1000);
  // };



  if (!rulesData || rulesData.length === 0) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Typography variant="h6" color="textSecondary">
          No tables found
        </Typography>
      </Box>
    );
  }


  return (
    <>
      <Box display="flex" flexDirection="column" gap={1} sx={{ width: '100%' }}>

        {rulesData.map((tableData) => {
          console.log('🔍 Table data structure:', JSON.stringify(tableData, null, 2));
          // const tableId = tableData.id;
          // const tableId = tableData.table_name;
          //Hard-coding the tableId as http://127.0.0.1:5000/api/tables/103/approved_rules api doesnt return tableId
          const tableId = `${tableData.catalog_name}-${tableData.schema_name}-${tableData.table_name}`;
          const tableName = tableData.table_name || tableData.name || `Table ${tableId}`;
          const schemaName = `${tableData.catalog_name}.${tableData.schema_name}`;




          const approvedRules = approvedRulesData[tableId] || [];
          const transformedRules = transformApiData(approvedRules);
          const filteredRules = filterRules(transformedRules, searchTerms[tableId], severityFilters[tableId]);


          const tableColumns = tableData.columns
            ? (typeof tableData.columns === 'string'
              ? tableData.columns.split(', ').map(col => col.trim())
              : tableData.columns)
            : tableData.column_names || [];
          const isLoading = loadingApprovedRules[tableId] || false;


          return (
            <Card key={tableId} sx={{ ...CARD_SX }}>
              <CardContent sx={{ ...CARD_CONTENT_SX, position: 'relative' }}>

                <Box
                  sx={{
                    position: 'relative',
                    display: 'block',
                    pr: { xs: 0, sm: '200px' },
                    pb: 1,
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <TableChartIcon sx={{ color: '#1e3a8a70' }} />
                    <Typography
                      variant="h6"
                      sx={{ ...TITLE_SX, cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                      onClick={() => {

                        console.log('Navigate to table details:', tableId);
                        navigate(`/rule-management/table/${tableId}`, {
                          state: {
                            tableName,
                            schemaName: `${tableData.catalog_name}.${tableData.schema_name}`,
                            catalogName: tableData.catalog_name
                          }
                        });
                      }}
                      role="button"
                      tabIndex={0}
                      className="table-name"
                    >
                      {tableName}
                    </Typography>
                  </Box>


                  <Typography
                    variant="body2"
                    sx={{ fontFamily: FONT_STACK, color: 'text.primary', mb: 0.5 }}
                  >
                    <span style={{ color: '#555', fontWeight: 'normal', fontSize: 12 }}>{schemaName}</span>
                  </Typography>


                  <Typography
                    variant="body2"
                    sx={{
                      color: '#333',
                      m: 0,
                      mb: '8px',
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-word',
                      fontFamily: FONT_STACK,
                    }}
                  >
                    <strong>Columns:</strong>{' '}
                    {Array.isArray(tableColumns) && tableColumns.length > 0 ? (
                      tableColumns.join(', ').length > 100 ? (
                        <Tooltip title={tableColumns.join(', ')} arrow placement="bottom">
                          <span style={{ cursor: 'pointer' }}>
                            {tableColumns.join(', ').slice(0, 100)}...
                          </span>
                        </Tooltip>
                      ) : (
                        tableColumns.join(', ')
                      )
                    ) : (
                      'N/A'
                    )}
                  </Typography>



                  <Button
                    size="small"
                    disableRipple
                    disableFocusRipple
                    onClick={() => handleApprovedRulesClick(tableId)}
                    sx={{
                      textTransform: 'none',
                      p: 0,
                      minWidth: 0,
                      color: '#1976d2',
                      fontFamily: FONT_STACK,
                      fontSize: '0.9rem',
                      '&:hover': { textDecoration: 'underline', backgroundColor: 'transparent' },
                    }}
                  >
                    {expandedTableId === tableId ? 'Hide Approved Rules' : 'View Approved Rules'}
                  </Button>



                  <Box
                    sx={{
                      position: { xs: 'static', sm: 'absolute' },
                      right: { sm: 16 },
                      top: { sm: '50%' },
                      transform: { sm: 'translateY(-50%)' },
                      display: 'flex',
                      alignItems: 'center',
                      gap: 2,
                      ml: { xs: 'auto', sm: 0 },
                      zIndex: 2,
                    }}
                  >
                    <Stat value={tableData.rules_count} label="Rules" onClick={() => handleApprovedRulesClick(tableId)} />
                    <Stat value={tableData.column_count} label="Columns" />
                  </Box>
                </Box>


                <Collapse in={expandedTableId === tableId} timeout="auto" unmountOnExit>
                  <Box
                    sx={{
                      mt: 1,
                      p: '16px',
                      borderTop: '1px solid #eee',
                      backgroundColor: '#fafafa',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '16px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <TextField
                      size="small"
                      placeholder="Search"
                      value={searchTerms[tableId] ?? ''}
                      onChange={(e) => handleSearchChange(tableId, e.target.value)}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SearchIcon />
                          </InputAdornment>
                        ),
                      }}
                      sx={{
                        width: '200px',
                        backgroundColor: '#fff',
                        '& .MuiOutlinedInput-root': {
                          fontSize: '14px',
                          fontFamily: FONT_STACK,
                        },
                      }}
                    />


                    <TextField
                      size="small"
                      select
                      label=""
                      value={severityFilters[tableId] ?? ''}
                      onChange={(e) => handleSeverityChange(tableId, e.target.value)}
                      SelectProps={{ native: true }}
                      sx={{
                        width: '120px',
                        backgroundColor: '#fff',
                        '& .MuiOutlinedInput-root': {
                          fontSize: '14px',
                          fontFamily: FONT_STACK,
                        },
                      }}
                    >
                      <option value="">All Severity</option>
                      {(severityOptions[tableId] || []).map(severity => (
                        <option key={severity} value={severity}>{severity}</option>
                      ))}
                    </TextField>


                    <Button
                      size="small"
                      onClick={() => {
                        handleSearchChange(tableId, '');
                        handleSeverityChange(tableId, '');
                      }}
                      sx={{
                        textTransform: 'none',
                        minWidth: '70px',
                        fontWeight: 400,
                        padding: '6px 12px',
                        borderRadius: '4px',
                        height: '32px',
                        border: '1px solid rgba(0, 0, 0, 0.23)',
                        backgroundColor: '#e0e0e0',
                        color: '#333',
                        fontSize: '14px',
                        fontFamily: FONT_STACK,
                        '&:hover': {
                          backgroundColor: '#616161',
                          color: '#fff',
                        },
                      }}
                    >
                      Clear All
                    </Button>
                  </Box>


                  <Box sx={{ p: '16px' }}>
                    {filteredRules.length > 0 ? (
                      <RuleDetailsGrid ruleDetails={filteredRules} />
                    ) : (
                      <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'center', py: 2 }}>
                        Loading...
                      </Typography>
                    )}
                  </Box>
                </Collapse>
              </CardContent>
            </Card>
          );
        })}
      </Box>
    </>
  );
};


export default RuleCard