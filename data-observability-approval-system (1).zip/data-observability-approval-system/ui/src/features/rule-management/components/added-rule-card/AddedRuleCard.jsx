import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Stack,
  IconButton,
  Tooltip
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import EditIcon from '@mui/icons-material/Edit';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import MailOffIcon from '@mui/icons-material/MailLock';
import DeleteIcon from '@mui/icons-material/Delete';

const statusBorderColors = {
  Approved: '#4caf50',
  'Yet to Approve': '#ffb300',
  Pending: '#f39c12',
  Failed: '#c0392b',
};

const severityColors = {
  Critical: '#f57c00',
  Warning: '#fdd835',
  High: '#e53935',
  Medium: '#fb8c00',
  Low: '#43a047'
};

const renderStatusChip = (status) => {
  if (status === 'Approved') {
    return (
      <Chip
        icon={<CheckCircleIcon fontSize="small" />}
        label="Approved"
        color="success"
        variant="outlined"
        size="small"
        sx={{ fontWeight: 'bold' }}
      />
    );
  } else if (status === 'Yet to Approve') {
    return (
      <Chip
        icon={<HourglassEmptyIcon fontSize="small" />}
        label="Yet to Approve"
        size="small"
        sx={{
          bgcolor: '#fff3cd',
          color: '#856404',
          fontWeight: 'bold',
          border: '1px solid #ffeeba',
        }}
      />
    );
  }
  return (
    <Chip
      label={status}
      variant="outlined"
      size="small"
      sx={{ fontWeight: 'bold' }}
    />
  );
};

const AddedRuleCard = ({ rule, ruleNumber, onEdit, onDelete }) => {
  const {
    table,
    ruleDescription,
    catalog,
    conditionType,
    severity,
    columns,
    status = 'Pending', 
    ruleName = `Rule_${ruleNumber}`,
    effectiveDate = '2025-08-01',
  } = rule;

  return (
    <Card
      sx={{
        width: '100%',
        mb: 2,
        boxShadow: 3,
        borderRadius: 2,
        transition: 'box-shadow 0.3s ease',
        '&:hover': {
          boxShadow: 6,
        },
      }}
    >
      <CardContent sx={{ padding: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="start">
          <Box>
            <Typography
              variant="h6"
              component="div"
              gutterBottom
              sx={{ fontWeight: 600, fontSize: '1rem', letterSpacing: 0.5 }}
            >
              Rule {ruleNumber}: {table?.toUpperCase()}
              {rule?.source === "llm_generated" && (
                <Chip
                  label="LLM Generated"
                  size="small"
                  color="secondary"
                  variant="outlined"
                  sx={{ ml: 1, fontWeight: 500, verticalAlign: 'middle' }}
                />
              )}
            </Typography>

            <Stack direction="row" spacing={1} mb={1} alignItems="center" flexWrap="wrap">
              <Chip
                label={ruleName}
                color="primary"
                variant="outlined"
                size="small"
                sx={{ fontWeight: 'bold' }}
              />
              <Chip
                label={severity}
                size="small"
                sx={{
                  bgcolor: severityColors[severity] || '#ccc',
                  color: '#000',
                  fontWeight: 'bold',
                }}
              />
              {renderStatusChip(status)}
              <Chip
                label={rule?.enforcementAction === "AUDIT_ONLY" ? "Audit only" : "Filter & audit"}
                size="small"
                variant="outlined"
                sx={{ fontWeight: 500 }}
              />
              <Chip
                icon={rule?.emailAlertEnabled === false ? <MailOffIcon fontSize="small" /> : <MailOutlineIcon fontSize="small" />}
                label={rule?.emailAlertEnabled === false ? "Alert off" : "Alert on"}
                size="small"
                variant="outlined"
                sx={{ fontWeight: 500 }}
              />
            </Stack>

            <Typography variant="body2" sx={{ mb: 0.5 }}>
              <strong>Description: </strong>{ruleDescription}
            </Typography>

            <Typography variant="caption" color="text.secondary" display="block">
              <strong>Catalog:</strong> {catalog} &nbsp; | &nbsp;
              <strong>Condition:</strong> {conditionType}
            </Typography>

            <Typography variant="caption" color="text.secondary" display="block">
              <strong>Columns:</strong> {columns?.join(', ') || 'N/A'}
            </Typography>

            <Typography variant="caption" color="text.secondary">
              <strong>Effective From:</strong> {effectiveDate}
            </Typography>
          </Box>

          <Stack direction="row" spacing={1}>
            <Tooltip title="Edit Rule">
              <IconButton color="primary" onClick={onEdit}>
                <EditIcon />
              </IconButton>
            </Tooltip>

            <Tooltip title="Delete Rule">
              <IconButton color="error" onClick={onDelete}>
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Stack>
        </Box>
      </CardContent>
    </Card>
  );
};

export default AddedRuleCard;
