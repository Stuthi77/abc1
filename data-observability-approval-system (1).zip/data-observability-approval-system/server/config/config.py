# server/config/config.py
#
# All secrets come from environment variables.
# - Locally: put them in server/.env (never commit it) or export them in the shell.
# - In Databricks Apps: define them in app.yaml under `env:` (ideally valueFrom a secret).
import os

try:
    # optional: load server/.env when running locally
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))
except ImportError:
    pass

DATABRICKS_HOST = os.getenv("DATABRICKS_HOST", "https://adb-7769428536383727.7.azuredatabricks.net").rstrip("/")
DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN", "dapi95880d2add949cd2eac9a16c7fa28f49-2")
SQL_WAREHOUSE_ID = os.getenv("SQL_WAREHOUSE_ID", "c46555dff4f199bb")

if not all([DATABRICKS_HOST, DATABRICKS_TOKEN, SQL_WAREHOUSE_ID]):
    print("WARNING: DATABRICKS_HOST / DATABRICKS_TOKEN / SQL_WAREHOUSE_ID not fully set.")
