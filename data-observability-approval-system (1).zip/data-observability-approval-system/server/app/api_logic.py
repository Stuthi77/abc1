# app/api_logic.py
import time
import requests
from config import config

def query_table(name, query):
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"

    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            return data_array
        elif state == "FAILED":
            print(status_json)
            raise Exception(f"Query failed for '{name}'")
        time.sleep(1)


def get_all_tables():
    tables = {
        "dq_rules": "SELECT distinct catalog_name,schema_name,table_name FROM ds_training_1.dq_config.dq_rules"
    }

    results = {}
    for name, query in tables.items():
        try:
            data = query_table(name, query)
            results[name] = data
            time.sleep(1)
        except Exception as e:
            results[name] = {"error": str(e)}

    return results
