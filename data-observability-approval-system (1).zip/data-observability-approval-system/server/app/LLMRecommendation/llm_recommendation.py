# server/app/LLMRecommendation/llm_recommendation.py
from flask import Blueprint, jsonify, request

from .llm_recommendation_logic import recommend_rules

llm_recommendation_bp = Blueprint("llm_recommendation", __name__)


@llm_recommendation_bp.route("/api/rules/recommend", methods=["POST"])
def api_recommend_rules():
    """
    Body: { "catalog": "...", "schema": "...", "table": "..." }
    Returns: { "results": [ {rule}, ... ] }
    """
    try:
        payload = request.get_json(force=True) or {}
        catalog = payload.get("catalog")
        schema = payload.get("schema")
        table = payload.get("table")

        if not all([catalog, schema, table]):
            return jsonify({"error": "catalog, schema and table are all required."}), 400

        results = recommend_rules(catalog, schema, table)
        if not results:
            return jsonify({"error": "The LLM did not return any usable rules. Try again."}), 502

        return jsonify({"results": results}), 200

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500
