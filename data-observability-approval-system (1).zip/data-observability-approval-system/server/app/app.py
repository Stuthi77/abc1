# from flask import Flask, jsonify, request, send_from_directory
# from flask_cors import CORS
# import os
# #from flask_cors import CORS
# from .Approval.Approval_logic import get_approval_data,get_filter,approve_rule_request,reject_rule_request,revert_rule_request,get_approval_status_counts
# from .RuleManagement.Rule_management_logic import get_tables_data, get_filters_data,get_rules_for_table_data,get_active_or_inactive_rules_for_table,get_filters_for_table,get_rule_details,update_rule_data,delete_rule_data


# from .api_logic import get_all_tables
# from .alerts.routes import alerts_bp
# from .RuleManagement.Rulemanagement import RuleManagement_bp
# from .CreateRules.create_rules import create_rules_bp
# from .RuleManagement.Rulemanagement import RuleManagement_bp
# from .Group.group import groups_bp
# from .Approval.Approval import Approval_bp

# app = Flask(__name__, static_folder='../../templates')
# CORS(app)

# print("Static folder is set to:", app.static_folder)

# @app.route('/assets/<path:path>')
# def serve_assets(path):
#     return send_from_directory(os.path.join(app.static_folder, 'assets'), path)

# @app.route('/', defaults={'path': ''})
# @app.route('/<path:path>')
# def index(path):
#     if path.startswith('api/'):
#         return "API route not found", 404
#     return send_from_directory(app.static_folder, 'index.html')

# # Register the blueprint
# app.register_blueprint(alerts_bp)
# app.register_blueprint(RuleManagement_bp)
# app.register_blueprint(Approval_bp)
# app.register_blueprint(create_rules_bp)

# app.register_blueprint(groups_bp)



# @app.route("/api/user_info", methods=['GET'])
# def api_user_info():
#     try:
#         user_email = request.headers.get('X-Forwarded-Email')
#         display_name = ""
#         if user_email:
#             # Extract display name from email (before @ symbol)
#             email_prefix = user_email.split('@')[0]
#             # Format display name by replacing dots/underscores with spaces and title case
#             display_name = email_prefix.replace('.', ' ').replace('_', ' ').title()
#         else:
#             display_name = "Local Host" 
#             user_email = "localhost.host@latentview.com"

#         result = {
#             "display_name" : display_name,
#             "user_email" : user_email
#         }

#         # Return a success response
#         return jsonify(result), 200


#     except Exception as e:
#         # Return a clear error response if anything fails
#         return jsonify({"error": str(e)}), 500



# if __name__ == "__main__":
#     app.run(debug=True)


from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import os
import yaml

from .Approval.Approval_logic import get_approval_data,get_filter,approve_rule_request,reject_rule_request,revert_rule_request,get_approval_status_counts
from .RuleManagement.Rule_management_logic import get_tables_data, get_filters_data,get_rules_for_table_data,get_active_or_inactive_rules_for_table,get_filters_for_table,get_rule_details,insert_rule_request,delete_rule_data

from .api_logic import get_all_tables
from .alerts.routes import alerts_bp
from .RuleManagement.Rulemanagement import RuleManagement_bp
from .CreateRules.create_rules import create_rules_bp
from .Group.group import groups_bp
from .Approval.Approval import Approval_bp
from .LLMRecommendation.llm_recommendation import llm_recommendation_bp


app = Flask(__name__, static_folder='../../templates')
CORS(app)

print("Static folder is set to:", app.static_folder)

@app.route('/assets/<path:path>')
def serve_assets(path):
    return send_from_directory(os.path.join(app.static_folder, 'assets'), path)

# --- LLM RECOMMENDATION ENDPOINTS ---


# --- CATCH-ALL REACT ROUTE ---

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def index(path):
    if path.startswith('api/'):
        return "API route not found", 404
    return send_from_directory(app.static_folder, 'index.html')


# Register the blueprints
app.register_blueprint(alerts_bp)
app.register_blueprint(RuleManagement_bp)
app.register_blueprint(Approval_bp)
app.register_blueprint(create_rules_bp)
app.register_blueprint(groups_bp)
app.register_blueprint(llm_recommendation_bp)


# --- GENERAL API ROUTES ---

@app.route("/api/user_info", methods=['GET'])
def api_user_info():
    try:
        user_email = request.headers.get('X-Forwarded-Email')
        display_name = ""
        if user_email:
            # Extract display name from email (before @ symbol)
            email_prefix = user_email.split('@')[0]
            # Format display name by replacing dots/underscores with spaces and title case
            display_name = email_prefix.replace('.', ' ').replace('_', ' ').title()
        else:
            display_name = "Local Host"
            user_email = "localhost.host@latentview.com"

        result = {
            "display_name" : display_name,
            "user_email" : user_email
        }

        # Return a success response
        return jsonify(result), 200

    except Exception as e:
        # Return a clear error response if anything fails
        return jsonify({"error": str(e)}), 500


CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")

try:
    with open(CONFIG_PATH, "r") as f:
        APP_CONFIG = yaml.safe_load(f)
except Exception as e:
    # Essential for error handling if the config isn't found
    print(f"Error loading config.yml: {e}")
    APP_CONFIG = {}

@app.route('/api/frontend/config', methods=['GET'])
def get_frontend_config():
    """
    API endpoint to read and serve the necessary configuration data to the React frontend.
    """
    # Define which keys the frontend is allowed to see.
    # We include all the table names that the UI might need for building full paths or labels.
    frontend_keys = [
        "catalog", 
        "schema", 
        "rule_requests_table", 
        "rule_table",
        "table_config",
        "pipeline_metadata",
        "group_table",
        "user_table"
    ]
    
    # Filter the config dictionary to exclude sensitive server settings
    safe_config = {key: APP_CONFIG.get(key) for key in frontend_keys}
    
    # Return the data as JSON
    return jsonify(safe_config)

if __name__ == "__main__":
    app.run(debug=True)


