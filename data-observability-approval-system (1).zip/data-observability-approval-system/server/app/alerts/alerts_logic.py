# app/alerts_logic.py
from app.api_logic import query_table


import yaml
import os


# Load config.yaml
# Always point to server/config.yaml (one level up from app/)
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")


# CONFIG_PATH = os.path.abspath(CONFIG_PATH)


with open(CONFIG_PATH, "r") as f:
    yaml_config = yaml.safe_load(f)


# Assign values
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
RULE_TABLE = yaml_config.get("rule_table")
TABLE_CONFIG = yaml_config.get("table_config")
PIPELINE_METADATA = yaml_config.get("pipeline_metadata")


def get_alerts(
    condition_type=None,
    table=None,
    owner=None,
    start_date=None,
   
    search=None,
    group_id=None,  
):
    """
    Builds and executes the SQL to fetch alerts, with an optional filter
    for group_id.
    """
    query = f"""
        WITH latestUpdates AS (
        SELECT *,
                ROW_NUMBER() OVER (PARTITION BY request_id ORDER BY created_at DESC) AS rn
        FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        WHERE status in('APPROVED','approved','Approved') and operation in ('update','UPDATE','Update')
        ),
        updatedRules AS(
        select dr.rule_id,dr.catalog_name as catalog,dr.schema_name as schema,dr.table_name ,
        dr.condition_type ,
                dr.condition_criteria as condition,
                dr.owner,lu.created_by as updated_by,dr.column_name as columns,dr.severity,dr.updated_at as modified_date,
                dr.effective_date_to,dr.effective_date_from
        from latestupdates lu right join {CATALOG}.{SCHEMA}.{RULE_TABLE} dr
        on lu.request_id=dr.rule_id and  
        date_format(to_timestamp(dr.updated_at),'yyyy-MM-dd HH:mm:ss')=date_format(to_timestamp(lu.created_at),'yyyy-MM-dd HH:mm:ss')
        WHERE 1=1 and dr.updated_at is not null
        and (select case when max(date(effective_date_to))='9999-12-31' then 'is_active' else 'is_inactive' end
            from {CATALOG}.{SCHEMA}.{RULE_TABLE} r2 where r2.rule_id = dr.rule_id)='is_active'
        ),
        createdRules as(
        SELECT  rule_id,catalog_name as catalog,schema_name as schema,table_name ,
        condition_type ,
                condition_criteria as condition,
                owner,null as updated_by,column_name as columns,severity,updated_at as modified_date,
                effective_date_to,effective_date_from
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        where updated_at is null and rule_id not in (
        SELECT rule_id
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} group by rule_id,table_name having count(*)>1
       
       )
        )
    SELECT rule_id,catalog,schema,table_name,condition_type,condition,owner,updated_by,
    columns,severity,date_format(to_timestamp(modified_date),'yyyy-MM-dd HH:mm:ss')as modified_date,
    date_format(to_timestamp(effective_date_from),'yyyy-MM-dd HH:mm:ss') as effective_date_from,
    date_format(to_timestamp(effective_date_to),'yyyy-MM-dd HH:mm:ss') as effective_date_to
    FROM (
            SELECT * FROM updatedRules
            UNION
            SELECT * FROM createdRules
        ) t
        WHERE 1=1
    """




    # --- New filter block for group_id ---
    print('group_id', group_id)
    if group_id:
        query += f"""
            AND (t.catalog, t.schema, t.table_name) IN (
                SELECT catalog_name, schema_name, table_name
                FROM {CATALOG}.{SCHEMA}.{TABLE_CONFIG}
                WHERE group_id = '{group_id}'
            )
        """




    if condition_type:
        placeholders = ",".join(f"'{v}'" for v in condition_type)
        query += f" AND condition_type IN ({placeholders})"




    if table:
        placeholders = ",".join(f"'{v}'" for v in table)
        query += f" AND table_name IN ({placeholders})"




    if owner:
        non_null_owners = [v for v in owner if v.lower() not in ("null", "unknown")]
        null_owner_selected = any(v.lower() in ("null", "unknown") for v in owner)
       
        conditions = []
       
        if non_null_owners:
            placeholders = ",".join(f"'{v}'" for v in non_null_owners)
            conditions.append(f"owner IN ({placeholders})")
       
        if null_owner_selected:
            conditions.append("owner IS NULL")
       
        if conditions:
            query += " AND (" + " OR ".join(conditions) + ")"


    if start_date:
        query += f" AND effective_date_from >= '{start_date}'"
    # if end_date:
    #     query += f" AND effective_date_from <= '{end_date}'"
    if search:
        query += f" AND ( table_name LIKE '%{search}%' )"




    query += " ORDER BY modified_date desc"




    print(query)
   
    rows = query_table("get_alerts", query)
   
    return [
        {
            "rule_id": row[0],
            "catalog": row[1],
            "schema": row[2],      
            "table_name": row[3],
            "condition_type": row[4],
            "condition": row[5],
            "owner": row[6],
            "updated_by": row[7],
            "columns": row[8],
            "severity": row[9],
            "modified_date": row[10],
            "effective_date_from":row[11],
            "effective_date_to" :row[12],
        }
        for row in rows
    ]




def get_filters_data(group_id=None,table=None,condition_type=None,owner=None,date_range=None):
    """
    Executes multiple queries to get all unique values for the filter dropdowns.
    """
    print("getting filtered data")
    filter_queries = {
        "condition_type": f"""SELECT DISTINCT  condition_type FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} dr
         join {CATALOG}.{SCHEMA}.{TABLE_CONFIG} t
        on dr.table_name=t.table_name
        and dr.catalog_name=t.catalog_name
        and dr.schema_name=t.schema_name
        where 1=1
        """,
        "table": f"""SELECT DISTINCT dr.table_name  FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} dr join
            {CATALOG}.{SCHEMA}.{TABLE_CONFIG} t
            on dr.table_name=t.table_name
            and dr.catalog_name=t.catalog_name
            and dr.schema_name=t.schema_name
            where 1=1
            """,
        "owner": f"""SELECT DISTINCT COALESCE(dr.owner, 'Unknown')as owner  FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} dr join
            {CATALOG}.{SCHEMA}.{TABLE_CONFIG} t
            on dr.table_name=t.table_name
            and dr.catalog_name=t.catalog_name
            and dr.schema_name=t.schema_name
             where 1=1
               """
    }
    where_cond = []
   
    if group_id:
        where_cond.append(f" t.group_id='{group_id}'")




    if table:
        if isinstance(table, list) and table:
            placeholders = ", ".join(f"'{t}'" for t in table if t and t.lower() != 'null')
            if placeholders:
                where_cond.append(f"dr.table_name IN ({placeholders})")
        elif isinstance(table, str) and table.strip() and table.lower() != 'null':
            where_cond.append(f"dr.table_name = '{table}'")




    # Similarly for condition_type
    if condition_type:
        if isinstance(condition_type, list) and condition_type:
            placeholders = ", ".join(f"'{ct}'" for ct in condition_type if ct and ct.lower() != 'null')
            if placeholders:
                where_cond.append(f"dr.condition_type IN ({placeholders})")
        elif isinstance(condition_type, str) and condition_type.strip() and condition_type.lower() != 'null':
            where_cond.append(f"dr.condition_type = '{condition_type}'")




    if owner:
        non_null_owners = [v for v in owner if v.lower() not in ("null", "unknown")]
        null_owner_selected = any(v.lower() in ("null", "unknown") for v in owner)
       
        conditions = []
       
        if non_null_owners:
            placeholders = ",".join(f"'{v}'" for v in non_null_owners)
            conditions.append(f"owner IN ({placeholders})")
       
        if null_owner_selected:
            conditions.append("owner IS NULL")
       
        if conditions:
            where_cond.append( "  (" + " OR ".join(conditions) + ")")




    if date_range:
        print("date_range ",date_range)
        where_cond.append(f"dr.effective_date_from >='{date_range}'")
    results = {}
    for name, query in filter_queries.items():
        try:
            if where_cond:
                query += " AND " + " AND ".join(where_cond)
            print(query)
            data = query_table(name,query)
            results[name] = [row[0] for row in data]
            print(data)
        except Exception as e:
            results[name] = {"error": str(e)}




        results["date_range"] = ["Today", "Last 7 Days", "Last 30 Days"]
       




    return results








def get_alert_modifications(rule_id,table_name,modified_date):




    base_query = f"""
    WITH filtered_versions AS (
      SELECT table_name, condition_category, condition_criteria, column_name, severity, updated_at,
      violation_threshold,
     effective_date_to,
     effective_date_from
      FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
      WHERE rule_id = '{rule_id}'  and table_name='{table_name}'
      AND ((select case when max(date(effective_date_to))='9999-12-31' then 'is_active' else 'is_inactive' end from {CATALOG}.{SCHEMA}.{RULE_TABLE} where rule_id = '{rule_id}') = 'is_active')
    """




    base_query += f"""
    ),
    ordered_versions AS (
      SELECT *,
             ROW_NUMBER() OVER (ORDER BY effective_date_to ) AS rn
      FROM filtered_versions
    )
    SELECT
      t1.condition_criteria as old_condition_criteria,
      t2.condition_criteria as new_condition_criteria,
      t1.column_name as old_column_name,
      t2.column_name as new_column_name,
      t1.severity as old_severity,
      t2.severity as new_severity,
      t1.violation_threshold as old_violation_threshold,
      t2.violation_threshold as new_violation_threshold,
      date_format(to_timestamp(t2.updated_at),'yyyy-MM-dd HH:mm:ss') as modified_date,
      date_format(to_timestamp(t2.effective_date_to),'yyyy-MM-dd HH:mm:ss')as effective_date_to,
      date_format(to_timestamp(t2.effective_date_from),'yyyy-MM-dd HH:mm:ss')as effective_date_from




    FROM ordered_versions t1
    JOIN ordered_versions t2
      ON t1.rn + 1 = t2.rn
     AND t1.table_name = t2.table_name
     AND date_format(to_timestamp(t2.updated_at),'yyyy-MM-dd HH:mm:ss')=timestamp('{modified_date}')
 
    """




   
    print(base_query)
    rows = query_table("get_alert_modifications", base_query)




    return [
        {
            "old_condition_criteria": row[0],
            "new_condition_criteria": row[1],
            "old_column_name": row[2],
            "new_column_name": row[3],
            "old_severity": row[4],
            "new_severity" : row[5],
            "old_violation_threshold":row[6],
            "new_violation_threshold":row[7],
            "modified_date": row[8],
            "effective_date_to":row[9],
            "effective_date_from":row[10]
        }
        for row in rows
    ]




def get_rule_summary(rule_id,table_name):




    query=f"""SELECT  column_name,condition_criteria as condition,
        date_format(to_timestamp(created_at),'yyyy-MM-dd HH:mm:ss') as created_at
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
         where rule_id='{rule_id}' and table_name='{table_name}' and rule_id  not in
        (select rule_id from {CATALOG}.{SCHEMA}.{RULE_TABLE} group by rule_id,table_name having count(*)>1 and
        max(date(effective_date_to))='9999-12-31')
        """
    rows = query_table("get_rule_summary", query)
   
    return [
        {
            "column_name": row[0],
            "condition": row[1],
            "created_at": row[2]
        }
        for row in rows
    ]









