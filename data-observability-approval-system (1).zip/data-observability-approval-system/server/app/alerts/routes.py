# app/alerts/routes.py
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify
from app.alerts.alerts_logic import get_alert_modifications,get_alerts,get_filters_data,get_rule_summary
alerts_bp = Blueprint("alerts", __name__)



def get_date_range(label: str):
    today = datetime.utcnow().date()
    if label == "Today":
        return today
    elif label == "Last 7 Days":
        return today - timedelta(days=7)
    elif label == "Last 30 Days":
        return today - timedelta(days=30)
    else:
        return None 
    
# @alerts_bp.route("/api/alerts", methods=["GET"])
# def api_alerts():
    
#     table = request.args.getlist("table")
#     search = request.args.get("search")
#     date_range=request.args.get("dateRange") 
#     owner=request.args.getlist("owner")
#     condition_type=request.args.getlist("condition_type")
#     date_to, date_from = get_date_range(date_range)

#     result = get_alerts(condition_type,table,owner,date_to,date_from,search)
   
#     return jsonify(result)
@alerts_bp.route("/api/alerts", methods=["GET"])
def api_alerts():
    
    table = request.args.getlist("table")
    search = request.args.get("search")
    date_range=request.args.get("dateRange") 
    group_id=request.args.get("group_id")
    owner=request.args.getlist("owner")
    condition_type=request.args.getlist("condition_type")
    date_to = get_date_range(date_range)
    print("date_ to ", date_to)
    
    result = get_alerts(condition_type,table,owner,date_to,search,group_id)
   
    return jsonify(result)


@alerts_bp.route("/api/alerts/<string:rule_id>/<string:table_name>/modifications", methods=["GET"])
def api_modifications(rule_id,table_name):
    modified_date=request.args.get("modified_date") 
    
    print(f"📅 API received: {modified_date}")
    result = get_alert_modifications(rule_id,table_name,modified_date)
    

    return jsonify(result)

# @alerts_bp.route("/api/alerts/filters", methods=["GET"])
# def api_get_filters_data():
#     try:
#         filters_data = get_filters_data()
#         return jsonify(filters_data)
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
@alerts_bp.route("/api/alerts/filters", methods=["GET"])
def api_get_filters_data():
    try:
        tables = request.args.getlist("table")
        owners = request.args.getlist("owner")
        condition_types = request.args.getlist("condition_type")
        date_ranges = request.args.get("date_range")
        print("date_ranges recieved ",date_ranges)
        date_range=get_date_range(date_ranges)
        print("date_ranges ",date_range)
        # Get single-value params (like group_id)
        group_id = request.args.get("group_id")

        # Pass everything to your logic function
        filters_data = get_filters_data(
            group_id=group_id,
            table=tables,
            owner=owners,
            condition_type=condition_types,
            date_range=get_date_range(date_ranges)
        )
     
        return jsonify(filters_data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@alerts_bp.route("/api/alerts/<string:rule_id>/<string:table_name>/rulesummary", methods=["GET"])
def api_rule_summary(rule_id,table_name):
    try:
        print(f"Fetching summary for rule {rule_id}")

        result = get_rule_summary(rule_id,table_name)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    