from flask import Flask, jsonify, request, Blueprint
from .create_rules_logic import get_catalogs, get_schemas, get_tables, get_columns, insert_rule

app = Flask(__name__)

# --- define blueprint ---
create_rules_bp = Blueprint("create_rules", __name__)

# --- GET Catalog Metadata (all catalogs in the environment) ---
@create_rules_bp.route("/api/catalog-meta", methods=['GET'])
def api_get_catalog_meta():
    try:
        data = get_catalogs()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Schema Metadata ---
@create_rules_bp.route("/api/schema-meta", methods=['GET'])
def api_get_schema_meta():
    try:
        catalog_name = request.args.get('catalog')
        if not catalog_name:
            return jsonify({"error": "Missing 'catalog' query parameter"}), 400
        data = get_schemas(catalog_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Table Metadata ---
@create_rules_bp.route("/api/table-meta", methods=['GET'])
def api_get_table_meta():
    try:
        catalog_name = request.args.get('catalog')
        schema_name = request.args.get('schema')
        if not all([catalog_name, schema_name]):
            return jsonify({"error": "Missing 'catalog' or 'schema' query parameter"}), 400
        data = get_tables(catalog_name, schema_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- GET Column Metadata ---
@create_rules_bp.route("/api/column-meta", methods=['GET'])
def api_get_column_meta():
    try:
        catalog_name = request.args.get('catalog')
        schema_name = request.args.get('schema')
        table_name = request.args.get('table')
        if not all([catalog_name, schema_name, table_name]):
            return jsonify({"error": "Missing 'catalog', 'schema', or 'table' query parameter"}), 400
        data = get_columns(catalog_name, schema_name, table_name)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- POST Create Rule ---
@create_rules_bp.route("/api/rules/add", methods=['POST'])
def api_add_rule():
    try:
        payload = request.get_json(force=True)
        # Check if payload is a list (multiple rules)
        if isinstance(payload, list):
            results = []
            for rule_data in payload:
                res = insert_rule(rule_data)
                results.append(res)
            return jsonify({"message": "Rules added successfully", "results": results})
        else:
            # Single rule
            res = insert_rule(payload)
            return jsonify({"message": "Rule added successfully", "result": res})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
