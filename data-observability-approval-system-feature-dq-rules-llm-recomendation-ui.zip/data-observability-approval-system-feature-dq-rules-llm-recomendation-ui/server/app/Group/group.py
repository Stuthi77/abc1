# server/app/Group/Group.py

from flask import Flask, jsonify, request,Blueprint
import uuid
# Correctly import from the logic file in the same directory
from .group_logic import get_groups_data,get_add_table_data,get_users_data,create_group,get_all_tables_data,get_group_by_id,get_group_members_data,get_group_tables_data,add_tables_to_group_data,add_members_to_group_data,delete_group_data,remove_members_from_group_data

app = Flask(__name__)

# --- define blueprint ---
groups_bp = Blueprint("groups", __name__)



@groups_bp.route("/api/groups", methods=['GET'])
def api_get_groups():
    """
    API endpoint to get a paginated list of groups with subscription status.
    """
    try:
        # Get user_id from request arguments
        user_id = request.args.get('user_id')
        data = get_groups_data(user_id=user_id)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    
@groups_bp.route("/api/add_table_data", methods=['GET'])
def api_get_add_table_data():
    """Endpoint for the Add Table list."""
    try:
        search_query = request.args.get('search')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))

        data = get_add_table_data(search=search_query, page=page, limit=limit)
        
        total_rows = data[0]['total_rows'] if data else 0
        
        # We remove the total_rows from each item for a cleaner response
        tables_list = [{k: v for k, v in row.items() if k != 'total_rows'} for row in data]
        
        response = {
            "total_rows": total_rows,
            "tables": tables_list
        }
        return jsonify(response)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


@groups_bp.route("/api/users", methods=['GET'])
def api_get_users():
    """Endpoint for the Add Users dropdown list."""
    try:
        data = get_users_data()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
# Add this new route to your rulemanagement.py file

@groups_bp.route("/api/create_group", methods=['POST'])
def api_create_group():
    """Endpoint to create a new group."""
    try:
        group_details = request.get_json()
        print(group_details)
        result = create_group(group_details)
        print(result)
        return jsonify(result), 201 # 201 Created is a more specific success code
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    

@groups_bp.route("/api/all_tables", methods=['GET'])
def api_get_all_tables():
    """Endpoint for getting all tables from the information schema."""
    try:
        data = get_all_tables_data()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@groups_bp.route('/api/groups/<string:group_id>', methods=['GET'])
def get_group(group_id):
    try:
        group_data = get_group_by_id(group_id)
        if group_data:
            return jsonify(group_data)
        else:
            # Return 404 Not Found if the group ID doesn't exist
            return jsonify({"error": "Group not found"}), 404
    except Exception as e:
        # Handle internal server errors
        return jsonify({"error": str(e)}), 500
    

@groups_bp.route("/api/groups/<string:groupId>/tables", methods=['GET'])
def get_api_group_tables(groupId):
    """
    Handles getting the list of tables for a group.
    """
    try:
        search_query = request.args.get('search')
        data = get_group_tables_data(groupId, search=search_query)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@groups_bp.route("/api/groups/<groupId>/tables/add", methods=["POST"])
def add_tables(groupId):
    try:
        data = request.get_json()
        tables_to_add = data.get("tables", [])

        if not tables_to_add:
            return jsonify({"status": "error", "message": "No tables provided"}), 400

        result = add_tables_to_group_data(groupId, tables_to_add)
        return jsonify(result), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@groups_bp.route("/api/groups/<string:groupId>/add_members", methods=['POST'])
def api_add_group_members(groupId):
    """Endpoint to add members to a group."""
    try:
        data = request.get_json()
        user_ids = data.get("user_ids")

        if not user_ids:
            return jsonify({"status": "error", "message": "No user IDs provided"}), 400

        result = add_members_to_group_data(groupId, user_ids)
        return jsonify(result), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@groups_bp.route("/api/groups/<uuid:groupId>", methods=['DELETE'])
def api_delete_group(groupId):
    """Endpoint to delete a group."""
    try:
        # Convert the UUID object from the URL into a string for the logic function
        result = delete_group_data(str(groupId))
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@groups_bp.route("/api/groups/<string:groupId>/remove_members", methods=['POST'])
def api_remove_group_members(groupId):
    """Endpoint to remove members from a group."""
    try:
        data = request.get_json()
        user_ids = data.get("user_ids")

        result = remove_members_from_group_data(groupId, user_ids)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@groups_bp.route("/api/groups/<string:groupId>/members", methods=['GET'])
def api_get_group_members(groupId):
    """Endpoint for a group's members list, with search."""
    try:
        search_query = request.args.get('search')
        data = get_group_members_data(groupId, search=search_query)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500