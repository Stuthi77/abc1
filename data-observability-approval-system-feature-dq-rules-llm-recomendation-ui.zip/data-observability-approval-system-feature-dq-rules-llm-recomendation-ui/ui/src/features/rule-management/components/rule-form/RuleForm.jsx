// import React, { useState, useEffect } from "react";
// import {
//   Grid, TextField, Select, MenuItem, FormControl, InputLabel,
//   Checkbox, ListItemText, OutlinedInput, Box, IconButton, CircularProgress,Typography,Skeleton 
// } from "@mui/material";
// import EditIcon from "@mui/icons-material/Edit";
// import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";

// // Base URL for the API endpoints
// const API_BASE_URL = `${import.meta.env.VITE_API_URL}/api`;
// const API_CONFIG_URL = `${import.meta.env.VITE_API_URL}/api/frontend/config`; // Dynamic config endpoint

// const categoryToTypes = {
//   "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
//   "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
//   "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
//   "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
//   "Business Logic Rules": ["CUSTOM_RULE"],
//   "Consistency & Standardization Checks": ["CASE_STANDARDIZATION", "MAPPING_CHECK"],
//   "Anomaly Detection": ["OUTLIER_DETECTION"],
//   "Time-based Validations": ["TIME_STAMP_CHECK"],
//   "Trend Analysis": ["ROW_COUNT_TREND"],
//   "KPI Statistics": ["KPI_CHECK"],
// };

// const RuleForm = ({
//   ruleNumber,
//   rule,
//   onChange,
//   onEdit,
//   isCardView
// }) => {
//   const [availableCatalogs, setAvailableCatalogs] = useState([]);
  // const [availableSchemas, setAvailableSchemas] = useState([]);
//   const [availableTables, setAvailableTables] = useState([]);
//   const [availableColumns, setAvailableColumns] = useState([]);
//   const [loading, setLoading] = useState({ schemas: false, tables: false, columns: false });
//   const [error, setError] = useState(null);
//   const [config, setConfig] = useState(null);
//   const [configLoading, setConfigLoading] = useState(true);

//   const handleChange = (field, value) => {
//     const updatedRule = { ...rule, [field]: value };

//     if (field === "schema") {
//       updatedRule.table = "";
//       updatedRule.columns = [];
//       setAvailableTables([]);
//       setAvailableColumns([]);
//     }

//     if (field === "table") {
//       updatedRule.columns = [];
//       setAvailableColumns([]);
//     }

//     if (field === "conditionCategory") {
//       updatedRule.conditionType = "";
//       updatedRule.criteria = {};
//     }

//     onChange(ruleNumber - 1, updatedRule);
//   };
//   useEffect(() => {
//       const fetchConfig = async () => {
//           try {
//               const response = await fetch(API_CONFIG_URL);
//               if (!response.ok) throw new Error(`Config fetch error: ${response.status}`);
//               const data = await response.json();
//               setConfig(data);
//           } catch (e) {
//               setError("Failed to load application configuration.");
//               console.error("Error fetching config:", e);
//           } finally {
//               setConfigLoading(false);
//           }
//       };
//       fetchConfig();
//   }, []);

//   useEffect(() => {
//       // Wait until config is loaded
//       if (!config || configLoading) return;
      
//       const DYNAMIC_CATALOG = config.catalog; 
      
//       const fetchSchemas = async () => {
//           setLoading(prev => ({ ...prev, schemas: true }));
//           setError(null);
//           try {
//               // REPLACEMENT: Use DYNAMIC_CATALOG
//               const response = await fetch(`${API_BASE_URL}/schema-meta?catalog=${DYNAMIC_CATALOG}`);
//               if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
//               const data = await response.json();
//               const schemas = data.map(item => item.schema_name);
//               setAvailableSchemas(schemas);
//           } catch (e) {
//               setError("Failed to load schemas. Please check the API endpoint.");
//               console.error("Error fetching schemas:", e);
//           } finally {
//               setLoading(prev => ({ ...prev, schemas: false }));
//           }
//       };
//       fetchSchemas();
//   // DEPENDENCY ADDED: config, configLoading
//   }, [config, configLoading]);

//   useEffect(() => {
//       // Wait until config is loaded
//       if (!config || !rule.schema) return;
      
//       const DYNAMIC_CATALOG = config.catalog; 

//       const fetchTables = async () => {
//           setLoading(prev => ({ ...prev, tables: true }));
//           setError(null);
//           try {
//               // REPLACEMENT: Use DYNAMIC_CATALOG
//               const response = await fetch(`${API_BASE_URL}/table-meta?catalog=${DYNAMIC_CATALOG}&schema=${rule.schema}`);
//               if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
//               const data = await response.json();
//               const tables = data.map(item => item.table_name);
//               setAvailableTables(tables);
//           } catch (e) {
//               setError("Failed to load tables. Please check the API endpoint.");
//               console.error("Error fetching tables:", e);
//           } finally {
//               setLoading(prev => ({ ...prev, tables: false }));
//           }
//       };
//       fetchTables();
//   // DEPENDENCY ADDED: config
//   }, [rule.schema, rule.catalog, config]);

//   useEffect(() => {
//       // Wait until config is loaded
//       if (!config || !rule.table) return;

//       const DYNAMIC_CATALOG = config.catalog; 
      
//       const fetchColumns = async () => {
//           setLoading(prev => ({ ...prev, columns: true }));
//           setError(null);
//           try {
//               // REPLACEMENT: Use DYNAMIC_CATALOG
//               const response = await fetch(`${API_BASE_URL}/column-meta?catalog=${DYNAMIC_CATALOG}&schema=${rule.schema}&table=${rule.table}`);
//               if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
//               const data = await response.json();
//               const columns = data.map(item => item.column_name);
//               setAvailableColumns(columns);
//           } catch (e) {
//               setError("Failed to load columns. Please check the API endpoint.");
//               console.error("Error fetching columns:", e);
//           } finally {
//               setLoading(prev => ({ ...prev, columns: false }));
//           }
//       };
//       fetchColumns();
//   // DEPENDENCY ADDED: config
//   }, [rule.table, rule.schema, rule.catalog, config]);
//   // --- ADD CONFIG LOADING/ERROR RENDER BLOCK ---
//   // AFTER the three data-fetching useEffect blocks, REPLACE the entire conditional block (if (configLoading) { ... } if (error || !config || !config.catalog) { ... } ) with this:
//   if (configLoading) {
//       // Define a visibly distinct color for the skeleton background
//       const SKELETON_COLOR = '#A9A9A9'; 

//       return (
//           <Box sx={{ mb: 4, border: "1px solid #e0e0e0", borderRadius: 2, p: 3 }}>
//               <Grid container spacing={2}>
//                   {[...Array(6)].map((_, index) => (
//                       // Skeleton for the first six form fields (Catalog, Schema, Table, etc.)
//                       <Grid item xs={12} md={4} key={index}>
//                           {/* Applied bgcolor for strong contrast */}
//                           <Skeleton 
//                               variant="rectangular" 
//                               height={36} 
//                               animation="wave"
//                               sx={{ bgcolor: SKELETON_COLOR }} 
//                           />
//                       </Grid>
//                   ))}
                  
//                   {/* Skeleton for the Rule Description textarea */}
//                   <Grid item xs={12} md={4}>
//                       {/* Applied bgcolor for strong contrast */}
//                       <Skeleton 
//                           variant="rectangular" 
//                           height={100} 
//                           sx={{ mt: 2, bgcolor: SKELETON_COLOR }} 
//                           animation="wave" 
//                       />
//                   </Grid>
//               </Grid>
//           </Box>
//       );
//   }

//     // --- CONDITIONAL RENDER: ERROR ---
//     if (error || !config || !config.catalog) {
//         return <Box sx={{ p: 3, color: 'error.main', border: "1px solid #e0e0e0", borderRadius: 2 }}>Error: Configuration data is missing or failed to load. {error}</Box>;
//     }

//     // --- MAIN RENDER ---
//     const DYNAMIC_CATALOG = config.catalog;

//   // if (configLoading) {
//   //     return (
//   //         <Box sx={{ p: 3, textAlign: 'center' }}>
//   //             <CircularProgress size={24} />
//   //             <Typography variant="body1" sx={{ ml: 2, display: 'inline' }}>Loading configuration...</Typography>
//   //         </Box>
//   //     );
//   // }

//   // if (error || !config || !config.catalog) {
//   //     return <Box sx={{ p: 3, color: 'error.main' }}>Error: Configuration data is missing or failed to load. {error}</Box>;
//   // }

//   // // Define DYNAMIC_CATALOG here for use in the return block below
//   // const DYNAMIC_CATALOG = config.catalog;

//   const availableConditionTypes = rule.conditionCategory
//     ? categoryToTypes[rule.conditionCategory] || []
//     : [];
//   // const isCustomTypeInput = rule.conditionCategory === "Business Logic Rules";
//   // const effectiveConditionType =
//   //   isCustomTypeInput || rule.conditionCategory === "KPI Statistics"
//   //     ? "CUSTOM_RULE"
//   //     : rule.conditionType;
//   const isCustomTypeInput = rule.conditionCategory === "Business Logic Rules";
//   const isKpiCheck = rule.conditionCategory === "KPI Statistics";

//   // Effective type → decide what DynamicConditionFields should render
//   const effectiveConditionType = isKpiCheck
//     ? "KPI_CHECK"
//     : isCustomTypeInput
//     ? "CUSTOM_RULE"
//     : rule.conditionType;


//   return (
//     <Box sx={{ mb: 4, border: "1px solid #e0e0e0", borderRadius: 2, p: 3 }}>
//       <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
//         <Box fontWeight={600} fontSize={16}>Rule: {ruleNumber}</Box>
//         {isCardView && (
//           <IconButton size="small" onClick={() => onEdit(ruleNumber - 1)}>
//             <EditIcon fontSize="small" />
//           </IconButton>
//         )}
//       </Box>

//       {!isCardView && (
//         <>
//           <Grid container spacing={2}>
//             <Grid size={{ xs: 12, md: 4 }} justifyContent={"left-end"}>
//               {/* Catalog */}
//               <Box>
//                 {/* Note: The FormControl wrapper has height: 32, but the actual rendered height is likely 36-40 due to global CSS/MUI defaults */}
//                 <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Catalog</InputLabel>
//                   <Select value={DYNAMIC_CATALOG} label="Catalog" disabled>
//                     <MenuItem value={DYNAMIC_CATALOG}>{DYNAMIC_CATALOG}</MenuItem>
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Columns */}
//               <Box mt={2}>
//                 <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Columns</InputLabel>
//                   <Select
//                     multiple
//                     value={!rule.table || loading.columns ? [] : rule.columns}
//                     onChange={(e) => handleChange("columns", e.target.value)}
//                     input={<OutlinedInput label="Columns" />}
//                     renderValue={(selected) => selected.join(", ")}
//                     MenuProps={{
//                       PaperProps: {
//                         style: { maxHeight: 36 * 6 + 8, width: 250 },
//                       },
//                     }}
//                   >
//                     {!rule.schema && !rule.table ? (
//                       <MenuItem disabled>Please select a schema and table</MenuItem>
//                     ) : !rule.table ? (
//                       <MenuItem disabled>Please select a table</MenuItem>
//                     ) : loading.columns ? (
//                       <MenuItem disabled>
//                         <Box sx={{ display: 'flex', alignItems: 'center' }}>
//                           <CircularProgress size={20} />
//                           <span style={{ marginLeft: 8 }}>Loading...</span>
//                         </Box>
//                       </MenuItem>
//                     ) : (
//                       availableColumns.map((col) => (
//                         <MenuItem key={col} value={col}>
//                           <Checkbox size="small" checked={rule.columns.includes(col)} />
//                           <ListItemText primary={col} sx={{ fontSize: '0.85rem' }} />
//                         </MenuItem>
//                       ))
//                     )}
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Rule Description */}
//               <Box mt={2}>
//                 <textarea
//                   value={rule.ruleDescription || ""}
//                   onChange={(e) => handleChange("ruleDescription", e.target.value)}
//                   placeholder="Enter Rule description"
//                   rows={4}
//                   style={{
//                     width: '100%',
//                     padding: '10px 14px',
//                     fontSize: '0.85rem',
//                     borderRadius: '4px',
//                     border: '1px solid rgba(0, 0, 0, 0.23)',
//                     backgroundColor: '#fff',
//                     fontFamily: 'Segeo-UI, Helvetica, Arial, sans-serif',
//                     boxSizing: 'border-box',
//                     transition: 'border-color 0.2s, box-shadow 0.2s',
//                     outline: 'none',
//                     resize: 'none',
//                     lineHeight: 1.2,
//                   }}
//                   onFocus={(e) => {
//                     e.target.style.border = '1px solid #1976d2';
//                     e.target.style.boxShadow = '0 0 0 1px #1976d2';
//                   }}
//                   onBlur={(e) => {
//                     e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
//                     e.target.style.boxShadow = 'none';
//                   }}
//                 />
//               </Box>
//             </Grid>

//             <Grid size={{ xs: 12, md: 4 }} justifyContent={"left-end"}>
//               {/* Schema */}
//               <Box>
//                 <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Schema</InputLabel>
//                   <Select
//                     value={loading.schemas ? "" : rule.schema}
//                     onChange={(e) => handleChange("schema", e.target.value)}
//                     input={<OutlinedInput label="Schema" />}
//                     MenuProps={{
//                       PaperProps: { style: { maxHeight: 36 * 6 + 8, width: 250 } },
//                     }}
//                   >
//                     {loading.schemas ? (
//                       <MenuItem disabled>
//                         <CircularProgress size={20} /> Loading...
//                       </MenuItem>
//                     ) : (
//                       availableSchemas.map((schema) => (
//                         <MenuItem key={schema} value={schema}>{schema}</MenuItem>
//                       ))
//                     )}
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Condition Category */}
//               <Box mt={2}>
//                 <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Condition Category</InputLabel>
//                   <Select
//                     value={rule.conditionCategory}
//                     onChange={(e) => handleChange("conditionCategory", e.target.value)}
//                     input={<OutlinedInput label="Condition Category" />}
//                     MenuProps={{
//                       PaperProps: { style: { maxHeight: 36 * 6 + 8, width: 250 } },
//                     }}
//                   >
//                     {Object.keys(categoryToTypes).map((category) => (
//                       <MenuItem key={category} value={category}>{category}</MenuItem>
//                     ))}
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Severity */}
//               <Box mt={2}>
//                 <FormControl fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Severity</InputLabel>
//                   <Select
//                     value={rule.severity}
//                     onChange={(e) => handleChange("severity", e.target.value)}
//                     input={<OutlinedInput label="Severity" />}
//                   >
//                     <MenuItem value="Warning">Warning</MenuItem>
//                     <MenuItem value="Critical">Critical</MenuItem>
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Threshold */}
//               <Box mt={2}>
//                 <TextField
//                   fullWidth
//                   label="Threshold"
//                   type="number"
//                   value={rule.threshold}
//                   onChange={(e) => handleChange("threshold", e.target.value)}
//                   size="small"
//                   // FIX: Targetting 36px total height to match the effective size of the Select components
//                   sx={{ 
//                     fontSize: '0.75rem', 
//                     '& .MuiOutlinedInput-root': {
//                       height: '36px !important', // Force the outer wrapper height to 36px
//                       padding: '0 !important', 
//                       '& .MuiOutlinedInput-input': {
//                         // 6px vertical padding + 24px inner content height = 36px total
//                         padding: '6px 14px !important', 
//                         fontSize: '0.85rem !important',
//                         height: '24px !important', 
//                       }
//                     },
//                     // Adjust label Y position for 36px height container
//                     '& .MuiInputLabel-root:not(.MuiInputLabel-shrink)': {
//                         transform: 'translate(14px, 8px) scale(1) !important',
//                     }
//                   }}
//                 />
//               </Box>
//             </Grid>

//             <Grid size={{ xs: 12, md: 4 }} justifyContent={"left-end"}>
//               {/* Table */}
//               <Box>
//                 <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                   <InputLabel>Table</InputLabel>
//                   <Select
//                     value={!rule.schema || loading.tables ? "" : rule.table}
//                     onChange={(e) => handleChange("table", e.target.value)}
//                     input={<OutlinedInput label="Table" />}
//                     MenuProps={{
//                       PaperProps: { style: { maxHeight: 36 * 6 + 8, width: 250 } },
//                     }}
//                   >
//                     {!rule.schema ? (
//                       <MenuItem disabled>Please select a schema</MenuItem>
//                     ) : loading.tables ? (
//                       <MenuItem disabled>
//                         <Box sx={{ display: 'flex', alignItems: 'center' }}>
//                           <CircularProgress size={20} />
//                           <span style={{ marginLeft: 8 }}>Loading...</span>
//                         </Box>
//                       </MenuItem>
//                     ) : (
//                       availableTables.map((table) => (
//                         <MenuItem key={table} value={table}>{table}</MenuItem>
//                       ))
//                     )}
//                   </Select>
//                 </FormControl>
//               </Box>

//               {/* Condition Type */}
//               {/* <Box mt={2}>
//                 {isCustomTypeInput || rule.conditionCategory === "KPI Statistics" ? (
//                   <TextField
//                     required
//                     fullWidth
//                     size="small"
//                     label="Condition Type (Custom Name)"
//                     value={rule.conditionType}
//                     onChange={(e) => handleChange("conditionType", e.target.value)}
//                     disabled={!rule.conditionCategory}
//                     // FIX: Targetting 36px total height to match the effective size of the Select components
//                     sx={{
//                       fontSize: '0.75rem',
//                       '& .MuiOutlinedInput-root': {
//                         height: '36px !important', // Force the outer wrapper height to 36px
//                         padding: '0 !important', 
//                         '& .MuiOutlinedInput-input': {
//                           // 6px vertical padding + 24px inner content height = 36px total
//                           padding: '6px 14px !important', 
//                           fontSize: '0.85rem !important',
//                           height: '24px !important', 
//                         },
//                       },
//                       '& .MuiInputLabel-root': {
//                         fontSize: '0.75rem',
//                       },
//                       // Adjust label Y position for 36px height container
//                       '& .MuiInputLabel-root:not(.MuiInputLabel-shrink)': {
//                         transform: 'translate(14px, 8px) scale(1) !important',
//                       }
//                     }}
//                   />
//                 ) : (
//                   <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                     <InputLabel>Condition Type</InputLabel>
//                     <Select
//                       value={rule.conditionType}
//                       onChange={(e) => handleChange("conditionType", e.target.value)}
//                       input={<OutlinedInput label="Condition Type" />}
//                       disabled={!rule.conditionCategory}
//                     >
//                       {availableConditionTypes.map((type) => (
//                         <MenuItem key={type} value={type}>{type}</MenuItem>
//                       ))}
//                     </Select>
//                   </FormControl>
//                 )}
//               </Box> */}
//               {/* <Box mt={2}>
//                 {isCustomTypeInput ? (
//                   // Business Logic Rules → free text input
//                   <TextField
//                     required
//                     fullWidth
//                     size="small"
//                     label="Condition Type (Custom Name)"
//                     value={rule.conditionType}
//                     onChange={(e) => handleChange("conditionType", e.target.value)}
//                     disabled={!rule.conditionCategory}
//                     sx={{
//                       fontSize: '0.75rem',
//                       '& .MuiOutlinedInput-root': {
//                         height: '36px !important',
//                         padding: '0 !important',
//                         '& .MuiOutlinedInput-input': {
//                           padding: '6px 14px !important',
//                           fontSize: '0.85rem !important',
//                           height: '24px !important',
//                         },
//                       },
//                       '& .MuiInputLabel-root': {
//                         fontSize: '0.75rem',
//                       },
//                       '& .MuiInputLabel-root:not(.MuiInputLabel-shrink)': {
//                         transform: 'translate(14px, 8px) scale(1) !important',
//                       },
//                     }}
//                   />
//                 ) : (
//                   // KPI_CHECK + others → dropdown
//                   <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                     <InputLabel>Condition Type</InputLabel>
//                     <Select
//                       value={rule.conditionType}
//                       onChange={(e) => handleChange("conditionType", e.target.value)}
//                       input={<OutlinedInput label="Condition Type" />}
//                       disabled={!rule.conditionCategory}
//                     >
//                       {availableConditionTypes.map((type) => (
//                         <MenuItem key={type} value={type}>{type}</MenuItem>
//                       ))}
//                     </Select>
//                   </FormControl>
//                 )}
//               </Box> */}
//               <Box mt={2}>
//                 {(isCustomTypeInput || isKpiCheck) ? (
//                   <TextField
//                     required
//                     fullWidth
//                     size="small"
//                     label="Condition Type (Custom Name)"
//                     value={rule.conditionType}
//                     onChange={(e) => handleChange("conditionType", e.target.value)}
//                     disabled={!rule.conditionCategory}
//                     sx={{
//                       fontSize: '0.75rem',
//                       '& .MuiOutlinedInput-root': {
//                         height: '36px !important',
//                         padding: '0 !important',
//                         '& .MuiOutlinedInput-input': {
//                           padding: '6px 14px !important',
//                           fontSize: '0.85rem !important',
//                           height: '24px !important',
//                         },
//                       },
//                       '& .MuiInputLabel-root': {
//                         fontSize: '0.75rem',
//                       },
//                       '& .MuiInputLabel-root:not(.MuiInputLabel-shrink)': {
//                         transform: 'translate(14px, 8px) scale(1) !important',
//                       },
//                     }}
//                   />
//                 ) : (
//                   <FormControl required fullWidth size="small" sx={{ fontSize: '0.75rem', height: 32 }}>
//                     <InputLabel>Condition Type</InputLabel>
//                     <Select
//                       value={rule.conditionType}
//                       onChange={(e) => handleChange("conditionType", e.target.value)}
//                       input={<OutlinedInput label="Condition Type" />}
//                       disabled={!rule.conditionCategory}
//                     >
//                       {availableConditionTypes.map((type) => (
//                         <MenuItem key={type} value={type}>{type}</MenuItem>
//                       ))}
//                     </Select>
//                   </FormControl>
//                 )}
//               </Box>



//               {/* Dynamic Criteria Fields */}
//               <Box mt={2}>
//                 <DynamicConditionFields
//                   category={rule.conditionCategory}
//                   type={effectiveConditionType}
//                   columns={availableColumns}
//                   onCriteriaChange={(updatedCriteria) => {
//                       // merge updated criteria with existing criteria to avoid losing previous fields
//                       const mergedCriteria = { ...rule.criteria, ...updatedCriteria };
//                       handleChange("criteria", mergedCriteria);
//                   }}
//                 />
//               </Box>


//               {/* <Box mt={2}>
//                 <DynamicConditionFields
//                   category={rule.conditionCategory}
//                   type={effectiveConditionType}
//                   columns={availableColumns}
//                   onCriteriaChange={(updated) => handleChange("criteria", updated)}
//                 />
//               </Box> */}
//             </Grid>
//           </Grid>
//         </>
//       )}
//     </Box>
//   );
// };

// export default RuleForm;

import React, { useState, useEffect } from "react";
import {
  Grid, TextField, Select, MenuItem, FormControl, InputLabel,
  Checkbox, ListItemText, OutlinedInput, Box, IconButton, CircularProgress,Typography,Skeleton,Autocomplete 
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import EditIcon from "@mui/icons-material/Edit";
import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";

// Base URL for the API endpoints
const API_BASE_URL = `${import.meta.env.VITE_API_URL}/api`;
const API_CONFIG_URL = `${import.meta.env.VITE_API_URL}/api/frontend/config`; // Dynamic config endpoint

const categoryToTypes = {
  "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
  "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
  "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
  "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
  "Business Logic Rules": ["CUSTOM_RULE"],
  "Consistency & Standardization Checks": ["CASE_STANDARDIZATION", "MAPPING_CHECK"],
  "Anomaly Detection": ["OUTLIER_DETECTION"],
  "Time-based Validations": ["TIME_STAMP_CHECK"],
  "Trend Analysis": ["ROW_COUNT_TREND"],
  "KPI Statistics": ["KPI_CHECK"],
};

const RuleForm = ({
  ruleNumber,
  rule,
  onChange,
  onEdit,
  isCardView
}) => {
  const [availableSchemas, setAvailableSchemas] = useState([]);
  const [availableCatalogs, setAvailableCatalogs] = useState([]);
  const [availableTables, setAvailableTables] = useState([]);
  const [availableColumns, setAvailableColumns] = useState([]);
  const [loading, setLoading] = useState({ schemas: false, tables: false, columns: false });
  const [error, setError] = useState(null);
  const [config, setConfig] = useState(null);
  const [configLoading, setConfigLoading] = useState(true);
  const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
  const checkedIcon = <CheckBoxIcon fontSize="small" />;

  const autocompleteStyles = {
      // Targets the InputBase wrapper used internally by Autocomplete/TextField
      '& .MuiInputBase-root': {
          height: '36px !important',
          padding: '0 !important',
          '& .MuiOutlinedInput-input': {
              padding: '6px 14px !important',
              fontSize: '0.85rem !important',
              height: '24px !important',
          },
      },
      // Adjusts the label position for the compact 36px height
      '& .MuiInputLabel-root:not(.MuiInputLabel-shrink)': {
          transform: 'translate(14px, 8px) scale(1) !important',
          fontSize: '0.85rem',
      },
      '& .MuiInputLabel-shrink': {
          fontSize: '0.75rem',
      },
      // Centers the clear/dropdown icons within the 36px height for Autocomplete
      '& .MuiAutocomplete-endAdornment': {
          top: '50%',
          transform: 'translateY(-50%)',
      }
  };

  const handleChange = (field, value) => {
    const updatedRule = { ...rule, [field]: value };

    if (field === "catalog") {
      updatedRule.schema = "";
      updatedRule.table = "";
      updatedRule.columns = [];
      setAvailableSchemas([]);
      setAvailableTables([]);
      setAvailableColumns([]);
    }

    if (field === "schema") {
      updatedRule.table = "";
      updatedRule.columns = [];
      setAvailableTables([]);
      setAvailableColumns([]);
    }

    if (field === "table") {
      updatedRule.columns = [];
      setAvailableColumns([]);
    }

    if (field === "conditionCategory") {
      updatedRule.conditionType = "";
      updatedRule.criteria = {};
    }

    onChange(ruleNumber - 1, updatedRule);
  };
  useEffect(() => {
      const fetchConfig = async () => {
          try {
              const response = await fetch(API_CONFIG_URL);
              if (!response.ok) throw new Error(`Config fetch error: ${response.status}`);
              const data = await response.json();
              setConfig(data);
          } catch (e) {
              setError("Failed to load application configuration.");
              console.error("Error fetching config:", e);
          } finally {
              setConfigLoading(false);
          }
      };
      fetchConfig();
  }, []);

  // Load ALL catalogs in the environment once config is ready
  useEffect(() => {
      if (!config || configLoading) return;
      const fetchCatalogs = async () => {
          setLoading(prev => ({ ...prev, catalogs: true }));
          try {
              const response = await fetch(`${API_BASE_URL}/catalog-meta`);
              if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
              const data = await response.json();
              const catalogs = data.map(item => item.catalog_name);
              // Make sure the configured default catalog is always present
              if (config.catalog && !catalogs.includes(config.catalog)) {
                  catalogs.unshift(config.catalog);
              }
              setAvailableCatalogs(catalogs);
          } catch (e) {
              console.error("Error fetching catalogs:", e);
              // Fallback: at least the configured catalog remains usable
              setAvailableCatalogs(config.catalog ? [config.catalog] : []);
          } finally {
              setLoading(prev => ({ ...prev, catalogs: false }));
          }
      };
      fetchCatalogs();
  }, [config, configLoading]);

  useEffect(() => {
      // Wait until config is loaded
      if (!config || configLoading) return;
      
      // Use the catalog selected on this rule; fall back to the configured default
      const DYNAMIC_CATALOG = rule.catalog || config.catalog; 
      
      const fetchSchemas = async () => {
          setLoading(prev => ({ ...prev, schemas: true }));
          setError(null);
          try {
              // REPLACEMENT: Use DYNAMIC_CATALOG
              const response = await fetch(`${API_BASE_URL}/schema-meta?catalog=${DYNAMIC_CATALOG}`);
              if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
              const data = await response.json();
              const schemas = data.map(item => item.schema_name);
              setAvailableSchemas(schemas);
          } catch (e) {
              setError("Failed to load schemas. Please check the API endpoint.");
              console.error("Error fetching schemas:", e);
          } finally {
              setLoading(prev => ({ ...prev, schemas: false }));
          }
      };
      fetchSchemas();
  // DEPENDENCY ADDED: rule.catalog, config, configLoading
  }, [rule.catalog, config, configLoading]);

  useEffect(() => {
      // Wait until config is loaded
      if (!config || !rule.schema) return;
      
      const DYNAMIC_CATALOG = rule.catalog || config.catalog; 

      const fetchTables = async () => {
          setLoading(prev => ({ ...prev, tables: true }));
          setError(null);
          try {
              // REPLACEMENT: Use DYNAMIC_CATALOG
              const response = await fetch(`${API_BASE_URL}/table-meta?catalog=${DYNAMIC_CATALOG}&schema=${rule.schema}`);
              if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
              const data = await response.json();
              const tables = data.map(item => item.table_name);
              setAvailableTables(tables);
          } catch (e) {
              setError("Failed to load tables. Please check the API endpoint.");
              console.error("Error fetching tables:", e);
          } finally {
              setLoading(prev => ({ ...prev, tables: false }));
          }
      };
      fetchTables();
  // DEPENDENCY ADDED: config
  }, [rule.schema, rule.catalog, config]);

  useEffect(() => {
      // Wait until config is loaded
      if (!config || !rule.table) return;

      const DYNAMIC_CATALOG = rule.catalog || config.catalog;
      
      const fetchColumns = async () => {
          setLoading(prev => ({ ...prev, columns: true }));
          setError(null);
          try {
              // REPLACEMENT: Use DYNAMIC_CATALOG
              const response = await fetch(`${API_BASE_URL}/column-meta?catalog=${DYNAMIC_CATALOG}&schema=${rule.schema}&table=${rule.table}`);
              if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
              const data = await response.json();
              const columns = data.map(item => item.column_name);
              setAvailableColumns(columns);
          } catch (e) {
              setError("Failed to load columns. Please check the API endpoint.");
              console.error("Error fetching columns:", e);
          } finally {
              setLoading(prev => ({ ...prev, columns: false }));
          }
      };
      fetchColumns();
  // DEPENDENCY ADDED: config
  }, [rule.table, rule.schema, rule.catalog, config]);
  // --- ADD CONFIG LOADING/ERROR RENDER BLOCK ---
  // AFTER the three data-fetching useEffect blocks, REPLACE the entire conditional block (if (configLoading) { ... } if (error || !config || !config.catalog) { ... } ) with this:
  if (configLoading) {
      // Define a visibly distinct color for the skeleton background
      const SKELETON_COLOR = '#A9A9A9'; 

      return (
          <Box sx={{ mb: 4, border: "1px solid #e0e0e0", borderRadius: 2, p: 3 }}>
              <Grid container spacing={2}>
                  {[...Array(6)].map((_, index) => (
                      // Skeleton for the first six form fields (Catalog, Schema, Table, etc.)
                      <Grid item xs={12} md={4} key={index}>
                          {/* Applied bgcolor for strong contrast */}
                          <Skeleton 
                              variant="rectangular" 
                              height={36} 
                              animation="wave"
                              sx={{ bgcolor: SKELETON_COLOR }} 
                          />
                      </Grid>
                  ))}
                  
                  {/* Skeleton for the Rule Description textarea */}
                  <Grid item xs={12} md={4}>
                      {/* Applied bgcolor for strong contrast */}
                      <Skeleton 
                          variant="rectangular" 
                          height={100} 
                          sx={{ mt: 2, bgcolor: SKELETON_COLOR }} 
                          animation="wave" 
                      />
                  </Grid>
              </Grid>
          </Box>
      );
  }

    // --- CONDITIONAL RENDER: ERROR ---
    if (error || !config || !config.catalog) {
        return <Box sx={{ p: 3, color: 'error.main', border: "1px solid #e0e0e0", borderRadius: 2 }}>Error: Configuration data is missing or failed to load. {error}</Box>;
    }

    // --- MAIN RENDER ---
    const DYNAMIC_CATALOG = config.catalog;

  // if (configLoading) {
  //     return (
  //         <Box sx={{ p: 3, textAlign: 'center' }}>
  //             <CircularProgress size={24} />
  //             <Typography variant="body1" sx={{ ml: 2, display: 'inline' }}>Loading configuration...</Typography>
  //         </Box>
  //     );
  // }

  // if (error || !config || !config.catalog) {
  //     return <Box sx={{ p: 3, color: 'error.main' }}>Error: Configuration data is missing or failed to load. {error}</Box>;
  // }

  // // Define DYNAMIC_CATALOG here for use in the return block below
  // const DYNAMIC_CATALOG = config.catalog;

  const availableConditionTypes = rule.conditionCategory
    ? categoryToTypes[rule.conditionCategory] || []
    : [];
  // const isCustomTypeInput = rule.conditionCategory === "Business Logic Rules";
  // const effectiveConditionType =
  //   isCustomTypeInput || rule.conditionCategory === "KPI Statistics"
  //     ? "CUSTOM_RULE"
  //     : rule.conditionType;
  const isCustomTypeInput = rule.conditionCategory === "Business Logic Rules";
  const isKpiCheck = rule.conditionCategory === "KPI Statistics";

  // Effective type → decide what DynamicConditionFields should render
  const effectiveConditionType = isKpiCheck
    ? "KPI_CHECK"
    : isCustomTypeInput
    ? "CUSTOM_RULE"
    : rule.conditionType;


  return (
    <Box sx={{ mb: 4, border: "1px solid #e0e0e0", borderRadius: 2, p: 3 }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
        <Box fontWeight={600} fontSize={16}>Rule: {ruleNumber}</Box>
        {isCardView && (
          <IconButton size="small" onClick={() => onEdit(ruleNumber - 1)}>
            <EditIcon fontSize="small" />
          </IconButton>
        )}
      </Box>

      {!isCardView && (
        <>
          <Grid container spacing={2}>
            {/* ================= Left Column ================= */}
            <Grid size= {{xs:12, md:4}}>
              {/* Catalog */}
              <Box>
                <Autocomplete
                  options={availableCatalogs.length > 0 ? availableCatalogs : [DYNAMIC_CATALOG]}
                  value={rule.catalog || DYNAMIC_CATALOG}
                  disableClearable
                  loading={loading.catalogs}
                  onChange={(event, newValue) => handleChange("catalog", newValue)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Catalog"
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box>

              {/* Columns */}
              <Box mt={2}>
                <Autocomplete
                  multiple
                  options={availableColumns || []}
                  value={!rule.table || loading.columns ? [] : rule.columns}
                  getOptionLabel={(option) => option}
                  onChange={(event, newValue) => handleChange("columns", newValue)}
                  disabled={!rule.schema || !rule.table || loading.columns}
                  loading={loading.columns}
                  disableCloseOnSelect
                  renderTags={(selected) => {
                    const maxToShow = 2;
                    if (selected.length === 0) return '';
                    if (selected.length <= maxToShow) {
                      return <span style={{ marginLeft: 4 }}>{selected.join(', ')}</span>;
                    }
                    const displayed = selected.slice(0, maxToShow).join(', ');
                    const remaining = selected.length - maxToShow;
                    return <span style={{ marginLeft: 4 }}>{displayed} +{remaining}</span>;
                  }}
                  renderOption={(props, option, { selected }) => (
                    <li {...props}>
                      <Checkbox
                        style={{ marginRight: 8 }}
                        checked={selected}
                      />
                      <ListItemText primary={option} sx={{ fontSize: '0.85rem' }} />
                    </li>
                  )}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Columns"
                      size="small"
                      placeholder={!rule.schema
                        ? "Please select a schema"
                        : !rule.table
                        ? "Please select a table"
                        : "Select columns"}
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loading.columns && (
                              <Box sx={{ display: 'flex', alignItems: 'center', mr: 1 }}>
                                <CircularProgress color="inherit" size={20} />
                                <span style={{ marginLeft: 8 }}>Loading...</span>
                              </Box>
                            )}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box>

              {/* <Box mt={2}>
                <Autocomplete
                  multiple
                  options={availableColumns || []}
                  value={!rule.table || loading.columns ? [] : rule.columns}
                  getOptionLabel={(option) => option}
                  onChange={(event, newValue) => handleChange("columns", newValue)}
                  disabled={!rule.schema || !rule.table || loading.columns}
                  loading={loading.columns}
                  disableCloseOnSelect
                  renderTags={(selected) => {
                    const maxToShow = 2;
                    if (selected.length === 0) return '';
                    if (selected.length <= maxToShow) {
                      return selected.join(', ');
                    }
                    const displayed = selected.slice(0, maxToShow).join(', ');
                    const remaining = selected.length - maxToShow;
                    return `${displayed} +${remaining}`;
                  }}
                  renderOption={(props, option, { selected }) => (
                    <li {...props}>
                      <Checkbox
                        style={{ marginRight: 8 }}
                        checked={selected}
                      />
                      <ListItemText primary={option} sx={{ fontSize: '0.85rem' }} />
                    </li>
                  )}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Columns"
                      size="small"
                      placeholder={!rule.schema
                        ? "Please select a schema"
                        : !rule.table
                        ? "Please select a table"
                        : "Select columns"}
                      InputProps={{
                        ...params.InputProps,
                        sx: { paddingLeft: '12px' }, // ← adds left padding inside input
                        endAdornment: (
                          <>
                            {loading.columns && (
                              <Box sx={{ display: 'flex', alignItems: 'center', mr: 1 }}>
                                <CircularProgress color="inherit" size={20} />
                                <span style={{ marginLeft: 8 }}>Loading...</span>
                              </Box>
                            )}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box> */}



              {/* <Box mt={2}>
                <Autocomplete
                  multiple
                  options={availableColumns || []}
                  // The value array must contain the selected options
                  value={!rule.table || loading.columns ? [] : rule.columns}
                  // The options are strings, so getOptionLabel uses the option itself
                  getOptionLabel={(option) => option}
                  
                  onChange={(event, newValue) => handleChange("columns", newValue)}
                  loading={loading.columns}
                  disabled={!rule.table || loading.columns}
                  
                  // 💡 The key change is using renderOption to display checkboxes
                  renderOption={(props, option, { selected }) => (
                    <li {...props}>
                      <Checkbox
                        icon={icon}
                        checkedIcon={checkedIcon}
                        style={{ marginRight: 8 }}
                        checked={selected}
                      />
                      <ListItemText primary={option} />
                    </li>
                  )}
                  
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Columns"
                      size="small"
                      placeholder="Select columns"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loading.columns ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box> */}
              {/* <Box mt={2}>
                <Autocomplete
                  multiple
                  options={availableColumns || []}
                  value={!rule.table || loading.columns ? [] : rule.columns}
                  onChange={(event, newValue) => handleChange("columns", newValue)}
                  loading={loading.columns}
                  disabled={!rule.table || loading.columns}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Columns"
                      size="small"
                      placeholder="Select columns"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loading.columns ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box> */}

              {/* Rule Description */}
              <Box mt={2}>
                <textarea
                  value={rule.ruleDescription || ""}
                  onChange={(e) => handleChange("ruleDescription", e.target.value)}
                  placeholder="Enter Rule description"
                  rows={4}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    fontSize: '0.85rem',
                    borderRadius: '4px',
                    border: '1px solid rgba(0, 0, 0, 0.23)',
                    backgroundColor: '#fff',
                    fontFamily: 'Segoe UI, Helvetica, Arial, sans-serif',
                    boxSizing: 'border-box',
                    transition: 'border-color 0.2s, box-shadow 0.2s',
                    outline: 'none',
                    resize: 'none',
                    lineHeight: 1.2,
                    height: '96px',
                  }}
                  onFocus={(e) => {
                    e.target.style.border = '1px solid #1976d2';
                    e.target.style.boxShadow = '0 0 0 1px #1976d2';
                  }}
                  onBlur={(e) => {
                    e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </Box>

            </Grid>

            {/* ================= Middle Column ================= */}
            <Grid size= {{xs:12, md:4}}>
              {/* Schema */}
              <Box>
                <Autocomplete
                  options={availableSchemas}
                  value={rule.schema || null}
                  onChange={(event, newValue) => handleChange("schema", newValue || "")}
                  loading={loading.schemas}
                  disabled={loading.schemas}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Schema"
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loading.schemas ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box>

              {/* Condition Category */}
              <Box mt={2}>
                <Autocomplete
                  options={Object.keys(categoryToTypes)}
                  value={rule.conditionCategory || ""}
                  onChange={(event, newValue) => handleChange("conditionCategory", newValue || "")}
                  renderInput={(params) => (
                    <TextField {...params} required label="Condition Category" size="small" />
                  )}
                />
              </Box>

              {/* Severity */}
              <Box mt={2}>
                <Autocomplete
                  options={["Warning", "Critical"]}
                  value={rule.severity || ""}
                  onChange={(event, newValue) => handleChange("severity", newValue || "")}
                  renderInput={(params) => (
                    <TextField {...params} label="Severity" size="small" />
                  )}
                />
              </Box>

              {/* Threshold */}
              <Box mt={2}>
                <TextField
                  fullWidth
                  label="Threshold"
                  type="number"
                  value={rule.threshold || ""}
                  onChange={(e) => handleChange("threshold", e.target.value)}
                  size="small"
                />
              </Box>
            </Grid>

            {/* ================= Right Column ================= */}
            <Grid size= {{xs:12, md:4}}>
              {/* Table */}
              <Box>
                <Autocomplete
                  options={availableTables || []}
                  value={!rule.schema || loading.tables ? "" : rule.table}
                  onChange={(event, newValue) => handleChange("table", newValue || "")}
                  loading={loading.tables}
                  disabled={!rule.schema || loading.tables}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      label="Table"
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loading.tables ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                />
              </Box>

              {/* Condition Type */}
              <Box mt={2}>
                {(isCustomTypeInput || isKpiCheck) ? (
                  <TextField
                    required
                    fullWidth
                    size="small"
                    label="Condition Type (Custom Name)"
                    value={rule.conditionType || ""}
                    onChange={(e) => handleChange("conditionType", e.target.value)}
                    disabled={!rule.conditionCategory}
                  />
                ) : (
                  <Autocomplete
                    options={availableConditionTypes || []}
                    value={rule.conditionType || ""}
                    onChange={(event, newValue) => handleChange("conditionType", newValue || "")}
                    disabled={!rule.conditionCategory}
                    renderInput={(params) => (
                      <TextField {...params} required label="Condition Type" size="small" />
                    )}
                  />
                )}
              </Box>

              {/* Dynamic Fields */}
              <Box mt={2}>
                <DynamicConditionFields
                  category={rule.conditionCategory}
                  type={effectiveConditionType}
                  columns={availableColumns}
                  onCriteriaChange={(updatedCriteria) => {
                    const mergedCriteria = { ...rule.criteria, ...updatedCriteria };
                    handleChange("criteria", mergedCriteria);
                  }}
                />
              </Box>
            </Grid>
          </Grid>

        </>
      )}
    </Box>
  );
};

export default RuleForm;


