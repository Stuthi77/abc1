# server/app/RuleManagement/metadata_logic.py (Example file name)
import uuid
import time
import requests
import re
import os
import yaml
import json

# Import config assuming it is available in the Python path
from config import config 


# Load config.yaml
# Always point to server/config.yaml (one level up from app/)
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")
# Load config.yaml
try:
    with open(CONFIG_PATH, "r") as f:
        yaml_config = yaml.safe_load(f)
except FileNotFoundError:
    # Fallback/Error handling if config.yaml is not found at the expected path
    print(f"Warning: config.yaml not found at {CONFIG_PATH}. Using mock values.")
    yaml_config = {}

# Assign values
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
GROUPS_TABLE=yaml_config.get("group_table")
TABLES_TABLE=yaml_config.get("table_config")
# NOTE: Only the required tables are loaded, matching your configuration variables used in the functions below.


# --- HELPER FUNCTION FOR VALIDATING SQL IDENTIFIERS ---
def is_valid_identifier(name):
    """
    Checks if a string is a valid and safe SQL identifier.
    Prevents SQL injection by ensuring the string contains only 
    alphanumeric characters and underscores.
    """
    if not isinstance(name, str) or not name:
        return False
    # Regular expression to check for alphanumeric characters and underscores
    return re.match(r'^[a-zA-Z0-9_]+$', name) is not None


# --- CORE QUERY FUNCTION (Modified for Databricks Statement Execution API) ---
def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API, 
    waiting for results.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {"statement": query, "warehouse_id": config.SQL_WAREHOUSE_ID, "wait_timeout": "5s"}
    if params:
        payload["parameters"] = params
    
    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")
    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")
    
    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")
        
        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            columns = [col["name"] for col in manifest.get("schema", {}).get("columns", [])]
            data_array = status_json.get("result", {}).get("data_array", [])
            return [dict(zip(columns, row)) for row in data_array]
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
        
        time.sleep(1)


# --- GET METADATA FUNCTIONS ---
def get_catalogs():
    """
    Fetches ALL catalogs visible in this environment (that the app's
    token has permission to see), using SHOW CATALOGS.
    Internal/system catalogs are filtered out.
    """
    rows = query_table("get_catalogs", "SHOW CATALOGS")
    hidden = {"__databricks_internal", "system"}
    catalogs = [
        {"catalog_name": row["catalog"]}
        for row in rows
        if row.get("catalog") and row["catalog"] not in hidden
    ]
    return catalogs

def get_schemas(catalog_name):
    """Fetches schemas for a given catalog by dynamically injecting a validated catalog name."""
    if not is_valid_identifier(catalog_name):
        raise ValueError("Invalid catalog name provided.")
        
    query = f"""
        SELECT DISTINCT
            schema_name 
        FROM {catalog_name}.information_schema.schemata
        WHERE catalog_name = :catalog_name ORDER BY schema_name
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name}
    ]
    return query_table("get_schemas", query, params)

def get_tables(catalog_name, schema_name):
    """Fetches tables for a given catalog and schema by dynamically injecting validated names."""
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name):
        raise ValueError("Invalid catalog or schema name provided.")

    query = f"""
        SELECT DISTINCT
            table_name
        FROM {catalog_name}.information_schema.tables
        WHERE table_catalog = :catalog_name
        AND table_schema = :schema_name ORDER BY table_name
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name},
        {"name": "schema_name", "type": "STRING", "value": schema_name}
    ]
    return query_table("get_tables", query, params)

def get_columns(catalog_name, schema_name, table_name):
    """Fetches columns for a given catalog, schema, and table by dynamically injecting validated names."""
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name) or not is_valid_identifier(table_name):
        raise ValueError("Invalid catalog, schema, or table name provided.")

    query = f"""
        SELECT
            column_name,
            data_type
        FROM {catalog_name}.information_schema.columns
        WHERE table_catalog = :catalog_name
        AND table_schema = :schema_name
        AND table_name = :table_name ORDER BY ordinal_position
    """
    params = [
        {"name": "catalog_name", "type": "STRING", "value": catalog_name},
        {"name": "schema_name", "type": "STRING", "value": schema_name},
        {"name": "table_name", "type": "STRING", "value": table_name}
    ]
    return query_table("get_columns", query, params)


# # --- INSERT RULE FUNCTION (PARAMETERIZED) ---
# def insert_rule(data):
#     """
#     Inserts a new rule request into the rules table.
#     Uses globally loaded CONFIG variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE).
#     """
#     global CATALOG, SCHEMA, RULE_REQUESTS_TABLE
    
#     # Check if config is loaded
#     if not all([CATALOG, SCHEMA, RULE_REQUESTS_TABLE]):
#         raise Exception("Configuration variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE) are missing.")

#     # Generate a unique request_id
#     request_id = str(uuid.uuid4())
    
#     # Sanitize violation_threshold
#     violation_threshold = data.get("violation_threshold")
#     if not violation_threshold or str(violation_threshold).lower() in ('none', 'null', ''):
#         safe_threshold = None  # Will be inserted as NULL
#     else:
#         try:
#             safe_threshold = int(violation_threshold)  
#         except (ValueError, TypeError):
#             safe_threshold = None
    
#     # PARAMETERIZATION CHANGE: Table path is constructed using f-string
#     query = f"""
#         INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
#         (request_id, catalog, schema, table_name, column_name, rule_description,
#          status, created_by, created_at, condition_category,
#          condition_type, condition_criteria, operation, severity, violation_threshold)
#         VALUES (:request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
#                 'PENDING', :created_by, current_timestamp(),
#                 :condition_category, :condition_type, :condition_criteria,
#                 :operation, :severity, :violation_threshold)
#     """
    
#     params = [
#         {"name": "request_id", "type": "STRING", "value": request_id},
#         {"name": "catalog", "type": "STRING", "value": data["catalog"]},
#         {"name": "schema", "type": "STRING", "value": data["schema"]},
#         {"name": "table_name", "type": "STRING", "value": data["table_name"]},
#         {"name": "column_name", "type": "STRING", "value": data["column_name"]},
#         {"name": "rule_description", "type": "STRING", "value": data["rule_description"]},
#         {"name": "condition_category", "type": "STRING", "value": data["condition_category"]},
#         {"name": "condition_type", "type": "STRING", "value": data["condition_type"]},
#         {"name": "condition_criteria", "type": "STRING", "value": data["condition_criteria"]},
#         {"name": "operation", "type": "STRING", "value": data["operation"]},
#         {"name": "severity", "type": "STRING", "value": data["severity"]},
#         {"name": "violation_threshold", "type": "INT", "value": safe_threshold}, 
#         {"name": "created_by", "type": "STRING", "value": str(data["created_by"])}
#     ]
    
#     query_table("insert_rule", query, params)
    
#     return {"request_id": request_id}

# Assuming these global variables are defined elsewhere:
# CATALOG = "ds_training_1"
# SCHEMA = "dq_config"
# GROUPS_TABLE = "groups"
# TABLES_TABLE = "tables"

# --- NEW METADATA FUNCTION (PARAMETERIZED) ---
def get_group_id_by_name(group_name):
    """Fetches the group_id for a given group_name."""
    global CATALOG, SCHEMA, GROUPS_TABLE
    
    # Use f-strings to dynamically construct the table path
    query = f"""
        SELECT group_id
        FROM {CATALOG}.{SCHEMA}.{GROUPS_TABLE}
        WHERE group_name = :group_name
    """
    params = [
        {"name": "group_name", "type": "STRING", "value": group_name}
    ]
    
    result = query_table("get_group_id", query, params)
    
    if result and len(result) > 0:
        return result[0]['group_id']
    else:
        # Raise a specific error if the required group is missing
        raise ValueError(f"Approvers group '{group_name}' not found in {CATALOG}.{SCHEMA}.{GROUPS_TABLE}.")

# --- INSERT RULE HELPER (PARAMETERIZED) ---
def check_and_add_table_to_approvers(catalog, schema, table_name):
    """
    Checks if the table is in the 'Approvals' group and adds it if it's not.
    The group ID is dynamically fetched.
    """
    global CATALOG, SCHEMA, TABLES_TABLE
    
    # 1. Dynamically fetch the Group ID for 'Approvers'
    APPROVERS_GROUP_ID = get_group_id_by_name("Approvers")
    
    # 2. Check if the table is already linked to the Approvers group
    # Use f-strings to dynamically construct the table path
    check_query = f"""
        SELECT count(*) AS count
        FROM {CATALOG}.{SCHEMA}.{TABLES_TABLE}
        WHERE group_id = :group_id
          AND catalog_name = :catalog
          AND schema_name = :schema
          AND table_name = :table_name
    """
    check_params = [
        {"name": "group_id", "type": "STRING", "value": APPROVERS_GROUP_ID},
        {"name": "catalog", "type": "STRING", "value": catalog},
        {"name": "schema", "type": "STRING", "value": schema},
        {"name": "table_name", "type": "STRING", "value": table_name}
    ]
    
    # query_table returns a list of dictionaries for SELECT queries
    check_result = query_table("check_approvers_group", check_query, check_params)
    print(check_result)
    # Ensure result is valid and check the count
    count = check_result[0]['count'] if check_result and len(check_result) > 0 else 0
    print(count)
    if count == '0':
        # 3. If not found, insert the table into the Approvals group
        print(f"Adding table {catalog}.{schema}.{table_name} to Approvals group (ID: {APPROVERS_GROUP_ID}).")
        
        # Use f-strings to dynamically construct the table path
        insert_query = f"""
            INSERT INTO {CATALOG}.{SCHEMA}.{TABLES_TABLE}
            (group_id, catalog_name, schema_name, table_name)
            VALUES (:group_id, :catalog, :schema, :table_name)
        """
        insert_params = [
            {"name": "group_id", "type": "STRING", "value": APPROVERS_GROUP_ID},
            {"name": "catalog", "type": "STRING", "value": catalog},
            {"name": "schema", "type": "STRING", "value": schema},
            {"name": "table_name", "type": "STRING", "value": table_name}
        ]
        query_table("add_table_to_approvers_group", insert_query, insert_params)
        return True
    
    return False

def insert_rule(data):
    """
    Inserts a new rule request into the rules table and ensures the target 
    table is associated with the 'Approvals' group.
    Uses globally loaded CONFIG variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE).
    """
    global CATALOG, SCHEMA, RULE_REQUESTS_TABLE
    
    # Check if config is loaded
    if not all([CATALOG, SCHEMA, RULE_REQUESTS_TABLE]):
        raise Exception("Configuration variables (CATALOG, SCHEMA, RULE_REQUESTS_TABLE) are missing.")

    catalog_name = data["catalog"]
    schema_name = data["schema"]
    table_name = data["table_name"]
    
    # 1. Input Validation
    if not is_valid_identifier(catalog_name) or not is_valid_identifier(schema_name) or not is_valid_identifier(table_name):
        raise ValueError("Invalid catalog, schema, or table name provided.")

    # 2. Check and Add Table to Approvers Group
    table_added=check_and_add_table_to_approvers(catalog_name, schema_name, table_name)
    
    # 3. Insert the new rule request

    # Generate a unique request_id
    request_id = str(uuid.uuid4())
    
    # Sanitize violation_threshold to handle None/malformed strings gracefully
    violation_threshold = data.get("violation_threshold")
    safe_threshold = None
    if violation_threshold is not None:
        try:
            # Convert to int if possible, otherwise keep None (which results in NULL)
            safe_threshold = int(violation_threshold)
        except (ValueError, TypeError):
            # If conversion fails, safe_threshold remains None
            pass 
    
    # Enforcement action: how the execution engine should treat records that
    # fail this rule when moving bronze -> silver. Restricted to a known set
    # so a bad/missing value from an older client can't silently disable
    # filtering; default is the safer option (block bad records + audit).
    VALID_ENFORCEMENT_ACTIONS = ("BLOCK_AND_AUDIT", "AUDIT_ONLY")
    enforcement_action = data.get("enforcement_action")
    if enforcement_action not in VALID_ENFORCEMENT_ACTIONS:
        enforcement_action = "BLOCK_AND_AUDIT"

    # Email alert toggle: defaults to enabled so existing/omitted values keep
    # today's behavior (alerts fire for every violated rule).
    email_alert_enabled = bool(data.get("email_alert_enabled", True))

    # Optional per-rule alert group override.
    # group_id is a UUID (contains hyphens) — validate against that shape.
    alert_group_id = data.get("alert_group_id") or None
    if alert_group_id is not None and not re.fullmatch(r"[0-9a-fA-F\-]{8,36}", str(alert_group_id)):
        alert_group_id = None

    # PARAMETERIZATION: Table path is constructed using f-string
    query = f"""
        INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        (request_id, catalog, schema, table_name, column_name, rule_description,
         status, created_by, updated_by, created_at, condition_category,
         condition_type, condition_criteria, operation, severity, violation_threshold,
         enforcement_action, email_alert_enabled, alert_group_id)
        VALUES (:request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
                 'PENDING', :created_by, :updated_by, current_timestamp(),
                 :condition_category, :condition_type, :condition_criteria,
                 :operation, :severity, :violation_threshold, :enforcement_action,
                 :email_alert_enabled, :alert_group_id)
    """
    
    # Determine updated_by: prefer the value sent by the UI; fall back to
    # created_by for older clients (but never fall back to 'llm_generated',
    # since that is a system marker, not a real user).
    safe_updated_by = data.get("updated_by")
    if not safe_updated_by and str(data.get("created_by", "")) != "llm_generated":
        safe_updated_by = str(data["created_by"])

    params = [
        {"name": "request_id", "type": "STRING", "value": request_id},
        {"name": "catalog", "type": "STRING", "value": catalog_name},
        {"name": "schema", "type": "STRING", "value": schema_name},
        {"name": "table_name", "type": "STRING", "value": table_name},
        {"name": "column_name", "type": "STRING", "value": data["column_name"]},
        {"name": "rule_description", "type": "STRING", "value": data["rule_description"]},
        {"name": "condition_category", "type": "STRING", "value": data["condition_category"]},
        {"name": "condition_type", "type": "STRING", "value": data["condition_type"]},
        {"name": "condition_criteria", "type": "STRING", "value": data["condition_criteria"]},
        {"name": "operation", "type": "STRING", "value": data["operation"]},
        {"name": "severity", "type": "STRING", "value": data["severity"]},
        {"name": "violation_threshold", "type": "INT", "value": safe_threshold}, # Correctly passes Python None as SQL NULL
        {"name": "created_by", "type": "STRING", "value": str(data["created_by"])},
        # updated_by: the actual user submitting the request. Falls back to
        # created_by for older clients that don't send it (unless created_by
        # is the system marker 'llm_generated', in which case NULL).
        {"name": "updated_by", "type": "STRING", "value": safe_updated_by},
        {"name": "enforcement_action", "type": "STRING", "value": enforcement_action},
        {"name": "email_alert_enabled", "type": "BOOLEAN", "value": email_alert_enabled},
        {"name": "alert_group_id", "type": "STRING", "value": alert_group_id}
    ]
    
    query_table("insert_rule", query, params)
    
    return {"request_id": request_id,"table_added_to_approvers_group": table_added}