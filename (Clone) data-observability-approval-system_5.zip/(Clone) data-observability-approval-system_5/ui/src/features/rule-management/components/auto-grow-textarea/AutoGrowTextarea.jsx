import React, { useRef, useEffect } from "react";

// Shared auto-growing <textarea>. Uses a real useRef + useEffect keyed on
// `value` so the box correctly resizes whenever its content changes for
// ANY reason -- not just user typing, but also a value that arrives
// asynchronously after this component has already mounted (e.g. editing
// an existing rule, where the real description/SQL/criteria text often
// loads from an API call slightly after this textarea first renders).
//
// A callback ref (`ref={(el) => autoGrow(el)}`) only fires once, when the
// DOM node first mounts -- it does NOT re-fire when a later render passes
// a different `value` prop to the same node, so that approach silently
// left the box sized for whatever content existed at the very first
// render (often empty), never resizing once the real data arrived.
export default function AutoGrowTextarea({ value, onChange, style, minHeight = 84, ...rest }) {
  const textareaRef = useRef(null);

  const resize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.max(el.scrollHeight, minHeight)}px`;
  };

  useEffect(() => {
    resize();
  }, [value]);

  return (
    <textarea
      ref={textareaRef}
      value={value}
      onChange={(e) => {
        onChange(e);
        resize();
      }}
      style={style}
      {...rest}
    />
  );
}
