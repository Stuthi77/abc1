// import React, { useState, useEffect, useCallback , useRef } from 'react';
// import ApprovalCard from '../../components/approval-card/ApprovalCard';
// import Search from '../../../Shared/Components/Search/Search-Feature';

// import {
//   Box,
//   Button,
//   Chip,
//   Container,
//   Stack,
//   Typography,
//   Skeleton,
//   TextField,
//   Checkbox,
//   FormControlLabel,
//   InputAdornment,
// } from '@mui/material';
// import SearchIcon from '@mui/icons-material/Search';
// import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

// const CONTROL_H = 35;
// const SEARCH_W = 284;
// const itemsPerPage = 5;

// const StatusChips = ({ pending, approved, rejected }) => (
//   <Stack direction="row" spacing={2} mb={3}>
//     {[
//       { label: 'Pending', count: pending, color: '#1976d2' },
//       { label: 'Approved', count: approved, color: '#2e7d32' },
//       { label: 'Rejected', count: rejected, color: '#d32f2f' },
//     ].map(({ label, count, color }) => (
//       <Chip
//         key={label}
//         label={
//           <Typography sx={{ fontSize: '13px' }}>
//             <span style={{ fontWeight: 300 }}>{label}:</span>{' '}
//             <span style={{ color, fontWeight: 700 }}>{count}</span>
//           </Typography>
//         }
//         variant="outlined"
//         sx={{ borderColor: 'black', color: 'black', fontWeight: 'bold' }}
//       />
//     ))}
//   </Stack>
// );

// const ApprovalManagement = () => {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [openFilter, setOpenFilter] = useState(null);

//   // Filter search states
//   const [schemaSearch, setSchemaSearch] = useState('');
//   const [tableSearch, setTableSearch] = useState('');
//   const [ownerSearch, setOwnerSearch] = useState('');
//   const [operationSearch, setOperationSearch] = useState('');

//   const [selectedSchema, setSelectedSchema] = useState([]);
//   const [selectedOwner, setSelectedOwner] = useState([]);
//   const [selectedStatus, setSelectedStatus] = useState([]);
//   const [selectedTables, setSelectedTables] = useState([]);

//   const [statusCounts, setStatusCounts] = useState({ pending: 0, approved: 0, rejected: 0 });
//   const [totalStatusCounts, setTotalStatusCounts] = useState({ pending: 0, approved: 0, rejected: 0 });

//   const [currentPage, setCurrentPage] = useState(1);
//   const [totalItems, setTotalItems] = useState(0);

//   const [filterOptions, setFilterOptions] = useState({
//     user: [],
//     status: [],
//     table: [],
//     schema: []
//   });

//   // separate loading state for filters (not for cards)
//   const [loadingFilters, setLoadingFilters] = useState(true);
//   const [loadingContent, setLoadingContent] = useState(false);
//   const [isFilterUpdating, setIsFilterUpdating] = useState(false);

//   // Filter options with search and sorting
//   const getFilteredAndSortedOptions = (options, selected, searchTerm) => {
//     const filtered = options.filter(option =>
//       option.toLowerCase().includes(searchTerm.toLowerCase())
//     );
    
//     return filtered.sort((a, b) => {
//       const aSelected = selected.includes(a);
//       const bSelected = selected.includes(b);
      
//       if (aSelected && !bSelected) return -1;
//       if (!aSelected && bSelected) return 1;
//       return a.localeCompare(b);
//     });
//   };

//   const getDisplayText = (label, selected) => {
//     if (selected.length === 0) return label;
//     if (selected.length <= 2) {
//       return selected.join(', ');
//     }
//     return `${selected.length} selected`;
//   };

 
//   const FilterDropdown = ({ label, options, selected, onToggle, searchValue, onSearchChange, isFilterUpdating }) => {
    
//     const dropdownRef = useRef(null)
//     const isOpen = openFilter === label;

//     const handleClick = () => {
//       setOpenFilter(openFilter === label ? null : label);
//     };

//     const handleSearchChange = (e) => {
//       e.stopPropagation();
//       onSearchChange(e.target.value);
//     };

//     const handleToggle = (option) => {
//       onToggle(option);
//     };

//     const handleClose = () => {
//       setOpenFilter(null);
//       onSearchChange('');
//     };

//     // Add click outside handler
//     useEffect(() => {
//       const handleClickOutside = (event) => {
//         if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//           handleClose();
//         }
//       };

//       if (isOpen) {
//         document.addEventListener('mousedown', handleClickOutside);
//       }

//       return () => {
//         document.removeEventListener('mousedown', handleClickOutside);
//       };
//     }, [isOpen]);

//     const filteredOptions = getFilteredAndSortedOptions(options, selected, searchValue);

//     return (
//       <Box sx={{ position: 'relative' }} ref={dropdownRef}>
//         <Button
//           className="filter-btn"
//           onClick={handleClick}
//           disabled={isFilterUpdating}
//           sx={{
//             textTransform: 'none',
//             fontWeight: 400,
//             justifyContent: 'space-between',
//             padding: '6px 12px',
//             borderRadius: '4px',
//             border: '1px solid rgba(0, 0, 0, 0.23)',
//             backgroundColor: selected.length > 0 ? '#e3f2fd' : '#fff',
//             color: selected.length > 0 ? '#1976d2' : '#333',
//             opacity: isFilterUpdating ? 0.7 : 1,
//             '&:hover': {
//               backgroundColor: selected.length > 0 ? '#bbdefb' : '#f5f5f5',
//             },
//             minWidth: '155px',
//             maxWidth: '200px',
//             overflow: 'hidden',
//             whiteSpace: 'nowrap',
//             textOverflow: 'ellipsis',
//           }}
//         >
//           <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
//             {getDisplayText(label, selected)}
//           </span>
//           <ArrowDropDownIcon sx={{ fontSize: 18, ml: 0.5 }} />
//         </Button>

//         {isOpen && (
//           <Box
//             sx={{
//               position: 'absolute',
//               top: '100%',
//               left: 0,
//               zIndex: 1000,
//               mt: 0.5,
//               width: '159px',
//               maxHeight: '280px',
//               backgroundColor: 'white',
//               border: '1px solid #d0d0d0',
//               borderRadius: '6px',
//               boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
//               p: 1,
//             }}
//           >
//             <TextField
//               autoFocus
//               size="small"
//               placeholder="Search..."
//               value={searchValue}
//               onChange={handleSearchChange}
//               onKeyDown={(e) => e.stopPropagation()}
//               sx={{ width: '100%', mb: 1 }}
//               InputProps={{
//                 startAdornment: (
//                   <InputAdornment position="start">
//                     <SearchIcon sx={{ fontSize: '14px', color: '#6c757d' }} />
//                   </InputAdornment>
//                 ),
//               }}
//             />
//             <Box sx={{ maxHeight: 180, overflowY: 'auto' }}>
//               {filteredOptions.length === 0 ? (
//                 <Typography variant="body2" sx={{ p: 1, color: '#6c757d', fontSize: '0.75rem', textAlign: 'center' }}>
//                   No options
//                 </Typography>
//               ) : (
//                 filteredOptions.map((option) => (
//                   <FormControlLabel
//                     key={option}
//                     control={
//                       <Checkbox
//                         checked={selected.includes(option)}
//                         onChange={() => handleToggle(option)}
//                         size="small"
//                       />
//                     }
//                     label={option}
//                   />
//                 ))
//               )}
//             </Box>
//             {selected.length > 0 && (
//               <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid #e9ecef' }}>
//                 <Button size="small" onClick={() => selected.forEach(option => handleToggle(option))}>
//                   Clear All
//                 </Button>
//               </Box>
//             )}
//           </Box>
//         )}
//       </Box>
//     );
//   };

//   useEffect(() => {
//     const fetchFiltersAndCounts = async () => {
//       try {
//         // Only show skeleton loading on the very first load
//         if (loadingFilters) {
//           // Keep it as is for initial load
//         } else {
//           setIsFilterUpdating(true);
//         }
        
//         const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
 
//         // Build query params for filters
//         const queryParams = new URLSearchParams();
//         queryParams.append("groupId", userData.selectedGroupId);
//         selectedSchema.forEach(s => queryParams.append("schemas", s));
//         selectedTables.forEach(t => queryParams.append("tables", t));
//         selectedOwner.forEach(o => queryParams.append("owners", o));
//         selectedStatus.forEach(s => queryParams.append("statuses", s));
//         if (searchTerm) queryParams.append("search", searchTerm);
 
//         // Fetch both in parallel
//         const [filtersRes, countsRes] = await Promise.all([
//           fetch(`${import.meta.env.VITE_API_URL}/api/approval-filters?${queryParams}`),
//           fetch(`${import.meta.env.VITE_API_URL}/api/approval-counts?groupId=${userData.selectedGroupId}`)
//         ]);
 
//         if (!filtersRes.ok || !countsRes.ok) throw new Error("Network error");
 
//         const filtersData = await filtersRes.json();
//         const countsData = await countsRes.json();
 
//         setFilterOptions({
//           user: filtersData.owners || [],
//           status: filtersData.statuses || [],
//           table: filtersData.tables || [],
//           schema: filtersData.schemas || [],
//         });
 
//         setTotalStatusCounts(countsData);
 
//       } catch (error) {
//         console.error("Failed to fetch filters/counts:", error);
//         setFilterOptions({ user: [], status: [], table: [], schema: [] });
//         setTotalStatusCounts({ pending: 0, approved: 0, rejected: 0 });
//       } finally {
//         requestAnimationFrame(() => {
//           setLoadingFilters(false);
//           setIsFilterUpdating(false);
//         });
//       }
//     };
 
//     fetchFiltersAndCounts();
//   }, [selectedSchema, selectedTables, selectedOwner, selectedStatus, searchTerm]);


//   const toggleOwner = (o) => setSelectedOwner(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
//   const toggleOperations = (o) => setSelectedOperations(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
//   const toggleTable = (o) => setSelectedTables(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
//   const toggleSchema = (o) => setSelectedSchema(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);


//   const clearAllFilters = () => {
//     setSelectedSchema([]); setSelectedTables([]); setSelectedOwner([]); setSelectedStatus([]);
//     setCurrentPage(1);
//   };

//   const handleStatusCountsChange = useCallback((counts) => {
//     setStatusCounts(counts);
//   }, []);

//   const handleTotalItemsChange = useCallback((count) => {
//     setTotalItems(count);
//   }, []);

//   const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage));

//   useEffect(() => {
//     if (currentPage > totalPages) setCurrentPage(totalPages);
//   }, [currentPage, totalPages]);

//   useEffect(() => {
//     setCurrentPage(1);
//   }, [searchTerm, selectedSchema, selectedTables, selectedOwner, selectedStatus]);

//   return (
//     <Container maxWidth="lg" sx={{ py: 2 }}>
//       <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//         <Typography variant='h6'>Approval Management</Typography>
//         <StatusChips pending={totalStatusCounts.pending} approved={totalStatusCounts.approved} rejected={totalStatusCounts.rejected} />
//       </Box>

//       {/* Search + Filters Row */}
//       {loadingFilters ? (
//         <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'nowrap', width: '100%' }}>
//           <Skeleton variant="rectangular" width={SEARCH_W} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//           <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//           <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//           <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//           <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//           <Skeleton variant="rectangular" width={70} height={CONTROL_H} sx={{ borderRadius: 1 }} />
//         </Box>
//       ) : (
//         <Box
//           sx={{
//             display: 'flex',
//             alignItems: 'center',
//             gap: 1,
//             mb: 2,
//             flexWrap: 'nowrap',
//             width: '100%',
//             '& .filter-btn': { height: `${CONTROL_H}px`, display: 'flex', alignItems: 'center', minWidth: '159px' },
//           }}
//         >
//           <Box sx={{ width: SEARCH_W, flexShrink: 0 }}>
//             <Search
//               placeholder="Search Rules"
//               searchTerm={searchTerm}
//               setSearchTerm={setSearchTerm}
//               width="100%"
//               inputSx={{
//                 height: `${CONTROL_H}px`,
//                 '& .MuiInputBase-root': { height: `${CONTROL_H}px` },
//                 '& .MuiOutlinedInput-input': { paddingTop: '8px', paddingBottom: '8px' },
//               }}
//             />
//           </Box>

//           <FilterDropdown
//             label="Schema"
//             options={filterOptions.schema}
//             selected={selectedSchema}
//             onToggle={toggleSchema}
//             searchValue={schemaSearch}
//             onSearchChange={setSchemaSearch}
//             isFilterUpdating={isFilterUpdating}
//           />

//           <FilterDropdown
//             label="Table"
//             options={filterOptions.table}
//             selected={selectedTables}
//             onToggle={toggleTable}
//             searchValue={tableSearch}
//             onSearchChange={setTableSearch}
//             isFilterUpdating={isFilterUpdating}
//           />

//           <FilterDropdown
//             label="Owner"
//             options={filterOptions.user}
//             selected={selectedOwner}
//             onToggle={toggleOwner}
//             searchValue={ownerSearch}
//             onSearchChange={setOwnerSearch}
//             isFilterUpdating={isFilterUpdating}
//           />

//           <FilterDropdown
//             label="Status"
//             options={filterOptions.status}
//             selected={selectedStatus}
//             onToggle={toggleStatus}
//             searchValue={statusSearch}
//             onSearchChange={setStatusSearch}
//             isFilterUpdating={isFilterUpdating}
//           />

//           <Box sx={{ flexShrink: 0 }}>
//             <Button
//               sx={{
//                 textTransform: 'none',
//                 minWidth: '70px',
//                 fontWeight: 400,
//                 justifyContent: 'center',
//                 padding: '6px 12px',
//                 borderRadius: '4px',
//                 height: CONTROL_H,
//                 border: '1px solid rgba(0, 0, 0, 0.23)',
//                 cursor: 'pointer',
//                 backgroundColor: '#e0e0e0',
//                 color: '#333',
//                 '&:hover': { backgroundColor: '#616161', color: '#fff' },
//                 '&.Mui-disabled': {
//                   backgroundColor: '#f0f0f0',
//                   color: '#9e9e9e',
//                   border: '1px solid #e0e0e0',
//                   cursor: 'not-allowed',
//                 },
//               }}
//               onClick={clearAllFilters}
//               disabled={
//                 selectedSchema.length === 0 &&
//                 selectedStatus.length === 0 &&
//                 selectedTables.length === 0 &&
//                 selectedOwner.length === 0
//               }
//             >
//               Reset
//             </Button>
//           </Box>
//         </Box>
//       )}

//       {/* Approval Cards */}
//       <Box sx={{ minHeight: '55vh' }}>
//         <ApprovalCard
//           loading={loadingContent}
//           onStatusCountsChange={handleStatusCountsChange}
//           onTotalItemsChange={handleTotalItemsChange}
//           filters={{
//             searchTerm,
//             selectedSchema,
//             selectedTables,
//             selectedOwner,
//             selectedStatus,
//             currentPage,
//             itemsPerPage: itemsPerPage,
//           }}
//           pagination={{
//             currentPage,
//             totalPages,
//             onPageChange: setCurrentPage,
//           }}
//         />
//       </Box>
//     </Container>
//   );
// };

// export default ApprovalManagement;
import React, { useState, useEffect, useCallback , useRef } from 'react';
import ApprovalCard from '../../components/approval-card/ApprovalCard';
import Search from '../../../Shared/Components/Search/Search-Feature';

import {
  Box,
  Button,
  Chip,
  Container,
  Stack,
  Typography,
  Skeleton,
  TextField,
  Checkbox,
  FormControlLabel,
  InputAdornment,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

const CONTROL_H = 35;
const SEARCH_W = 284;
const itemsPerPage = 5;

// --- StatusChips Component (Unchanged) ---
const StatusChips = ({ pending, approved, rejected }) => (
  <Stack direction="row" spacing={2} mb={3}>
    {[
      { label: 'Pending', count: pending, color: '#1976d2' },
      { label: 'Approved', count: approved, color: '#2e7d32' },
      { label: 'Rejected', count: rejected, color: '#d32f2f' },
    ].map(({ label, count, color }) => (
      <Chip
        key={label}
        label={
          <Typography sx={{ fontSize: '13px' }}>
            <span style={{ fontWeight: 300 }}>{label}:</span>{' '}
            <span style={{ color, fontWeight: 700 }}>{count}</span>
          </Typography>
        }
        variant="outlined"
        sx={{ borderColor: 'black', color: 'black', fontWeight: 'bold' }}
      />
    ))}
  </Stack>
);

const ApprovalManagement = () => {
  
  // =========================================================
  // 1. STATE AND REF INITIALIZATION (ALL MOVED TO THE TOP)
  // =========================================================
  const [searchTerm, setSearchTerm] = useState('');
  const [openFilter, setOpenFilter] = useState(null);

  // Filter search states
  const [schemaSearch, setSchemaSearch] = useState('');
  const [tableSearch, setTableSearch] = useState('');
  const [ownerSearch, setOwnerSearch] = useState('');
  const [operationSearch, setOperationSearch] = useState('');

  // Filter selection states
  const [selectedSchema, setSelectedSchema] = useState([]);
  const [selectedOwner, setSelectedOwner] = useState([]);
  const [selectedOperations, setSelectedOperations] = useState([]);
  const [selectedTables, setSelectedTables] = useState([]);

  // Approval ID state (needed for API calls)
  const [approverGroupId, setApproverGroupId] = useState(null);

  // Count states
  const [statusCounts, setStatusCounts] = useState({ pending: 0, approved: 0, rejected: 0 });
  const [totalStatusCounts, setTotalStatusCounts] = useState({ pending: 0, approved: 0, rejected: 0 });

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // Filter options source
  const [filterOptions, setFilterOptions] = useState({
    user: [],
    operations: [],
    table: [],
    schema: []
  });

  // Loading states
  const [loadingFilters, setLoadingFilters] = useState(true);
  const [loadingContent, setLoadingContent] = useState(false);
  const [isFilterUpdating, setIsFilterUpdating] = useState(false);
  
  // =========================================================
  // 2. HELPER FUNCTIONS (DEPENDING ON STATE)
  // =========================================================

  const getFilteredAndSortedOptions = (options, selected, searchTerm) => {
    const safeOptions = options || [];
    const safeSelected = selected || [];
    const filtered = safeOptions.filter(option =>
      option.toLowerCase().includes((searchTerm || '').toLowerCase())
    );
    
    return filtered.sort((a, b) => {
      const aSelected = safeSelected.includes(a);
      const bSelected = safeSelected.includes(b);
      
      if (aSelected && !bSelected) return -1;
      if (!aSelected && bSelected) return 1;
      return a.localeCompare(b);
    });
  };

  const getDisplayText = (label, selected) => {
    if (selected.length === 0) return label;
    if (selected.length <= 2) {
      return selected.join(', ');
    }
    return `${selected.length} selected`;
  };

  const FilterDropdown = ({ label, options, selected, onToggle, searchValue, onSearchChange, isFilterUpdating }) => {
    
    const dropdownRef = useRef(null)
    const isOpen = openFilter === label;

    const handleClick = () => {
      setOpenFilter(openFilter === label ? null : label);
    };

    const handleSearchChange = (e) => {
      e.stopPropagation();
      onSearchChange(e.target.value);
    };

    const handleToggle = (option) => {
      onToggle(option);
    };

    const handleClose = () => {
      setOpenFilter(null);
      onSearchChange('');
    };

    // Add click outside handler
    useEffect(() => {
      const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
          handleClose();
        }
      };

      if (isOpen) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [isOpen]);

    const filteredOptions = getFilteredAndSortedOptions(options, selected, searchValue);

    return (
      <Box sx={{ position: 'relative' }} ref={dropdownRef}>
        <Button
          className="filter-btn"
          onClick={handleClick}
          disabled={isFilterUpdating}
          sx={{
            textTransform: 'none',
            fontWeight: 400,
            justifyContent: 'space-between',
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid rgba(0, 0, 0, 0.23)',
            backgroundColor: selected.length > 0 ? '#e3f2fd' : '#fff',
            color: selected.length > 0 ? '#1976d2' : '#333',
            opacity: isFilterUpdating ? 0.7 : 1,
            '&:hover': {
              backgroundColor: selected.length > 0 ? '#bbdefb' : '#f5f5f5',
            },
            minWidth: '155px',
            maxWidth: '200px',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
          }}
        >
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {getDisplayText(label, selected)}
          </span>
          <ArrowDropDownIcon sx={{ fontSize: 18, ml: 0.5 }} />
        </Button>

        {isOpen && (
          <Box
            sx={{
              position: 'absolute',
              top: '100%',
              left: 0,
              zIndex: 1000,
              mt: 0.5,
              width: '159px',
              maxHeight: '280px',
              backgroundColor: 'white',
              border: '1px solid #d0d0d0',
              borderRadius: '6px',
              boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
              p: 1,
            }}
          >
            <TextField
              autoFocus
              size="small"
              placeholder="Search..."
              value={searchValue}
              onChange={handleSearchChange}
              onKeyDown={(e) => e.stopPropagation()}
              sx={{ width: '100%', mb: 1 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ fontSize: '14px', color: '#6c757d' }} />
                  </InputAdornment>
                ),
              }}
            />
            <Box sx={{ maxHeight: 180, overflowY: 'auto' }}>
              {filteredOptions.length === 0 ? (
                <Typography variant="body2" sx={{ p: 1, color: '#6c757d', fontSize: '0.75rem', textAlign: 'center' }}>
                  No options
                </Typography>
              ) : (
                filteredOptions.map((option) => (
                  <FormControlLabel
                    key={option}
                    control={
                      <Checkbox
                        checked={selected.includes(option)}
                        onChange={() => handleToggle(option)}
                        size="small"
                      />
                    }
                    label={option}
                  />
                ))
              )}
            </Box>
            {selected.length > 0 && (
              <Box sx={{ mt: 1, pt: 1, borderTop: '1px solid #e9ecef' }}>
                <Button size="small" onClick={() => selected.forEach(option => handleToggle(option))}>
                  Clear All
                </Button>
              </Box>
            )}
          </Box>
        )}
      </Box>
    );
  };

  // =========================================================
  // 3. EFFECTS AND HANDLERS
  // =========================================================

  // Fetch the "Approvers" Group ID on component mount
  useEffect(() => {
    const fetchApproverGroupId = async () => {
      const userData = JSON.parse(sessionStorage.getItem("userData")) || {};
      
      try {
        const url = new URL(`${import.meta.env.VITE_API_URL}/api/groups`, window.location.origin);
        url.searchParams.append("user_id", userData.userId);

        const response = await fetch(url.toString());
        if (!response.ok) throw new Error("Failed to fetch groups list.");

        const allGroups = await response.json();
        
        // Find the group object named "Approvers"
        const approversGroup = allGroups.find(g => g.group_name === 'Approvers');
        
        if (approversGroup) {
          setApproverGroupId(approversGroup.group_id);
        } else {
          console.error("Critical Error: 'Approvers' group not found in the group list.");
        }
      } catch (error) {
        console.error("Error fetching Approvers group ID:", error);
      }
    };

    fetchApproverGroupId();
  }, []); // Run only on mount

  // Fetch Filters and Counts whenever filters or group ID change
  useEffect(() => {
    // Only run the fetch if we have the Approver Group ID
    if (!approverGroupId) return;

    const fetchFiltersAndCounts = async () => {
      try {
        if (loadingFilters) {
          // Initial load
        } else {
          setIsFilterUpdating(true);
        }
        
        const groupIdToUse = approverGroupId; 
        
        // Build query params for filters
        const queryParams = new URLSearchParams();
        queryParams.append("groupId", groupIdToUse); // <-- Use the fetched ID
        selectedSchema.forEach(s => queryParams.append("schemas", s));
        selectedTables.forEach(t => queryParams.append("tables", t));
        selectedOwner.forEach(o => queryParams.append("owners", o));
        selectedOperations.forEach(op => queryParams.append("operations", op));
        if (searchTerm) queryParams.append("search", searchTerm);
        
        // Fetch both in parallel
        const [filtersRes, countsRes] = await Promise.all([
          fetch(`${import.meta.env.VITE_API_URL}/api/approval-filters?${queryParams}`),
          fetch(`${import.meta.env.VITE_API_URL}/api/approval-counts?groupId=${groupIdToUse}`) // <-- Use the fetched ID
        ]);
        
        if (!filtersRes.ok || !countsRes.ok) throw new Error("Network error");
        
        const filtersData = await filtersRes.json();
        const countsData = await countsRes.json();
        
        setFilterOptions({
          user: filtersData.owners || [],
          operations: filtersData.operations || [],
          table: filtersData.tables || [],
          schema: filtersData.schemas || [],
        });
        
        setTotalStatusCounts(countsData);
        
      } catch (error) {
        console.error("Failed to fetch filters/counts:", error);
        setFilterOptions({ user: [], operations: [], table: [], schema: [] });
        setTotalStatusCounts({ pending: 0, approved: 0, rejected: 0 });
      } finally {
        requestAnimationFrame(() => {
          setLoadingFilters(false);
          setIsFilterUpdating(false);
        });
      }
    };
    
    fetchFiltersAndCounts();
  }, [approverGroupId, selectedSchema, selectedTables, selectedOwner, selectedOperations, searchTerm]);


  const toggleOwner = (o) => setSelectedOwner(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
  const toggleOperations = (o) => setSelectedOperations(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
  const toggleTable = (o) => setSelectedTables(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);
  const toggleSchema = (o) => setSelectedSchema(p => p.includes(o) ? p.filter(x => x !== o) : [...p, o]);


  const clearAllFilters = () => {
    setSelectedSchema([]); setSelectedTables([]); setSelectedOwner([]); setSelectedOperations([]);
    setCurrentPage(1);
  };

  const handleStatusCountsChange = useCallback((counts) => {
    setStatusCounts(counts);
  }, []);

  const handleTotalItemsChange = useCallback((count) => {
    setTotalItems(count);
  }, []);

  const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage));

  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages);
  }, [currentPage, totalPages]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedSchema, selectedTables, selectedOwner, selectedOperations]);

  // Disable content loading and filtering if we haven't found the Approver Group ID yet
  const isContentLoading = loadingContent || !approverGroupId;

  return (
    <Container maxWidth="lg" sx={{ py: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant='h6'>Approval Management</Typography>
        <StatusChips pending={totalStatusCounts.pending} approved={totalStatusCounts.approved} rejected={totalStatusCounts.rejected} />
      </Box>

      {/* Search + Filters Row */}
      {loadingFilters || !approverGroupId ? ( // Use !approverGroupId to block UI until ID is found
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexWrap: 'nowrap', width: '100%' }}>
          <Skeleton variant="rectangular" width={SEARCH_W} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={150} height={CONTROL_H} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={70} height={CONTROL_H} sx={{ borderRadius: 1 }} />
        </Box>
      ) : (
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            mb: 2,
            flexWrap: 'nowrap',
            width: '100%',
            '& .filter-btn': { height: `${CONTROL_H}px`, display: 'flex', alignItems: 'center', minWidth: '159px' },
          }}
        >
          <Box sx={{ width: SEARCH_W, flexShrink: 0 }}>
            <Search
              placeholder="Search Rules"
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              width="100%"
              inputSx={{
                height: `${CONTROL_H}px`,
                '& .MuiInputBase-root': { height: `${CONTROL_H}px` },
                '& .MuiOutlinedInput-input': { paddingTop: '8px', paddingBottom: '8px' },
              }}
            />
          </Box>

          <FilterDropdown
            label="Schema"
            options={filterOptions.schema}
            selected={selectedSchema}
            onToggle={toggleSchema}
            searchValue={schemaSearch}
            onSearchChange={setSchemaSearch}
            isFilterUpdating={isFilterUpdating}
          />

          <FilterDropdown
            label="Table"
            options={filterOptions.table}
            selected={selectedTables}
            onToggle={toggleTable}
            searchValue={tableSearch}
            onSearchChange={setTableSearch}
            isFilterUpdating={isFilterUpdating}
          />

          <FilterDropdown
            label="Owner"
            options={filterOptions.user}
            selected={selectedOwner}
            onToggle={toggleOwner}
            searchValue={ownerSearch}
            onSearchChange={setOwnerSearch}
            isFilterUpdating={isFilterUpdating}
          />

          <FilterDropdown
            label="Operation"
            options={filterOptions.operations}
            selected={selectedOperations}
            onToggle={toggleOperations}
            searchValue={operationSearch}
            onSearchChange={setOperationSearch}
            isFilterUpdating={isFilterUpdating}
          />

          <Box sx={{ flexShrink: 0 }}>
            <Button
              sx={{
                textTransform: 'none',
                minWidth: '70px',
                fontWeight: 400,
                justifyContent: 'center',
                padding: '6px 12px',
                borderRadius: '4px',
                height: CONTROL_H,
                border: '1px solid rgba(0, 0, 0, 0.23)',
                cursor: 'pointer',
                backgroundColor: '#e0e0e0',
                color: '#333',
                '&:hover': { backgroundColor: '#616161', color: '#fff' },
                '&.Mui-disabled': {
                  backgroundColor: '#f0f0f0',
                  color: '#9e9e9e',
                  border: '1px solid #e0e0e0',
                  cursor: 'not-allowed',
                },
              }}
              onClick={clearAllFilters}
              disabled={
                selectedSchema.length === 0 &&
                selectedOperations.length === 0 &&
                selectedTables.length === 0 &&
                selectedOwner.length === 0
              }
            >
              Reset
            </Button>
          </Box>
        </Box>
      )}

      {/* Approval Cards */}
      <Box sx={{ minHeight: '55vh' }}>
        {/* Render ApprovalCard only if we have the Approver Group ID */}
        {approverGroupId ? (
          <ApprovalCard
            loading={isContentLoading}
            onStatusCountsChange={handleStatusCountsChange}
            onTotalItemsChange={handleTotalItemsChange}
            filters={{
              groupId: approverGroupId, // Pass the correct ID
              searchTerm,
              selectedSchema,
              selectedTables,
              selectedOwner,
              selectedOperations,
              currentPage,
              itemsPerPage: itemsPerPage,
            }}
            pagination={{
              currentPage,
              totalPages,
              onPageChange: setCurrentPage,
            }}
          />
        ) : (
          // Fallback loading state if ID is not found yet
          !loadingFilters && (
            <Typography color="error" sx={{ mt: 4, textAlign: 'center' }}>
              Error: Could not find the Approvers group ID or network issue.
            </Typography>
          )
        )}
      </Box>
    </Container>
  );
};

export default ApprovalManagement;