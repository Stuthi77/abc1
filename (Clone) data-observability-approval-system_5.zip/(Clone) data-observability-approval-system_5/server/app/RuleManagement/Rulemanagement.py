

from flask import Flask, jsonify, request, Blueprint
from .Rule_management_logic import get_tables_data, get_filters_data,get_rules_for_table_data,get_active_or_inactive_rules_for_table,get_filters_for_table,get_rule_details,insert_rule_request,delete_rule_data,submit_delete_request,get_columns_for_rule_from_info_schema
RuleManagement_bp = Blueprint("RuleManagement", __name__)




@RuleManagement_bp.route("/api/table_rule_cards", methods=['GET'])
def api_get_tables():
    try:
        data = get_tables_data(**request.args)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
   




@RuleManagement_bp.route("/api/rulemanagement_filters", methods=['GET'])
def api_get_filters():
    try:
        group_id = request.args.get('group_id')
        data = get_filters_data(group_id)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
   


   
# Changed from <int:tableId> to <string:tableId>
@RuleManagement_bp.route("/api/tables/<string:tableId>/approved_rules", methods=['GET'])
def api_get_rules_for_table(tableId):
    try:
        data = get_rules_for_table_data(tableId, **request.args)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500




# Changed from <int:tableId> to <string:tableId>
@RuleManagement_bp.route("/api/tables/<string:tableId>/rules", methods=['GET'])
def api_get_status_wise_rules(tableId):
    try:
        data = get_active_or_inactive_rules_for_table(tableId, **request.args)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500




# Changed from <int:tableId> to <string:tableId>
@RuleManagement_bp.route("/api/tables/<string:tableId>/filters", methods=['GET'])
def api_get_filters_for_table(tableId):
    """Handles requests for filter options for a specific table."""
    try:
        data = get_filters_for_table(tableId)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500




   
@RuleManagement_bp.route("/api/rules/<ruleId>", methods=['GET'])
def api_get_rule_details(ruleId):
    """Endpoint for a single rule's expanded details."""
    try:
        # Try casting to int if possible
        if ruleId.isdigit():
            ruleId_casted = int(ruleId)
        else:
            ruleId_casted = ruleId  # keep as string


        data = get_rule_details(ruleId_casted)


        if data:
            return jsonify(data)
        else:
            return jsonify({"error": f"Rule with ID {ruleId} not found."}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500




@RuleManagement_bp.route("/api/columns/<string:rule_id>", methods=['GET'])
def api_get_columns_for_rule(rule_id):
    try:
        if not rule_id:
            return jsonify({"error": "rule_id is required"}), 400
           
        # Call the new function that uses information_schema
        columns = get_columns_for_rule_from_info_schema(rule_id)
        return jsonify(columns)
       
    except Exception as e:
        return jsonify({"error": str(e)}), 500




# @RuleManagement_bp.route("/api/rules/<ruleId>", methods=['PUT'])
# def api_update_rule(ruleId):
#     update_data = request.get_json()
#     try:
#         # Try to convert to int if possible, else keep as string
#         try:
#             ruleId_val = int(ruleId)
#         except ValueError:
#             ruleId_val = ruleId


#         update_rule_data(ruleId_val, update_data)
#         return jsonify({"status": "success", "message": f"Rule {ruleId} updated."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500




# @RuleManagement_bp.route("/api/rules/<ruleId>", methods=['PUT'])
# def api_update_rule(ruleId):
#     update_data = request.get_json()
#     try:
#         # Always treat ruleId as string
#         update_rule_data(ruleId, update_data)
#         return jsonify({"status": "success", "message": f"Rule {ruleId} updated."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500




# @RuleManagement_bp.route("/api/rules/<ruleId>", methods=['DELETE'])
# def api_delete_rule(ruleId):
#     try:
#         try:
#             ruleId_val = int(ruleId)
#         except ValueError:
#             ruleId_val = ruleId


#         delete_rule_data(ruleId_val)
#         return jsonify({"status": "success", "message": f"Rule {ruleId} deleted."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


@RuleManagement_bp.route("/api/rules/<ruleId>/save_request", methods=['POST'])
def api_save_rule_request(ruleId):
    try:
        data = request.get_json()
        
        # Build popup_data directly from frontend; overwrite any original values
        popup_data = {
            "column_name": data.get("column_name"),
            "rule_description": data.get("rule_description"),
            "severity": data.get("severity"),
            "violation_threshold": data.get("violation_threshold"),
            "condition_criteria": data.get("condition_criteria")
        }

        # Just insert using the new values; no merging
        result = insert_rule_request(ruleId, popup_data, data)
        return jsonify({"message": "Rule request saved successfully", "result": result}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500



@RuleManagement_bp.route("/api/rules/<ruleId>", methods=['DELETE'])
def api_delete_rule(ruleId):
    try:
        # NEW: deleting an active rule now requires approval -- this submits
        # a pending request instead of deleting immediately. See
        # submit_delete_request() and Approval_logic.py's DELETE branch.
        body = request.get_json(silent=True) or {}
        requested_by = body.get("requested_by")
        result = submit_delete_request(ruleId, requested_by)
        return jsonify({
            "status": "pending_approval",
            "message": f"Delete request submitted for rule {ruleId}. It will remain active until an approver reviews this request.",
            "result": result
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

