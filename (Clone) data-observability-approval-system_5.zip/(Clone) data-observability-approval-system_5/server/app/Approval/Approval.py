from flask import Flask, jsonify, request, Blueprint
# Correctly import from the logic file in the same directory
from .Approval_logic import get_approval_data,get_filter,approve_rule_request,reject_rule_request,revert_rule_request,get_approval_status_counts,update_pending_rule_request

Approval_bp=Blueprint("Approval",__name__)
app = Flask(__name__)

# @app.route("/api/approval", methods=['GET'])
# def api_get_approval_details():
#     try:
#         data = get_approval_data(**request.args)
#         return jsonify(data)
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

@Approval_bp.route("/api/approval-counts", methods=['GET'])
def api_get_approval_counts():
    try:
        # Get groupId from the request as a single optional parameter
        groupId = request.args.get('groupId')

        # Pass the groupId to the data function
        counts = get_approval_status_counts(groupId=groupId)
        
        return jsonify(counts)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@Approval_bp.route("/api/approval", methods=['GET'])
def api_get_approval_details():
    try:
        # Use .getlist() to handle multiple selections for each filter
        search = request.args.get('search')
        schemas = request.args.getlist('schemas')
        tables = request.args.getlist('tables')
        owners = request.args.getlist('owners')
        operations = request.args.getlist('operations')
        groupId = request.args.get('groupId')

        # Pass the lists to the logic function
        data, total_count = get_approval_data(
            search=search, 
            schemas=schemas, 
            tables=tables, 
            owners=owners, 
            operations=operations,
            groupId = groupId,
            page=int(request.args.get('page', 1)), 
            limit=int(request.args.get('limit', 10))
        )
        return jsonify({
            "totalCount": total_count,
            "items": data
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
# @Approval_bp.route("/api/approval-filters", methods=['GET'])
# def api_get_filters():
#     try:
#         groupId = request.args.get('groupId')
#         data = get_filter(groupId=groupId)
#         return jsonify(data)
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# @Approval_bp.route("/api/approval-filters", methods=['GET'])
# def api_get_filters():
#     try:
#         groupId = request.args.get('groupId')
#         # Collect filter params from request
#         schemas = request.args.getlist('schemas')
#         tables = request.args.getlist('tables')
#         owners = request.args.getlist('owners')
#         statuses = request.args.getlist('statuses')
#         search = request.args.get('search')
#         # groupId = request.args.get('groupId')

#         # Pass them to your filter logic
#         data = get_filter(
#             groupId=groupId,
#             schemas=schemas,
#             tables=tables,
#             owners=owners,
#             statuses=statuses,
#             search=search
            
#         )

#         return jsonify(data)
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


@Approval_bp.route("/api/approval-filters", methods=['GET'])
def api_get_filters():
    try:
        groupId = request.args.get('groupId')
        # Collect filter params from request
        schemas = request.args.getlist('schemas')
        tables = request.args.getlist('tables')
        owners = request.args.getlist('owners')
        operations = request.args.getlist('operations')
        search = request.args.get('search')
        # groupId = request.args.get('groupId')


        # Pass them to your filter logic
        data = get_filter(
            groupId=groupId,
            schemas=schemas,
            tables=tables,
            owners=owners,
            operations=operations,
            search=search
           
        )

        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


    
@Approval_bp.route("/api/approval/approve_rule", methods=['POST'])
def api_approve_rule():
    try:
        # Get the JSON data from the request body
        body = request.get_json()
        request_id = body.get("request_id")
        # Use a default value if approved_by is not provided
        approved_by = body.get("approved_by", "system")

        if not request_id:
            # Return an error if request_id is missing
            return jsonify({"error": "request_id is required"}), 400

        # Call the core logic function to handle the database operations
        # The variables from the request are correctly passed as arguments
        result = approve_rule_request(request_id, approved_by)

        # Return a success response
        return jsonify(result), 200

    except Exception as e:
        # Return a clear error response if anything fails
        return jsonify({"error": str(e)}), 500



@Approval_bp.route("/api/approval/reject_rule", methods=['POST'])
def api_reject_rule():
    try:
        # Get the JSON data from the request body
        body = request.get_json()
        request_id = body.get("request_id")
        rejected_by = body.get("request_by")
        reason = body.get("reason")

        if not request_id:
            # Return an error if request_id is missing
            return jsonify({"error": "request_id is required"}), 400

        # Call the core logic function (rejected_by, review_comments will be NULL by default)
        result = reject_rule_request(request_id, rejected_by , reason )

        # Return a success response
        return jsonify(result), 200

    except Exception as e:
        # Return a clear error response if anything fails
        return jsonify({"error": str(e)}), 500


@Approval_bp.route("/api/approval/update_request", methods=['POST'])
def api_update_pending_rule_request():
    """
    NEW: lets the originator modify a still-pending request's fields
    (e.g. condition_criteria, severity, threshold, description) prior to
    approval, instead of having to reject it and re-enter everything
    from scratch.
    """
    try:
        body = request.get_json() or {}
        request_id = body.get("request_id")
        updated_by = body.get("updated_by")
        updated_fields = body.get("updated_fields") or {}

        if not request_id:
            return jsonify({"error": "request_id is required"}), 400
        if not updated_fields:
            return jsonify({"error": "updated_fields is required and must be non-empty"}), 400

        result = update_pending_rule_request(request_id, updated_fields, updated_by)
        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@Approval_bp.route("/api/revert_rule", methods=['POST'])
def api_revert_rule():
    try:
        body = request.get_json()
        request_id = body.get("request_id")
        reverted_by = body.get("reverted_by", "system")

        if not request_id:
            return jsonify({"error": "request_id is required"}), 400

        result = revert_rule_request(request_id, reverted_by)
        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500