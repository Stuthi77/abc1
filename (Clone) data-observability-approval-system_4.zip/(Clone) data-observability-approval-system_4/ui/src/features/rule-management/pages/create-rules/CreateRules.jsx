import React, { useState, useEffect } from "react";
import { 
    Box, Button, Container, IconButton, Typography, Snackbar, Alert, 
    CircularProgress, Grid, Skeleton, // <--- Import Grid and Skeleton
    Dialog, DialogTitle, DialogContent, DialogActions, List, ListItem, ListItemText,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate } from "react-router-dom";
import RuleForm from "../rule-form/RuleForm";
import AddedRuleCard from "../../components/added-rule-card/AddedRuleCard";
import LLMRecommendationSection from "../../components/llm-recommendation/LLMRecommendationSection";
import Glossary from "../glossary/Glossary";
import "./CreateRules.css";

// Define the API URL using the Vite environment variable
const API_BASE_URL = import.meta.env.VITE_API_URL;
const API_CONFIG_URL = `${API_BASE_URL}/api/frontend/config`; 
const MIN_LOAD_TIME = 300; // Minimum time in milliseconds to show loading state

const CreateRules = () => {
    const navigate = useNavigate();
    
    const [config, setConfig] = useState(null);
    const [configLoading, setConfigLoading] = useState(true);
    
    const [openGlossary, setOpenGlossary] = useState(false);
    const [rules, setRules] = useState([]);
    const [cardViews, setCardViews] = useState([]);
    const [snackbarState, setSnackbarState] = useState({
        open: false,
        message: '',
        severity: 'success',
    });
    const [loading, setLoading] = useState(false);

    // NEW: Bulk CSV upload state
    const [csvUploading, setCsvUploading] = useState(false);
    const [csvResultOpen, setCsvResultOpen] = useState(false);
    const [csvResult, setCsvResult] = useState(null);
    const [csvError, setCsvError] = useState('');

    // --- EFFECT HOOK TO FETCH CONFIGURATION ---
    useEffect(() => {
        const fetchConfig = async () => {
            const [responseResult] = await Promise.all([
                (async () => {
                    const response = await fetch(API_CONFIG_URL);
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })(),
                new Promise(resolve => setTimeout(resolve, MIN_LOAD_TIME)) 
            ]);

            try {
                const data = responseResult;

                setConfig(data);
                
                const initialCatalog = data.catalog || "";
                const newInitialRule = {
                    catalog: initialCatalog,
                    schema: "",
                    table: "",
                    columns: [],
                    conditionCategory: "",
                    conditionType: "",
                    ruleDescription: "",
                    severity: "",
                    threshold: "",
                    enforcementAction: "BLOCK_AND_AUDIT",
                    emailAlertEnabled: true,
                    alertGroupId: "",
                    criteria: {},
                };
                setRules([newInitialRule]);
                setCardViews([false]);

            } catch (error) {
                console.error("Configuration fetch failed:", error);
                setSnackbarState({
                    open: true,
                    message: `Failed to load app configuration: ${error.message}`,
                    severity: 'error',
                });
            } finally {
                setConfigLoading(false);
            }
        };

        fetchConfig();
    }, []); 
    // ------------------------------------------

    // --- START: LOADING RENDER BLOCK (SKELETON) ---
    if (configLoading) {
        return (
            <Container maxWidth="lg">
                <Box className="create-rule-container" mt={2} p={3}>
                    {/* Header Placeholder (Add Rules Title + Glossary Button) */}
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                        <Skeleton variant="text" width={120} height={32} />
                        <Skeleton variant="rectangular" width={80} height={32} sx={{ borderRadius: 1 }} />
                    </Box>

                    {/* RuleForm Placeholder (The main card structure) */}
                    <Box sx={{ mb: 4, border: "1px solid #e0e0e0", borderRadius: 2, p: 3 }}>
                        <Grid container spacing={2}>
                            {/* Mimic the 3-column layout */}
                            {[...Array(9)].map((_, index) => (
                                <Grid item xs={12} md={4} key={index}>
                                    <Skeleton variant="rectangular" height={36} animation="wave" />
                                </Grid>
                            ))}
                            {/* Mimic the Rule Description textarea (longer height) */}
                            <Grid item xs={12} md={4}>
                                <Skeleton variant="rectangular" height={100} animation="wave" />
                            </Grid>
                        </Grid>
                    </Box>
                    
                    {/* Add Rule Button Placeholder */}
                    <Skeleton variant="rectangular" width={100} height={36} sx={{ borderRadius: 1 }} />

                    {/* Submit Button Placeholder (Fixed Position) */}
                    <Box sx={{ position: "fixed", bottom: 20, right: 30 }}>
                        <Skeleton variant="rectangular" width={120} height={40} sx={{ borderRadius: 1 }} />
                    </Box>
                </Box>
            </Container>
        );
    }
    // --- END: LOADING RENDER BLOCK ---

    // Now we can use the dynamic catalog name
    const DYNAMIC_CATALOG = config.catalog;


    const handleRuleChange = (index, updatedRule) => {
        const newRules = [...rules];
        newRules[index] = updatedRule;
        setRules(newRules);
    };

    const handleAddRule = () => {
        setRules([...rules, {
            catalog: DYNAMIC_CATALOG,
            schema: "",
            table: "",
            columns: [],
            conditionCategory: "",
            conditionType: "",
            ruleDescription: "",
            severity: "",
            threshold: "",
            enforcementAction: "BLOCK_AND_AUDIT",
            emailAlertEnabled: true,
            alertGroupId: "",
            criteria: {},
        }]);
        setCardViews([...cardViews, false]);
    };

    // Called by the LLM Recommendation section with rules already mapped
    // to the RuleForm shape. If the only existing rule is a blank untouched
    // form, replace it; otherwise append. New rules show as cards for review.
    const handleAddGeneratedRules = (generatedRules) => {
        if (!generatedRules || generatedRules.length === 0) return;

        setRules(prevRules => {
            const isBlank = (r) =>
                !r.schema && !r.table && r.columns.length === 0 &&
                !r.conditionCategory && !r.conditionType;

            const keep = (prevRules.length === 1 && isBlank(prevRules[0])) ? [] : prevRules;
            const merged = [...keep, ...generatedRules];

            setCardViews(prevViews => {
                const keepViews = (prevRules.length === 1 && isBlank(prevRules[0]))
                    ? [] : prevViews;
                return [...keepViews, ...generatedRules.map(() => true)];
            });

            return merged;
        });

        setSnackbarState({
            open: true,
            message: `${generatedRules.length} LLM-recommended rule(s) added below. Review and click Submit.`,
            severity: 'success',
        });
    };

    const toggleCardView = (index) => {
        const newViews = [...cardViews];
        newViews[index] = !newViews[index];
        setCardViews(newViews);
    };

    const editRule = (index) => {
        const newViews = [...cardViews];
        newViews[index] = false;
        setCardViews(newViews);
    };

    const handleDeleteRule = (index) => {
        const newRules = rules.filter((_, i) => i !== index);
        const newViews = cardViews.filter((_, i) => i !== index);
        setRules(newRules);
        setCardViews(newViews);
    };

    const handleCloseSnackbar = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackbarState({ ...snackbarState, open: false });
    };

    const validateRules = () => {
        for (const rule of rules) {
            if (!rule.catalog || !rule.schema || !rule.table || rule.columns.length === 0 || !rule.conditionCategory || !rule.conditionType) {
                return false;
            }
        }
        return true;
    };

    const handleSubmit = () => {
        if (!validateRules()) {
            setSnackbarState({
                open: true,
                message: 'Please fill all mandatory fields for all rules.',
                severity: 'error',
            });
            return;
        }
        const userDetailsString = sessionStorage.getItem('userData');
        const userDetails = userDetailsString ? JSON.parse(userDetailsString) : { email: 'default_user@example.com' };

        setLoading(true);

        // const payload = rules.map(rule => {
        //     let criteriaPayload;

        //     if (rule.criteria && rule.criteria.custom_query) {
        //         criteriaPayload = JSON.stringify({ custom_query: rule.criteria.custom_query });
        //     } else if (Object.keys(rule.criteria).length === 0) {
        //         criteriaPayload = null;
        //     } else {
        //         criteriaPayload = JSON.stringify(rule.criteria);
        //     }
            
        //     const violationThresholdValue = 
        //         (rule.threshold === "" || rule.threshold === null)
        //             ? null
        //             : String(rule.threshold);

        //     return {
        //         catalog: rule.catalog,
        //         schema: rule.schema,
        //         table_name: rule.table,
        //         column_name: rule.columns.join(","),
        //         rule_description: rule.ruleDescription,
        //         created_by: userDetails.email,
        //         condition_category: rule.conditionCategory,
        //         condition_type: rule.conditionType,
        //         condition_criteria: criteriaPayload, 

        //         operation: "CREATE",
        //         severity: rule.severity || "Warning",
        //         violation_threshold: violationThresholdValue,
        //     };
        // });
        const payload = rules.map(rule => {
            const criteriaPayload = 
                Object.keys(rule.criteria || {}).length === 0 ? null : JSON.stringify(rule.criteria);

            const violationThresholdValue = 
                (rule.threshold === "" || rule.threshold === null)
                    ? null
                    : String(rule.threshold);

            // LLM-generated rules are tagged with source: "llm_generated"
            // by the LLM Recommendation section. Manual rules have no tag.
            const isLLMGenerated = rule.source === "llm_generated";

            return {
                catalog: rule.catalog,
                schema: rule.schema,
                table_name: rule.table,
                column_name: rule.columns.join(","),
                rule_description: rule.ruleDescription,
                created_by: isLLMGenerated ? "llm_generated" : userDetails.email,
                updated_by: userDetails.email,
                condition_category: rule.conditionCategory,
                condition_type: rule.conditionType,
                condition_criteria: criteriaPayload,
                operation: "CREATE",
                severity: rule.severity || "Warning",
                violation_threshold: violationThresholdValue,
                enforcement_action: rule.enforcementAction || "BLOCK_AND_AUDIT",
                email_alert_enabled: rule.emailAlertEnabled !== false,
                alert_group_id: rule.alertGroupId || null,
            };
        });

        console.log("Submitting payload:", payload);

        fetch(`${API_BASE_URL}/api/rules/add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        })
            .then(async res => {
                if (!res.ok) {
                    const errorData = await res.json().catch(() => ({ 
                        message: `HTTP error ${res.status}: Failed to process rule request.` 
                    }));
                    throw new Error(errorData.message || 'Unknown error occurred on the server.');
                }
                return res.json();
            })
            .then(data => {
                console.log("Rules saved:", data);
                // Reset form state on successful submission
                setRules([{
                    catalog: DYNAMIC_CATALOG,
                    schema: "",
                    table: "",
                    columns: [],
                    conditionCategory: "",
                    conditionType: "",
                    ruleDescription: "",
                    severity: "",
                    threshold: "",
                    enforcementAction: "BLOCK_AND_AUDIT",
                    emailAlertEnabled: true,
                    alertGroupId: "",
                    criteria: {},
                    created_by: ""
                }]);
                setCardViews([false]);
                setSnackbarState({
                    open: true,
                    message: 'Rule request submitted successfully!',
                    severity: 'success',
                });
            })
            .catch(error => {
                const errorMessage = error.message || 'Failed to submit rule request.';
                
                setSnackbarState({
                    open: true,
                    message: `Failed to add rule to rule requests: ${errorMessage.substring(0, 150)}...`, 
                    severity: 'error',
                });
            })
            .finally(() => {
                setLoading(false);
            });
    };

    // NEW: Bulk CSV upload handler
    // NEW: Downloadable CSV template -- gives users a concrete reference
    // for the required bulk-upload format instead of guessing column
    // names. Generated and downloaded entirely client-side.
    const handleDownloadCsvTemplate = () => {
        const templateRows = [
            ['catalog', 'schema', 'table_name', 'column_name', 'condition_category', 'condition_type', 'condition_criteria', 'severity', 'rule_description', 'violation_threshold', 'enforcement_action', 'email_alert_enabled', 'alert_group_id'],
            ['dev_sales', 'bronze', 'customers', 'email', 'Format & Pattern Validation', 'REGEX_MATCH', '{"regex_pattern": "^[^@]+@[^@]+\\.[^@]+$"}', 'Warning', 'Validate email format', '', 'BLOCK_AND_AUDIT', 'true', ''],
            ['dev_sales', 'bronze', 'customers', 'customer_id', 'Completeness Rules', 'NOT_NULL', '{}', 'Critical', 'Customer ID must never be blank', '', 'BLOCK_AND_AUDIT', 'true', ''],
            ['dev_sales', 'bronze', 'asap_tvbst', 'MANDT', 'Format & Pattern Validation', 'LENGTH_CHECK', '{"value": 100}', 'Warning', 'Client field must be exactly 100 characters', '', 'BLOCK_AND_AUDIT', 'true', ''],
        ];
        // CSV-escape: wrap any field containing a comma, quote, or newline in
        // double quotes, doubling any internal double quotes.
        const escapeCell = (cell) => {
            const str = String(cell);
            if (/[",\n]/.test(str)) {
                return '"' + str.replace(/"/g, '""') + '"';
            }
            return str;
        };
        const csvContent = templateRows.map((row) => row.map(escapeCell).join(',')).join('\r\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'bulk_upload_rules_template.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleCsvFileSelected = async (event) => {
        const file = event.target.files?.[0];
        event.target.value = ''; // allow re-selecting the same file later
        if (!file) return;

        setCsvUploading(true);
        setCsvError('');
        setCsvResult(null);

        try {
            const userData = JSON.parse(sessionStorage.getItem('userData')) || {};
            const formData = new FormData();
            formData.append('file', file);
            formData.append('created_by', userData.email || 'unknown');

            const response = await fetch(`${API_BASE_URL}/api/rules/bulk-upload`, {
                method: 'POST',
                body: formData,
            });
            const result = await response.json();

            if (!response.ok && response.status !== 207) {
                throw new Error(result.error || `Server error: ${response.status}`);
            }

            setCsvResult(result);
            setCsvResultOpen(true);
        } catch (error) {
            setCsvError(error.message || 'Failed to upload CSV.');
            setCsvResultOpen(true);
        } finally {
            setCsvUploading(false);
        }
    };

    return (
        <Box>
            <Container maxWidth="lg">
                <Box className="create-rule-container" marginTop={2}>
                    <Box className="header-bottom">
                        <Typography variant="h6">Add Rules</Typography>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                            {/* NEW: downloadable CSV template with example rows,
                                so users have a concrete reference for the
                                required bulk-upload format instead of guessing
                                column names. Column format is a reasonable
                                best-effort mapping pending Antonio's actual
                                spec -- see bulk_upload_rules_from_csv()'s
                                docstring in create_rules_logic.py. */}
                            <Button
                                variant="text"
                                size="small"
                                sx={{ textTransform: 'none' }}
                                onClick={handleDownloadCsvTemplate}
                            >
                                Download CSV Template
                            </Button>
                            <Button
                                component="label"
                                variant="outlined"
                                size="small"
                                sx={{ textTransform: 'none' }}
                                disabled={csvUploading}
                            >
                                {csvUploading ? 'Uploading...' : 'Bulk Upload (CSV)'}
                                <input
                                    type="file"
                                    accept=".csv"
                                    hidden
                                    onChange={handleCsvFileSelected}
                                />
                            </Button>
                            <Button
                                className="glossary-btn"
                                sx={{ textTransform: 'none' }}
                                onClick={() => setOpenGlossary(true)}
                            >
                                Glossary
                            </Button>
                        </Box>
                    </Box>

                    {/* --- LLM RECOMMENDATION SECTION (before manual Add Rule) --- */}
                    <LLMRecommendationSection
                        config={config}
                        onAddRules={handleAddGeneratedRules}
                    />

                    {rules.map((rule, index) => (
                        <Box key={index} mt={2} mb={2} sx={{ position: "relative" }}>
                            <IconButton
                                onClick={() => handleDeleteRule(index)}
                                sx={{
                                    position: "absolute",
                                    top: 12,
                                    right: 12,
                                    transform: "scale(1.2)",
                                    color: "#e63a3aff",
                                    "&:hover": {
                                        color: "#d32f2f",
                                        backgroundColor: "rgba(211, 47, 47, 0.1)",
                                    },
                                }}
                            >
                                <CloseIcon fontSize="small" />
                            </IconButton>

                            {cardViews[index] ? (
                                <AddedRuleCard
                                    rule={rule}
                                    ruleNumber={index + 1}
                                    onEdit={() => editRule(index)}
                                />
                            ) : (
                                <RuleForm
                                    ruleNumber={index + 1}
                                    rule={rule}
                                    onChange={handleRuleChange}
                                    onEdit={editRule}
                                    onToggleCardView={toggleCardView}
                                    isCardView={cardViews[index]}
                                />
                            )}
                        </Box>
                    ))}

                    <Box display="flex" justifyContent="flex-start" ml={1} mb={10}>
                        <Button
                            onClick={handleAddRule}
                            variant="outlined"
                            size="small"
                            sx={{ textTransform: "none", fontSize: "13px" }}
                        >
                            + Add Rule
                        </Button>
                    </Box>

                    <Box sx={{ position: "fixed", bottom: 20, right: 30 }}>
                        <Button
                            onClick={handleSubmit}
                            variant="contained"
                            className="submit-btn"
                            disabled={loading}
                            startIcon={loading && <CircularProgress size={20} color="inherit" />}
                        >
                            {loading ? "Submitting..." : "Submit"}
                        </Button>
                    </Box>

                    <Glossary open={openGlossary} onClose={() => setOpenGlossary(false)} />

                    <Snackbar
                        open={snackbarState.open}
                        autoHideDuration={6000}
                        onClose={handleCloseSnackbar}
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    >
                        <Alert onClose={handleCloseSnackbar} severity={snackbarState.severity} sx={{ width: '100%' }}>
                            {snackbarState.message}
                        </Alert>
                    </Snackbar>

                    {/* NEW: Bulk CSV upload results */}
                    <Dialog open={csvResultOpen} onClose={() => setCsvResultOpen(false)} maxWidth="sm" fullWidth>
                        <DialogTitle>Bulk Upload Results</DialogTitle>
                        <DialogContent>
                            {csvError ? (
                                <Typography color="error">{csvError}</Typography>
                            ) : csvResult ? (
                                <Box>
                                    <Typography sx={{ mb: 1 }}>
                                        {csvResult.total} row(s) processed —{' '}
                                        <strong style={{ color: '#2e7d32' }}>{csvResult.succeeded} succeeded</strong>
                                        {csvResult.failed > 0 && (
                                            <>, <strong style={{ color: '#d32f2f' }}>{csvResult.failed} failed</strong></>
                                        )}
                                        . Every successfully parsed row has been submitted as a
                                        pending rule request, awaiting the same approval as any
                                        manually entered rule.
                                    </Typography>
                                    {csvResult.errors?.length > 0 && (
                                        <>
                                            <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>
                                                Rows that failed:
                                            </Typography>
                                            <List dense sx={{ maxHeight: 300, overflow: 'auto' }}>
                                                {csvResult.errors.map((err, i) => (
                                                    <ListItem key={i} divider>
                                                        <ListItemText
                                                            primary={`Row ${err.row}`}
                                                            secondary={err.error}
                                                        />
                                                    </ListItem>
                                                ))}
                                            </List>
                                        </>
                                    )}
                                </Box>
                            ) : null}
                        </DialogContent>
                        <DialogActions>
                            <Button onClick={() => setCsvResultOpen(false)} variant="contained">
                                Close
                            </Button>
                        </DialogActions>
                    </Dialog>
                </Box>
            </Container>
        </Box>
    );
};

export default CreateRules;