# import time
# import requests
# import json
# import yaml
# import os
# from config import config

# # --- Configuration Loading ---
# # Load config.yaml, assuming it's one directory level up from the current file's location.
# CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")

# with open(CONFIG_PATH, "r") as f:
#     yaml_config = yaml.safe_load(f)

# # Assign global configuration variables
# CATALOG = yaml_config.get("catalog")
# SCHEMA = yaml_config.get("schema")
# RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
# RULE_TABLE = yaml_config.get("rule_table")
# TABLE_CONFIG = yaml_config.get("table_config")
# PIPELINE_METADATA = yaml_config.get("pipeline_metadata")


# # --- Databricks Query Engine ---
# def query_table(name, query, params=None):
#     """
#     Executes a SQL query on Databricks using the Statement Execution API.

#     Polls for the result and returns formatted data upon success, or raises
#     an exception on failure.
#     """
#     url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
#     headers = {
#         "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
#         "Content-Type": "application/json"
#     }
#     payload = {
#         "statement": query,
#         "warehouse_id": config.SQL_WAREHOUSE_ID,
#         "wait_timeout": "10s"
#     }

#     # Add parameters to the payload if they are provided
#     if params:
#         payload["parameters"] = params

#     res = requests.post(url, headers=headers, json=payload)
#     res.raise_for_status()
#     response_json = res.json()
#     statement_id = response_json.get("statement_id")

#     if not statement_id:
#         raise Exception(f"No statement_id returned for query '{name}'")

#     # Poll for the statement status
#     status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
#     while True:
#         status_res = requests.get(status_url, headers=headers)
#         status_res.raise_for_status()
#         status_json = status_res.json()
#         state = status_json.get("status", {}).get("state")

#         if state == "SUCCEEDED":
#             manifest = status_json.get("manifest", {})
#             schema = manifest.get("schema", {})
#             columns = [col["name"] for col in schema.get("columns", [])]
#             full_result = status_json.get("result", {})
#             data_array = full_result.get("data_array", [])
            
#             # Format data as a list of dictionaries
#             formatted_data = [dict(zip(columns, row)) for row in data_array]
#             return formatted_data
        
#         elif state in ["FAILED", "CANCELED", "CLOSED"]:
#             error = status_json.get("status", {}).get("error", {})
#             error_message = error.get('message', 'Unknown error')
#             raise Exception(f"Query '{name}' failed: {error_message}")
        
#         time.sleep(1)


# # --- Data Retrieval Functions ---

# def get_tables_data(search=None, severity=None, group_id=None, status=None, **kwargs):
#     """
#     Builds and executes the SQL for the main card view, fetching table metadata.
#     If a group_id is provided, it joins with the table configuration to filter results.
#     """
#     params = []
    
#     # Conditionally build the subquery based on whether a group_id is provided
#     if group_id:
#         t1_subquery = f"""
#             (
#                 SELECT
#                     r.table_name,
#                     r.schema_name,
#                     r.catalog_name,
#                     COUNT(r.rule_id) AS rules_count
#                 FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#                 JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS tbls
#                     ON r.catalog_name = tbls.catalog_name
#                     AND r.schema_name = tbls.schema_name
#                     AND r.table_name = tbls.table_name
#                 WHERE
#                     tbls.group_id = :group_id AND year(effective_date_to) = 9999
#                 GROUP BY
#                     r.catalog_name, r.schema_name, r.table_name
#             ) AS t1
#         """
#         params.append({"name": "group_id", "type": "STRING", "value": str(group_id)})
#     else:
#         t1_subquery = f"""
#             (
#                 SELECT
#                     table_name,
#                     schema_name,
#                     catalog_name,
#                     COUNT(rule_id) AS rules_count
#                 FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#                 GROUP BY
#                     table_name, schema_name, catalog_name
#             ) AS t1
#         """

#     # Construct the main query using the subquery
#     base_query = f"""
#         SELECT
#             t1.table_name,
#             t1.schema_name,
#             t1.catalog_name,
#             t1.rules_count,
#             COALESCE(t2.column_count, 0) AS column_count,
#             COALESCE(t2.columns, '') AS columns
#         FROM {t1_subquery}
#         LEFT JOIN (
#             SELECT
#                 table_name,
#                 table_schema,
#                 table_catalog,
#                 COUNT(DISTINCT column_name) AS column_count,
#                 concat_ws(', ', collect_list(DISTINCT column_name)) AS columns
#             FROM {CATALOG}.information_schema.columns
#             GROUP BY
#                 table_name, table_schema, table_catalog
#         ) AS t2
#             ON t1.table_name = t2.table_name
#             AND t1.schema_name = t2.table_schema
#             AND t1.catalog_name = t2.table_catalog
#     """
    
#     # Append a search filter if provided
#     if search:
#         base_query += " WHERE t1.table_name LIKE :search OR t1.catalog_name LIKE :search"
#         params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})
            
#     return query_table("get_tables_data", base_query, params)


# def get_filters_data(group_id=None):
#     """
#     Executes multiple queries to get all unique values for filter dropdowns.
#     """
#     base_from_clause = f"""
#         FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS t1
#         JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
#             ON t1.catalog_name = t2.catalog_name
#             AND t1.schema_name = t2.schema_name
#             AND t1.table_name = t2.table_name
#     """
    
#     where_clauses = []
#     params = []
    
#     if group_id:
#         where_clauses.append("t2.group_id = ?")
#         params.append({"value": group_id, "type": "STRING"})

#     where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

#     filter_queries = {
#         "schemas": f"SELECT DISTINCT t1.schema_name {base_from_clause} {where_clause_str}",
#         "table_names": f"SELECT DISTINCT t1.table_name {base_from_clause} {where_clause_str}",
#         "user": f"SELECT DISTINCT t1.owner {base_from_clause} {where_clause_str}"
#     }

#     results = {}
#     for name, query in filter_queries.items():
#         try:
#             data = query_table(name, query, params)
#             normalized_list = [str(list(row.values())[0]).lower() for row in data]
#             results[name] = sorted(list(set(normalized_list)))
#         except Exception as e:
#             results[name] = {"error": str(e)}
            
#     return results


# def get_rules_for_table_data(tableId, search=None, **kwargs):
#     """
#     Retrieves all active rules for a specific table, identified by 'catalog-schema-table'.
#     """
#     try:
#         catalog, schema, table = tableId.split('-')
#     except ValueError:
#         raise ValueError("tableId must be in the format 'catalog-schema-table'.")

#     query = f"""
#         SELECT
#             r.condition_type AS Rule_name,
#             r.column_name AS Column_name,
#             r.rule_description AS Rule_description,
#             r.condition_category AS Condition_category,
#             r.condition_type AS Condition_type,
#             r.condition_criteria AS Condition_criteria,
#             r.severity AS Severity
#         FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#         WHERE
#             r.table_name = :tableName
#             AND r.schema_name = :schemaName
#             AND r.catalog_name = :catalogName
#             AND year(effective_date_to) = 9999
#     """
    
#     params = [
#         {"name": "tableName", "type": "STRING", "value": table},
#         {"name": "schemaName", "type": "STRING", "value": schema},
#         {"name": "catalogName", "type": "STRING", "value": catalog}
#     ]

#     if search:
#         query += " AND r.condition_type LIKE :search"
#         params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})
    
#     return query_table(f"get_rules_for_{tableId}", query, params)


# def get_filters_for_table(tableId):
#     """
#     Gets all unique filter options for the rules within a specific table.
#     """
#     try:
#         catalog, schema, table = tableId.split('-')
#     except ValueError:
#         raise ValueError("tableId must be in the format 'catalog-schema-table'.")
            
#     filter_queries = {
#         "condition_category": f"""
#             SELECT DISTINCT r.condition_category
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#             WHERE r.table_name = :tableName
#               AND r.schema_name = :schemaName
#               AND r.catalog_name = :catalogName
#         """,
#         "condition_type": f"""
#             SELECT DISTINCT r.condition_type
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#             WHERE r.table_name = :tableName
#               AND r.schema_name = :schemaName
#               AND r.catalog_name = :catalogName
#         """,
#         "severity": f"""
#             SELECT DISTINCT r.severity
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#             WHERE r.table_name = :tableName
#               AND r.schema_name = :schemaName
#               AND r.catalog_name = :catalogName
#         """
#     }

#     params = [
#         {"name": "tableName", "type": "STRING", "value": table},
#         {"name": "schemaName", "type": "STRING", "value": schema},
#         {"name": "catalogName", "type": "STRING", "value": catalog}
#     ]

#     results = {}
#     for name, query in filter_queries.items():
#         try:
#             data = query_table(name, query, params)
#             results[name] = [list(row.values())[0] for row in data]
#         except Exception as e:
#             results[name] = {"error": str(e)}
            
#     # Add a static list for 'status' since it's computed in the business logic
#     results['status'] = ['active', 'inactive']
            
#     return results


# def get_rule_details(ruleId):
#     """
#     Builds and executes SQL to get the full details for a single rule by its ID.
#     This query distinguishes between creation and review metadata.
#     """
#     query = f"""
#         WITH active_rule AS (
#             SELECT *
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#             WHERE rule_id = :ruleId AND year(effective_date_to) = 9999
#         ),
#         previous_rule AS (
#             SELECT rule_id, owner, created_at
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#             WHERE rule_id = :ruleId AND year(effective_date_to) <> 9999
#             ORDER BY effective_date_to DESC
#             LIMIT 1
#         )
#         SELECT
#             a.condition_category,
#             a.condition_criteria,
#             CASE
#                 WHEN a.updated_at IS NULL THEN a.created_at
#                 ELSE p.created_at
#             END AS created_at,
#             CASE
#                 WHEN a.updated_at IS NULL THEN NULL
#                 ELSE a.updated_at
#             END AS reviewed_at,
#             CASE
#                 WHEN a.updated_at IS NULL THEN a.owner
#                 ELSE p.owner
#             END AS created_by,
#             CASE
#                 WHEN a.updated_at IS NULL THEN NULL
#                 ELSE a.owner
#             END AS reviewed_by
#         FROM active_rule AS a
#         LEFT JOIN previous_rule AS p ON a.rule_id = p.rule_id
#     """

#     param_type = "BIGINT" if isinstance(ruleId, int) else "STRING"
#     params = [{"name": "ruleId", "type": param_type, "value": ruleId}]
    
#     result = query_table(f"get_rule_{ruleId}", query, params)
#     return result[0] if result else None


# def get_active_or_inactive_rules_for_table(tableId, status=None, severity=None, Condition_Type=None, Condition_Category=None, **kwargs):
#     """
#     Builds and executes SQL to get rules for a specific table, with dynamic filters.
#     Computes rule status ('active'/'inactive') on the fly.
#     """
#     try:
#         catalog, schema, table = tableId.split('-')
#     except ValueError:
#         raise ValueError("tableId must be in the format 'catalog-schema-table'.")
    
#     base_query = f"""
#         WITH RulesWithStatus AS (
#             SELECT
#                 r.severity,
#                 r.rule_id,
#                 r.column_name,
#                 r.rule_description,
#                 r.violation_threshold,
#                 r.condition_criteria,
#                 r.condition_type,
#                 r.enforcement_action,
#                 r.email_alert_enabled,
#                 r.alert_group_id,
#                 CASE
#                     WHEN CURRENT_TIMESTAMP() >= r.effective_date_from AND CURRENT_TIMESTAMP() < r.effective_date_to
#                     THEN 'active'
#                     ELSE 'inactive'
#                 END AS computed_status
#             FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
#             WHERE
#                 r.table_name = :tableName
#                 AND r.schema_name = :schemaName
#                 AND r.catalog_name = :catalogName
#         )
#         SELECT * FROM RulesWithStatus
#     """
    
#     params = [
#         {"name": "tableName", "type": "STRING", "value": table},
#         {"name": "schemaName", "type": "STRING", "value": schema},
#         {"name": "catalogName", "type": "STRING", "value": catalog}
#     ]
    
#     where_clauses = []
    
#     if status:
#         where_clauses.append("computed_status = :status")
#         params.append({"name": "status", "type": "STRING", "value": status})
        
#     if severity:
#         where_clauses.append("severity = :severity")
#         params.append({"name": "severity", "type": "STRING", "value": severity})

#     if Condition_Type:
#         where_clauses.append("condition_type = :Condition_Type")
#         params.append({"name": "Condition_Type", "type": "STRING", "value": Condition_Type})

#     if Condition_Category:
#         where_clauses.append("condition_category = :Condition_Category")
#         params.append({"name": "Condition_Category", "type": "STRING", "value": Condition_Category})

#     final_query = base_query
#     if where_clauses:
#         final_query += " WHERE " + " AND ".join(where_clauses)
            
#     results = query_table(f"get_rules_for_{tableId}", final_query, params)
    
#     # Attempt to convert rule_id to integer for consistency
#     for row in results:
#         if "rule_id" in row and row["rule_id"] is not None:
#             try:
#                 row["rule_id"] = int(row["rule_id"])
#             except (ValueError, TypeError):
#                 pass  # Keep as-is if it’s not a valid number
#     return results


# def get_columns_for_rule_from_info_schema(rule_id):
#     """
#     Finds the table for a rule_id, then fetches its column names from information_schema.
#     """
#     # Step 1: Find the catalog, schema, and table for the given rule_id
#     get_rule_query = f"""
#         SELECT catalog_name, schema_name, table_name
#         FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#         WHERE rule_id = ?
#     """
#     rule_params = [{"type": "STRING", "value": rule_id}]
#     rule_details = query_table("get_rule_details_for_columns", get_rule_query, rule_params)
    
#     if not rule_details:
#         raise Exception(f"No rule found with rule_id: {rule_id}")
            
#     catalog = rule_details[0]["catalog_name"]
#     schema = rule_details[0]["schema_name"]
#     table = rule_details[0]["table_name"]
    
#     # Step 2: Use the details to query the information_schema
#     get_columns_query = f"""
#         SELECT column_name
#         FROM {CATALOG}.information_schema.columns
#         WHERE
#             table_catalog = ?
#             AND table_schema = ?
#             AND table_name = ?
#         ORDER BY ordinal_position
#     """
#     column_params = [
#         {"type": "STRING", "value": catalog},
#         {"type": "STRING", "value": schema},
#         {"type": "STRING", "value": table}
#     ]
#     column_data = query_table("get_columns_from_info_schema", get_columns_query, column_params)
    
#     column_names = [row["column_name"] for row in column_data]
#     return column_names


# def insert_rule_request(rule_id, popup_data, data):
#     """
#     Inserts a new record into the rule requests table, preserving data types
#     in the condition_criteria JSON.
#     """
#     get_rule_query = f"""
#         SELECT
#             rule_id, catalog_name, schema_name, table_name,
#             condition_category, condition_type, owner, condition_criteria,
#             enforcement_action, email_alert_enabled, alert_group_id
#         FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#         WHERE rule_id = :ruleId
#     """
#     params = [{"name": "ruleId", "type": "STRING", "value": rule_id}]
#     rule_details = query_table(f"get_rule_details_for_request_{rule_id}", get_rule_query, params)
    
#     if not rule_details:
#         raise Exception(f"No rule found with rule_id: {rule_id}")
#     rule = rule_details[0]

#     # --- Robustly handle condition_criteria (could be dict or JSON string) ---
#     raw_new_criteria = popup_data.get("condition_criteria")
#     new_criteria_dict = {}

#     if isinstance(raw_new_criteria, str):
#         try:
#             new_criteria_dict = json.loads(raw_new_criteria)
#         except json.JSONDecodeError:
#             new_criteria_dict = {} # Gracefully handle bad JSON string
#     elif isinstance(raw_new_criteria, dict):
#         new_criteria_dict = raw_new_criteria
    
#     final_criteria = new_criteria_dict.copy()

#     # Mirror data types from the original rule's criteria
#     original_criteria_str = rule.get("condition_criteria")
#     if original_criteria_str and new_criteria_dict:
#         try:
#             original_criteria = json.loads(original_criteria_str)
#             for key, new_value in new_criteria_dict.items():
#                 if key in original_criteria:
#                     original_value = original_criteria[key]
#                     if isinstance(original_value, (int, float)):
#                         try:
#                             # Attempt to cast new value to the original type
#                             final_criteria[key] = type(original_value)(new_value)
#                         except (ValueError, TypeError):
#                             final_criteria[key] = new_value # Keep new value if cast fails
#         except json.JSONDecodeError:
#             pass # Ignore if original criteria is not valid JSON

#     final_criteria_json_string = json.dumps(final_criteria) if final_criteria else None

#     # Enforcement action: use the value the edit dialog sent if present and
#     # valid; otherwise keep whatever the rule already had (so editing e.g.
#     # just the description doesn't accidentally reset this field).
#     VALID_ENFORCEMENT_ACTIONS = ("BLOCK_AND_AUDIT", "AUDIT_ONLY")
#     enforcement_action = data.get("enforcement_action") or popup_data.get("enforcement_action")
#     if enforcement_action not in VALID_ENFORCEMENT_ACTIONS:
#         enforcement_action = rule.get("enforcement_action") or "BLOCK_AND_AUDIT"

#     raw_email_alert = data.get("email_alert_enabled", popup_data.get("email_alert_enabled"))
#     if raw_email_alert is None:
#         email_alert_enabled = rule.get("email_alert_enabled")
#         email_alert_enabled = True if email_alert_enabled is None else bool(email_alert_enabled)
#     else:
#         email_alert_enabled = bool(raw_email_alert)

#     if "alert_group_id" in data or "alert_group_id" in popup_data:
#         alert_group_id = data.get("alert_group_id") or popup_data.get("alert_group_id") or None
#     else:
#         alert_group_id = rule.get("alert_group_id") or None

#     # --- Insert the formatted data into the requests table ---
#     insert_query = f"""
#         INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
#         (
#             request_id, catalog, schema, table_name, column_name, rule_description,
#             status, created_by, created_at, reviewed_by, reviewed_at, review_comments,
#             condition_category, condition_type, condition_criteria, operation,
#             severity, violation_threshold, enforcement_action,
#             email_alert_enabled, alert_group_id
#         )
#         VALUES
#         (
#             :request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
#             :status, :created_by, current_timestamp(), NULL, NULL, NULL,
#             :condition_category, :condition_type, :condition_criteria, :operation,
#             :severity, :violation_threshold, :enforcement_action,
#             :email_alert_enabled, :alert_group_id
#         )
#     """
#     insert_params = [
#         {"name": "request_id", "type": "STRING", "value": str(rule_id)},
#         {"name": "catalog", "type": "STRING", "value": rule["catalog_name"]},
#         {"name": "schema", "type": "STRING", "value": rule["schema_name"]},
#         {"name": "table_name", "type": "STRING", "value": rule["table_name"]},
#         {"name": "column_name", "type": "STRING", "value": popup_data["column_name"]},
#         {"name": "rule_description", "type": "STRING", "value": popup_data["rule_description"]},
#         {"name": "status", "type": "STRING", "value": "pending"},
#         {"name": "created_by", "type": "STRING", "value": rule["owner"]},
#         {"name": "condition_category", "type": "STRING", "value": rule["condition_category"]},
#         {"name": "condition_type", "type": "STRING", "value": rule["condition_type"]},
#         {"name": "condition_criteria", "type": "STRING", "value": final_criteria_json_string},
#         {"name": "operation", "type": "STRING", "value": "UPDATE"},
#         {"name": "severity", "type": "STRING", "value": popup_data["severity"]},
#         {"name": "violation_threshold", "type": "FLOAT", "value": float(popup_data["violation_threshold"])},
#         {"name": "enforcement_action", "type": "STRING", "value": enforcement_action},
#         {"name": "email_alert_enabled", "type": "BOOLEAN", "value": email_alert_enabled},
#         {"name": "alert_group_id", "type": "STRING", "value": alert_group_id}
#     ]

#     return query_table(f"insert_rule_request_{rule_id}", insert_query, insert_params)


# def delete_rule_data(ruleId):
#     """
#     Deletes a rule by its string-based rule_id.
#     """
#     query = f"""
#         DELETE FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
#         WHERE rule_id = :ruleId
#     """
#     params = [{"name": "ruleId", "type": "STRING", "value": ruleId}]
    
#     return query_table(f"delete_rule_{ruleId}", query, params)





import time
import requests
import json
import yaml
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import config
from app.CreateRules.create_rules_logic import check_and_add_table_to_approvers

# --- Configuration Loading ---
# Load config.yaml, assuming it's one directory level up from the current file's location.
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")

with open(CONFIG_PATH, "r") as f:
    yaml_config = yaml.safe_load(f)

# Assign global configuration variables
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
RULE_TABLE = yaml_config.get("rule_table")
TABLE_CONFIG = yaml_config.get("table_config")
PIPELINE_METADATA = yaml_config.get("pipeline_metadata")


# --- Databricks Query Engine ---
def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API.

    Polls for the result and returns formatted data upon success, or raises
    an exception on failure.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    # Add parameters to the payload if they are provided
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    # Poll for the statement status
    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            schema = manifest.get("schema", {})
            columns = [col["name"] for col in schema.get("columns", [])]
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            
            # Format data as a list of dictionaries
            formatted_data = [dict(zip(columns, row)) for row in data_array]
            return formatted_data
        
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            error_message = error.get('message', 'Unknown error')
            raise Exception(f"Query '{name}' failed: {error_message}")
        
        time.sleep(1)


# --- Data Retrieval Functions ---

def get_tables_data(search=None, severity=None, group_id=None, status=None, catalog=None, **kwargs):
    """
    Builds and executes the SQL for the main card view, fetching table metadata.
    If a group_id is provided, it joins with the table configuration to filter results.
    """
    params = []
    
    # Conditionally build the subquery based on whether a group_id is provided
    if group_id:
        # FIX: tables whose rules were inserted directly into dq_rules via
        # raw SQL (not through the UI's Create Rules flow) never get
        # registered in TABLE_CONFIG for any group -- the UI's own
        # insert_rule() -> check_and_add_table_to_approvers() step is what
        # normally creates that registration, and a direct SQL insert skips
        # it entirely. The previous INNER JOIN silently dropped any such
        # table from view, for every group, with no error or indication
        # anything was hidden. Changed to LEFT JOIN + a fallback: a table
        # with NO group registration at all (tbls.group_id IS NULL) is now
        # visible to every group, instead of being invisible to all of
        # them -- rules that genuinely exist in dq_rules are never hidden
        # purely because of a missing config row.
        t1_query = f"""
            SELECT
                r.table_name,
                r.schema_name,
                r.catalog_name,
                COUNT(r.rule_id) AS rules_count,
                MAX(tbls.group_id) AS _matched_group_id
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            LEFT JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS tbls
                ON r.catalog_name = tbls.catalog_name
                AND r.schema_name = tbls.schema_name
                AND r.table_name = tbls.table_name
            WHERE
                (tbls.group_id = :group_id OR tbls.group_id IS NULL)
                AND year(r.effective_date_to) = 9999
            GROUP BY
                r.catalog_name, r.schema_name, r.table_name
        """
        params.append({"name": "group_id", "type": "STRING", "value": str(group_id)})
    else:
        t1_query = f"""
            SELECT
                table_name,
                schema_name,
                catalog_name,
                COUNT(rule_id) AS rules_count
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            GROUP BY
                table_name, schema_name, catalog_name
        """

    rows = query_table("get_tables_data_t1", t1_query, params)

    # FIX: a table with NO TABLE_CONFIG registration at all was previously
    # left permanently visible to every group (the safety-net fallback
    # above) with no path to becoming correctly scoped -- e.g. a rule
    # inserted directly into dq_rules via raw SQL would show up under
    # every group indefinitely, not just the one it actually belongs to.
    # Auto-register any such table to Approvers (the same default group
    # already used when a table is created through the normal UI flow),
    # so it converges to correct, permanent registration instead of
    # relying on the fallback forever.
    if group_id:
        for row in rows:
            if row.get("_matched_group_id") is None:
                try:
                    check_and_add_table_to_approvers(
                        row["catalog_name"], row["schema_name"], row["table_name"]
                    )
                except Exception as e:
                    print(f"  ⚠️ Could not auto-register {row['catalog_name']}.{row['schema_name']}.{row['table_name']} to Approvers: {e}")

    # FIX: column_count/columns previously always showed 0 for every table.
    # information_schema is catalog-scoped in Unity Catalog, but rule tables
    # can live in different catalogs than the single hardcoded governance
    # CATALOG constant that used to be queried here -- so the old LEFT JOIN
    # could only ever match tables that happened to share that one catalog.
    # Fix: query information_schema once per DISTINCT catalog actually
    # present among these tables (using each table's own real catalog_name),
    # and merge the column counts back in Python.
    # FIX (performance): column_count/columns previously always showed 0 for
    # every table, and separately, this endpoint was extremely slow (22+
    # seconds observed in production). Two issues here, both fixed:
    #   1. The query scanned the ENTIRE catalog's information_schema with no
    #      WHERE clause at all, even though only a handful of specific
    #      schemas actually have rule-bearing tables -- now scoped to just
    #      the schemas actually present, which is a large reduction for any
    #      catalog with many schemas beyond the few actually in use.
    #   2. Each catalog was queried sequentially, one full network
    #      round-trip after another -- now parallelized with a
    #      ThreadPoolExecutor, since these are independent, I/O-bound HTTP
    #      calls to the Databricks SQL Statement Execution API.
    schemas_by_catalog = {}
    for row in rows:
        cat = row.get("catalog_name")
        sch = row.get("schema_name")
        if cat and sch:
            schemas_by_catalog.setdefault(cat, set()).add(sch)
    distinct_catalogs = sorted(schemas_by_catalog.keys())

    column_lookup = {}

    def _fetch_columns_for_catalog(cat):
        schemas = schemas_by_catalog.get(cat, set())
        if not schemas:
            return cat, []
        schemas_list = ", ".join(
            "'" + s.replace("'", "''") + "'" for s in schemas
        )
        query = f"""
            SELECT
                table_name,
                table_schema,
                table_catalog,
                COUNT(DISTINCT column_name) AS column_count,
                concat_ws(', ', collect_list(DISTINCT column_name)) AS columns
            FROM {cat}.information_schema.columns
            WHERE table_schema IN ({schemas_list})
            GROUP BY table_name, table_schema, table_catalog
        """
        return cat, query_table("get_tables_data_columns", query)

    with ThreadPoolExecutor(max_workers=min(8, max(1, len(distinct_catalogs)))) as executor:
        futures = {executor.submit(_fetch_columns_for_catalog, cat): cat for cat in distinct_catalogs}
        for future in as_completed(futures):
            cat = futures[future]
            try:
                _, col_rows = future.result()
            except Exception as e:
                print(f"  ⚠️ Could not read information_schema for catalog '{cat}': {e}")
                continue
            for col_row in col_rows:
                key = (col_row["table_catalog"].lower(), col_row["table_schema"].lower(), col_row["table_name"].lower())
                column_lookup[key] = (col_row["column_count"], col_row["columns"])

    results = []
    for row in rows:
        key = (row["catalog_name"].lower(), row["schema_name"].lower(), row["table_name"].lower())
        column_count, columns = column_lookup.get(key, (0, ""))
        results.append({
            "table_name": row["table_name"],
            "schema_name": row["schema_name"],
            "catalog_name": row["catalog_name"],
            "rules_count": row["rules_count"],
            "column_count": column_count,
            "columns": columns,
        })

    # Apply the search filter in Python now that the join happens there too
    if search:
        needle = search.lower()
        results = [
            r for r in results
            if needle in (r["table_name"] or "").lower()
            or needle in (r["catalog_name"] or "").lower()
        ]

    if catalog:
        results = [r for r in results if (r["catalog_name"] or "").lower() == catalog.lower()]

    return results


def get_filters_data(group_id=None):
    """
    Executes multiple queries to get all unique values for filter dropdowns.
    """
    # FIX: same table-visibility bug already fixed in get_tables_data() --
    # an INNER JOIN here silently excluded filter options (catalogs,
    # schemas, table names) for any table never registered in
    # TABLE_CONFIG (e.g. a rule inserted directly into dq_rules via raw
    # SQL). Changed to LEFT JOIN + a fallback so those tables' values are
    # visible in the filter dropdowns too.
    base_from_clause = f"""
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS t1
        LEFT JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
            ON t1.catalog_name = t2.catalog_name
            AND t1.schema_name = t2.schema_name
            AND t1.table_name = t2.table_name
    """
    
    where_clauses = []
    params = []
    
    if group_id:
        where_clauses.append("(t2.group_id = ? OR t2.group_id IS NULL)")
        params.append({"value": group_id, "type": "STRING"})

    where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

    filter_queries = {
        "catalogs": f"SELECT DISTINCT t1.catalog_name {base_from_clause} {where_clause_str}",
        "schemas": f"SELECT DISTINCT t1.schema_name {base_from_clause} {where_clause_str}",
        "table_names": f"SELECT DISTINCT t1.table_name {base_from_clause} {where_clause_str}",
        "user": f"SELECT DISTINCT t1.owner {base_from_clause} {where_clause_str}"
    }

    # FIX (performance): these 4 queries ran sequentially, one full
    # round-trip after another, contributing to the same slow-page-load
    # issue as get_tables_data's per-catalog queries. Parallelized since
    # they're independent, I/O-bound calls.
    results = {}

    def _run_filter_query(name_query):
        name, query = name_query
        data = query_table(name, query, params)
        normalized_list = [str(list(row.values())[0]).lower() for row in data]
        return name, sorted(list(set(normalized_list)))

    with ThreadPoolExecutor(max_workers=len(filter_queries)) as executor:
        futures = {executor.submit(_run_filter_query, item): item[0] for item in filter_queries.items()}
        for future in as_completed(futures):
            name = futures[future]
            try:
                _, values = future.result()
                results[name] = values
            except Exception as e:
                results[name] = {"error": str(e)}

    return results


def get_rules_for_table_data(tableId, search=None, **kwargs):
    """
    Retrieves all active rules for a specific table, identified by 'catalog-schema-table'.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")

    query = f"""
        SELECT
            r.condition_type AS Rule_name,
            r.column_name AS Column_name,
            r.rule_description AS Rule_description,
            r.condition_category AS Condition_category,
            r.condition_type AS Condition_type,
            r.condition_criteria AS Condition_criteria,
            r.severity AS Severity,
            COALESCE(r.enforcement_action, 'BLOCK_AND_AUDIT') AS Enforcement_action
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
        WHERE
            r.table_name = :tableName
            AND r.schema_name = :schemaName
            AND r.catalog_name = :catalogName
            AND year(effective_date_to) = 9999
    """
    
    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]

    if search:
        query += " AND r.condition_type LIKE :search"
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})
    
    return query_table(f"get_rules_for_{tableId}", query, params)


def get_filters_for_table(tableId):
    """
    Gets all unique filter options for the rules within a specific table.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")
            
    filter_queries = {
        "condition_category": f"""
            SELECT DISTINCT r.condition_category
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """,
        "condition_type": f"""
            SELECT DISTINCT r.condition_type
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """,
        "severity": f"""
            SELECT DISTINCT r.severity
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """,
        "enforcement_action": f"""
            SELECT DISTINCT COALESCE(r.enforcement_action, 'BLOCK_AND_AUDIT') AS enforcement_action
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """
    }

    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]

    results = {}
    for name, query in filter_queries.items():
        try:
            data = query_table(name, query, params)
            results[name] = [list(row.values())[0] for row in data]
        except Exception as e:
            results[name] = {"error": str(e)}
            
    # Add a static list for 'status' since it's computed in the business logic
    results['status'] = ['active', 'inactive']
            
    return results


def get_rule_details(ruleId):
    """
    Builds and executes SQL to get the full details for a single rule by its ID.
    This query distinguishes between creation and review metadata.
    """
    query = f"""
        WITH active_rule AS (
            SELECT *
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = :ruleId AND year(effective_date_to) = 9999
        ),
        previous_rule AS (
            SELECT rule_id, owner, created_at
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = :ruleId AND year(effective_date_to) <> 9999
            ORDER BY effective_date_to DESC
            LIMIT 1
        )
        SELECT
            a.condition_category,
            a.condition_criteria,
            CASE
                WHEN a.updated_at IS NULL THEN a.created_at
                ELSE p.created_at
            END AS created_at,
            CASE
                WHEN a.updated_at IS NULL THEN NULL
                ELSE a.updated_at
            END AS reviewed_at,
            CASE
                WHEN a.updated_at IS NULL THEN a.owner
                ELSE p.owner
            END AS created_by,
            CASE
                WHEN a.updated_at IS NULL THEN NULL
                ELSE a.owner
            END AS reviewed_by
        FROM active_rule AS a
        LEFT JOIN previous_rule AS p ON a.rule_id = p.rule_id
    """

    param_type = "BIGINT" if isinstance(ruleId, int) else "STRING"
    params = [{"name": "ruleId", "type": param_type, "value": ruleId}]
    
    result = query_table(f"get_rule_{ruleId}", query, params)
    return result[0] if result else None


def get_active_or_inactive_rules_for_table(tableId, status=None, severity=None, Condition_Type=None, Condition_Category=None, **kwargs):
    """
    Builds and executes SQL to get rules for a specific table, with dynamic filters.
    Computes rule status ('active'/'inactive') on the fly.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")
    
    base_query = f"""
        WITH RulesWithStatus AS (
            SELECT
                r.severity,
                r.rule_id,
                r.column_name,
                r.rule_description,
                r.violation_threshold,
                r.condition_criteria,
                r.condition_type,
                r.enforcement_action,
                r.email_alert_enabled,
                r.alert_group_id,
                CASE
                    WHEN CURRENT_TIMESTAMP() >= r.effective_date_from AND CURRENT_TIMESTAMP() < r.effective_date_to
                    THEN 'active'
                    ELSE 'inactive'
                END AS computed_status
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE
                r.table_name = :tableName
                AND r.schema_name = :schemaName
                AND r.catalog_name = :catalogName
        )
        SELECT * FROM RulesWithStatus
    """
    
    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]
    
    where_clauses = []
    
    if status:
        where_clauses.append("computed_status = :status")
        params.append({"name": "status", "type": "STRING", "value": status})
        
    if severity:
        where_clauses.append("severity = :severity")
        params.append({"name": "severity", "type": "STRING", "value": severity})

    if Condition_Type:
        where_clauses.append("condition_type = :Condition_Type")
        params.append({"name": "Condition_Type", "type": "STRING", "value": Condition_Type})

    if Condition_Category:
        where_clauses.append("condition_category = :Condition_Category")
        params.append({"name": "Condition_Category", "type": "STRING", "value": Condition_Category})

    final_query = base_query
    if where_clauses:
        final_query += " WHERE " + " AND ".join(where_clauses)
            
    results = query_table(f"get_rules_for_{tableId}", final_query, params)
    
    # Attempt to convert rule_id to integer for consistency
    for row in results:
        if "rule_id" in row and row["rule_id"] is not None:
            try:
                row["rule_id"] = int(row["rule_id"])
            except (ValueError, TypeError):
                pass  # Keep as-is if it’s not a valid number
    return results


def get_columns_for_rule_from_info_schema(rule_id):
    """
    Finds the table for a rule_id, then fetches its column names from information_schema.
    """
    # Step 1: Find the catalog, schema, and table for the given rule_id
    get_rule_query = f"""
        SELECT catalog_name, schema_name, table_name
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = ?
    """
    rule_params = [{"type": "STRING", "value": rule_id}]
    rule_details = query_table("get_rule_details_for_columns", get_rule_query, rule_params)
    
    if not rule_details:
        raise Exception(f"No rule found with rule_id: {rule_id}")
            
    catalog = rule_details[0]["catalog_name"]
    schema = rule_details[0]["schema_name"]
    table = rule_details[0]["table_name"]
    
    # Step 2: Use the details to query the information_schema.
    # NOTE: this queries `catalog` (the target table's own catalog, found in
    # Step 1) rather than the governance CATALOG constant — information_schema
    # is catalog-scoped in Unity Catalog, so using the governance catalog here
    # would silently return no columns whenever the rule's table lives in a
    # different catalog.
    get_columns_query = f"""
        SELECT column_name, data_type
        FROM {catalog}.information_schema.columns
        WHERE
            table_catalog = ?
            AND table_schema = ?
            AND table_name = ?
        ORDER BY ordinal_position
    """
    column_params = [
        {"type": "STRING", "value": catalog},
        {"type": "STRING", "value": schema},
        {"type": "STRING", "value": table}
    ]
    column_data = query_table("get_columns_from_info_schema", get_columns_query, column_params)

    # Returned as {column_name, data_type} objects (covers every column type —
    # string, short, byte, decimal, timestamp, etc.) so the frontend can show
    # and reason about type, not just the bare name.
    return [
        {"column_name": row["column_name"], "data_type": row.get("data_type")}
        for row in column_data
    ]


def insert_rule_request(rule_id, popup_data, data):
    """
    Inserts a new record into the rule requests table, preserving data types
    in the condition_criteria JSON.
    """
    get_rule_query = f"""
        SELECT
            rule_id, catalog_name, schema_name, table_name,
            condition_category, condition_type, owner, condition_criteria,
            enforcement_action, email_alert_enabled, alert_group_id
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = :ruleId
    """
    params = [{"name": "ruleId", "type": "STRING", "value": rule_id}]
    rule_details = query_table(f"get_rule_details_for_request_{rule_id}", get_rule_query, params)
    
    if not rule_details:
        raise Exception(f"No rule found with rule_id: {rule_id}")
    rule = rule_details[0]

    # --- Robustly handle condition_criteria (could be dict or JSON string) ---
    raw_new_criteria = popup_data.get("condition_criteria")
    new_criteria_dict = {}

    if isinstance(raw_new_criteria, str):
        try:
            new_criteria_dict = json.loads(raw_new_criteria)
        except json.JSONDecodeError:
            new_criteria_dict = {} # Gracefully handle bad JSON string
    elif isinstance(raw_new_criteria, dict):
        new_criteria_dict = raw_new_criteria
    
    final_criteria = new_criteria_dict.copy()

    # Mirror data types from the original rule's criteria
    original_criteria_str = rule.get("condition_criteria")
    if original_criteria_str and new_criteria_dict:
        try:
            original_criteria = json.loads(original_criteria_str)
            for key, new_value in new_criteria_dict.items():
                if key in original_criteria:
                    original_value = original_criteria[key]
                    if isinstance(original_value, (int, float)):
                        try:
                            # Attempt to cast new value to the original type
                            final_criteria[key] = type(original_value)(new_value)
                        except (ValueError, TypeError):
                            final_criteria[key] = new_value # Keep new value if cast fails
        except json.JSONDecodeError:
            pass # Ignore if original criteria is not valid JSON

    final_criteria_json_string = json.dumps(final_criteria) if final_criteria else None

    # Enforcement action: use the value the edit dialog sent if present and
    # valid; otherwise keep whatever the rule already had (so editing e.g.
    # just the description doesn't accidentally reset this field).
    VALID_ENFORCEMENT_ACTIONS = ("BLOCK_AND_AUDIT", "AUDIT_ONLY")
    enforcement_action = data.get("enforcement_action") or popup_data.get("enforcement_action")
    if enforcement_action not in VALID_ENFORCEMENT_ACTIONS:
        enforcement_action = rule.get("enforcement_action") or "BLOCK_AND_AUDIT"

    raw_email_alert = data.get("email_alert_enabled", popup_data.get("email_alert_enabled"))
    if raw_email_alert is None:
        email_alert_enabled = rule.get("email_alert_enabled")
        email_alert_enabled = True if email_alert_enabled is None else bool(email_alert_enabled)
    else:
        email_alert_enabled = bool(raw_email_alert)

    if "alert_group_id" in data or "alert_group_id" in popup_data:
        alert_group_id = data.get("alert_group_id") or popup_data.get("alert_group_id") or None
    else:
        alert_group_id = rule.get("alert_group_id") or None

    # --- Insert the formatted data into the requests table ---
    insert_query = f"""
        INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        (
            request_id, catalog, schema, table_name, column_name, rule_description,
            status, created_by, created_at, reviewed_by, reviewed_at, review_comments,
            condition_category, condition_type, condition_criteria, operation,
            severity, violation_threshold, enforcement_action,
            email_alert_enabled, alert_group_id
        )
        VALUES
        (
            :request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
            :status, :created_by, current_timestamp(), NULL, NULL, NULL,
            :condition_category, :condition_type, :condition_criteria, :operation,
            :severity, :violation_threshold, :enforcement_action,
            :email_alert_enabled, :alert_group_id
        )
    """
    # FIX: float(popup_data["violation_threshold"]) used to run unguarded —
    # an empty string or missing value (e.g. from a form field that failed
    # to pre-populate) raised an uncaught ValueError/TypeError here ("could
    # not convert string to float"). Fall back to the rule's current
    # violation_threshold so an untouched/blank field doesn't crash the
    # whole save.
    raw_violation_threshold = popup_data.get("violation_threshold")
    try:
        if raw_violation_threshold in (None, ""):
            raise ValueError("blank")
        violation_threshold = float(raw_violation_threshold)
    except (ValueError, TypeError):
        violation_threshold = rule.get("violation_threshold")
        try:
            violation_threshold = float(violation_threshold) if violation_threshold is not None else 0.0
        except (ValueError, TypeError):
            violation_threshold = 0.0

    insert_params = [
        {"name": "request_id", "type": "STRING", "value": str(rule_id)},
        {"name": "catalog", "type": "STRING", "value": rule["catalog_name"]},
        {"name": "schema", "type": "STRING", "value": rule["schema_name"]},
        {"name": "table_name", "type": "STRING", "value": rule["table_name"]},
        {"name": "column_name", "type": "STRING", "value": popup_data["column_name"]},
        {"name": "rule_description", "type": "STRING", "value": popup_data["rule_description"]},
        {"name": "status", "type": "STRING", "value": "pending"},
        {"name": "created_by", "type": "STRING", "value": rule["owner"]},
        {"name": "condition_category", "type": "STRING", "value": rule["condition_category"]},
        {"name": "condition_type", "type": "STRING", "value": rule["condition_type"]},
        {"name": "condition_criteria", "type": "STRING", "value": final_criteria_json_string},
        {"name": "operation", "type": "STRING", "value": "UPDATE"},
        {"name": "severity", "type": "STRING", "value": popup_data["severity"]},
        {"name": "violation_threshold", "type": "FLOAT", "value": violation_threshold},
        {"name": "enforcement_action", "type": "STRING", "value": enforcement_action},
        {"name": "email_alert_enabled", "type": "BOOLEAN", "value": email_alert_enabled},
        {"name": "alert_group_id", "type": "STRING", "value": alert_group_id}
    ]

    return query_table(f"insert_rule_request_{rule_id}", insert_query, insert_params)


def submit_delete_request(rule_id, requested_by):
    """
    NEW: Deleting an active rule now requires approval, matching how
    editing a rule already works. This submits a PENDING request
    (operation='DELETE') referencing the rule -- it does NOT touch
    dq_rules at all. The actual close-out (effective_date_to update)
    only happens once an approver calls approve_rule_request(), in
    Approval_logic.py's DELETE branch.
    """
    get_rule_query = f"""
        SELECT
            rule_id, catalog_name, schema_name, table_name, column_name,
            condition_category, condition_type, condition_criteria,
            rule_description, severity, violation_threshold, owner,
            enforcement_action, email_alert_enabled, alert_group_id
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = :ruleId
          AND effective_date_to = '9999-12-31T00:00:00.000+00:00'
    """
    params = [{"name": "ruleId", "type": "STRING", "value": rule_id}]
    rule_details = query_table(f"get_rule_for_delete_request_{rule_id}", get_rule_query, params)

    if not rule_details:
        raise Exception(f"No active rule found with rule_id: {rule_id}")
    rule = rule_details[0]

    insert_query = f"""
        INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        (
            request_id, catalog, schema, table_name, column_name, rule_description,
            status, created_by, created_at, reviewed_by, reviewed_at, review_comments,
            condition_category, condition_type, condition_criteria, operation,
            severity, violation_threshold, enforcement_action,
            email_alert_enabled, alert_group_id
        )
        VALUES
        (
            :request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
            :status, :created_by, current_timestamp(), NULL, NULL, NULL,
            :condition_category, :condition_type, :condition_criteria, :operation,
            :severity, :violation_threshold, :enforcement_action,
            :email_alert_enabled, :alert_group_id
        )
    """
    insert_params = [
        {"name": "request_id", "type": "STRING", "value": rule["rule_id"]},
        {"name": "catalog", "type": "STRING", "value": rule["catalog_name"]},
        {"name": "schema", "type": "STRING", "value": rule["schema_name"]},
        {"name": "table_name", "type": "STRING", "value": rule["table_name"]},
        {"name": "column_name", "type": "STRING", "value": rule["column_name"]},
        {"name": "rule_description", "type": "STRING", "value": rule.get("rule_description")},
        {"name": "status", "type": "STRING", "value": "pending"},
        {"name": "created_by", "type": "STRING", "value": requested_by or rule.get("owner")},
        {"name": "condition_category", "type": "STRING", "value": rule.get("condition_category")},
        {"name": "condition_type", "type": "STRING", "value": rule.get("condition_type")},
        {"name": "condition_criteria", "type": "STRING", "value": rule.get("condition_criteria")},
        {"name": "operation", "type": "STRING", "value": "DELETE"},
        {"name": "severity", "type": "STRING", "value": rule.get("severity")},
        {"name": "violation_threshold", "type": "FLOAT", "value": rule.get("violation_threshold") or 0.0},
        {"name": "enforcement_action", "type": "STRING", "value": rule.get("enforcement_action") or "BLOCK_AND_AUDIT"},
        {"name": "email_alert_enabled", "type": "BOOLEAN", "value": bool(rule.get("email_alert_enabled"))},
        {"name": "alert_group_id", "type": "STRING", "value": rule.get("alert_group_id")}
    ]

    return query_table(f"submit_delete_request_{rule_id}", insert_query, insert_params)


def delete_rule_data(ruleId):
    """
    RETAINED FOR INTERNAL USE ONLY -- do not call this directly from a
    Flask route. This performs the actual, immediate hard DELETE and now
    only runs as part of approve_rule_request()'s bookkeeping, if ever
    needed; the user-facing "delete a rule" action is submit_delete_request()
    above, which requires approval before anything happens to dq_rules.
    """
    query = f"""
        DELETE FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = :ruleId
    """
    params = [{"name": "ruleId", "type": "STRING", "value": ruleId}]
    
    return query_table(f"delete_rule_{ruleId}", query, params)