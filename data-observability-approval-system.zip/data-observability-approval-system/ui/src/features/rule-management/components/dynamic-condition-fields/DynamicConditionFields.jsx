import React, { useState, useEffect } from "react";
import { Box, TextField, MenuItem, Typography, Grid } from "@mui/material";

const conditionConfig = {
  NOT_NULL: {},
  BLANK: {},
  MUST_HAVE_VALUE: {
    fields: [{ name: "value", label: "Must Have Values (comma separated)", type: "array" }],
  },
  NOT_NULL_LENGTH_CHECK: {
    fields: [{ name: "value", label: "Minimum Length", type: "number" }],
  },
  REGEX_MATCH: {
    fields: [{ name: "regex_pattern", label: "Regex Pattern", type: "text" }],
  },
  LENGTH_CHECK: {
    fields: [{ name: "value", label: "Expected Length", type: "number" }],
  },
  FORMAT_CHECK: {
    fields: [{ name: "regex_pattern", label: "Format Regex", type: "text" }],
  },
  RANGE_CHECK: {
    fields: [
      { name: "min_value", label: "Minimum Value", type: "number" },
      { name: "max_value", label: "Maximum Value", type: "number" },
    ],
  },
  VALUE_THRESHOLD: {
    fields: [
      { name: "operator", label: "Operator", type: "select", options: [">", "<", ">=", "<=", "==", "!="] },
      { name: "value_threshold", label: "Threshold Value", type: "number" },
    ],
  },
  DATE_RANGE: {
    fields: [
      { name: "start_date", label: "Start Date", type: "date" },
      { name: "end_date", label: "End Date", type: "date" },
    ],
  },
  UNIQUE: {
    fields: [{ name: "identifier_column", label: "Identifier Column", type: "select", dynamicOptions: true }],
  },
  DUPLICATE: {},
  CUSTOM_RULE: {
    fields: [{ name: "custom_query", label: "Custom SQL Expression", type: "text" }],
  },
  CASE_STANDARDIZATION: {
    fields: [{ name: "case", label: "Standardization", type: "select", options: ["UPPER", "LOWER"] }],
  },
  MAPPING_CHECK: {
    fields: [{ name: "value", label: "Allowed Values (comma separated)", type: "array" }],
  },
  OUTLIER_DETECTION: {
    fields: [{ name: "value", label: "Sensitivity Level", type: "number" }],
  },
  TIME_STAMP_CHECK: {
    fields: [{ name: "condition", label: "Timestamp Condition", type: "text" }],
  },
  ROW_COUNT_TREND: {
    fields: [{ name: "interval", label: "Interval", type: "number" }],
  },
  KPI_CHECK: {
    fields: [
      { name: "custom_query", label: "Custom KPI Expression", type: "text" },
      { name: "lower_threshold", label: "Lower Threshold", type: "number" },
      { name: "upper_threshold", label: "Upper Threshold", type: "number" },
      { name: "interval", label: "Interval", type: "number" },
    ],
  },
};

const DynamicConditionFields = ({ category, type, columns = [], criteria = {}, onCriteriaChange }) => {
  const [formState, setFormState] = useState(criteria || {});
  const prevTypeRef = React.useRef(type);

  // Show existing criteria (e.g. LLM-generated or previously saved) when the
  // form opens; only clear the fields when the USER changes the rule type.
  useEffect(() => {
    if (prevTypeRef.current !== type) {
      prevTypeRef.current = type;
      setFormState({});
      onCriteriaChange?.({});
    } else {
      setFormState(criteria || {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const handleChange = (key, value) => {
    const updated = { ...formState, [key]: value };
    setFormState(updated);
    onCriteriaChange?.(updated);
  };

  const getFormattedValue = (fieldType, rawValue) => {
    if (rawValue === "" || rawValue === null) return fieldType === "number" ? null : rawValue;
    if (fieldType === "number") return Number(rawValue);
    if (fieldType === "array") return rawValue.split(",").map((v) => v.trim());
    return rawValue;
  };

  if (!category || !type) return null;

  const config = conditionConfig[type];
  const fields = config?.fields || [];

  if (fields.length === 0) {
    return (
      <Typography mt={2} color="text.secondary">
        No parameters needed for this rule type.
      </Typography>
    );
  }

  const isFullWidthField = (type, fieldName) => {
    if (type === "CUSTOM_RULE") return true;
    if (type === "KPI_CHECK" && fieldName === "custom_query") return true;
    return false;
  };

  return (
    <Grid container spacing={2}>
      {fields.map((field) => {
        const raw = formState[field.name] ?? "";
        // Arrays (e.g. MUST_HAVE_VALUE / MAPPING_CHECK lists) display as
        // comma-separated text, matching how the user types them.
        const value = Array.isArray(raw) ? raw.join(", ") : raw;

        const commonProps = {
          label: field.label,
          value,
          onChange: (e) => handleChange(field.name, getFormattedValue(field.type, e.target.value)),
          size: "small",
          sx: {
            fontFamily: "'Segoe UI', sans-serif",
            fontSize: "0.85rem",
            height: 32,
            width: isFullWidthField(type, field.name) ? "100%" : 145,
          },
          InputLabelProps: field.type === "date" ? { shrink: true } : {},
        };

        if (field.type === "select") {
          const options = field.dynamicOptions ? columns : field.options || [];
          return (
            <TextField {...commonProps} select key={field.name}>
              {options.map((opt) => (
                <MenuItem key={opt} value={opt}>
                  {opt}
                </MenuItem>
              ))}
            </TextField>
          );
        }

        return <TextField key={field.name} {...commonProps} type={field.type === "number" ? "number" : "text"} />;
      })}
    </Grid>
  );
};

export default DynamicConditionFields;
