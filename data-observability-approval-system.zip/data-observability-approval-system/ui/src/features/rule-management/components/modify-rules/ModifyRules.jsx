import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  TextField,
  Grid,
  CircularProgress,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
  Tooltip
} from "@mui/material";
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import DynamicConditionFields from "../../components/dynamic-condition-fields/DynamicConditionFields";
import { ruleManagementApi } from "../../../../services/ruleManagementApi";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

// Map condition types back to their categories
const getConditionCategory = (conditionType) => {
  const categoryToTypes = {
    "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
    "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
    "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
    "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
    "Business Logic Rules": ["CUSTOM_RULE"],
    "Consistency & Standardization Checks": ["CASE_STANDARDIZATION", "MAPPING_CHECK"],
    "Anomaly Detection": ["OUTLIER_DETECTION"],
    "Time-based Validations": ["TIME_STAMP_CHECK"],
    "Trend Analysis": ["ROW_COUNT_TREND"],
    "KPI Statistics": ["KPI_CHECK"],
  };

  for (const [category, types] of Object.entries(categoryToTypes)) {
    if (types.includes(conditionType)) {
      return category;
    }
  }
  return "";
};

const ModifyRules = ({ open, rule, allColumns, onClose, onSave, columnsLoading }) => {
  const [editedRule, setEditedRule] = React.useState(rule || {});
  const [saving, setSaving] = React.useState(false);
  const [snackbarOpen, setSnackbarOpen] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState('');
  const [snackbarSeverity, setSnackbarSeverity] = React.useState('success');

  React.useEffect(() => {
  if (rule) {
    // Debug: Log the entire rule object to see its structure
    console.log("Full Rule object:", rule);
    console.log("All rule keys:", Object.keys(rule));
    console.log("Rule object with values:", JSON.stringify(rule, null, 2));

    console.log("Rule condition type:", rule.conditionType || rule.condition_type);
    
    // Check what column-related fields exist for MUST_HAVE_VALUE
    if ((rule.conditionType || rule.condition_type) === 'MUST_HAVE_VALUE') {
      console.log("MUST_HAVE_VALUE rule - checking column fields:");
      console.log("rule.column_name:", rule.column_name);
      console.log("rule.columns:", rule.columns);
      console.log("rule.columnName:", rule.columnName);
      console.log("rule.column:", rule.column);
    }
  

    // Try multiple possible field names for columns
    let parsedColumns = [];
    
    
      // Check all possible column field names
      if (rule.column_name) {
        console.log("Found column_name:", rule.column_name);
        parsedColumns = rule.column_name.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.columns && Array.isArray(rule.columns)) {
        console.log("Found columns array:", rule.columns);
        parsedColumns = rule.columns;
      } else if (rule.columns && typeof rule.columns === 'string') {
        console.log("Found columns string:", rule.columns);
        parsedColumns = rule.columns.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.columnName) {
        console.log("Found columnName:", rule.columnName);
        parsedColumns = rule.columnName.split(",").map(col => col.trim()).filter(col => col);
      } else if (rule.column) {
        console.log("Found column:", rule.column);
        parsedColumns = Array.isArray(rule.column) ? rule.column : rule.column.split(",").map(col => col.trim()).filter(col => col);
      }

      // Parse condition criteria - check all possible field names
      let parsedCriteria = {};
      try {
        const criteriaString = rule.condition_criteria || 
                              rule.conditionCriteria || 
                              rule.condition_criteria_json || 
                              rule.criteria || 
                              null;
        
        console.log('Raw criteria from rule:', criteriaString);
        
        if (criteriaString) {
          if (typeof criteriaString === 'string') {
            parsedCriteria = JSON.parse(criteriaString);
          } else if (typeof criteriaString === 'object') {
            parsedCriteria = criteriaString;
          }
        }
      } catch (error) {
        console.warn('Failed to parse condition criteria:', error);
        parsedCriteria = {};
      }

      // Get condition type and derive category if missing
      const conditionType = rule.conditionType || rule.condition_type || "";
      const conditionCategory = rule.conditionCategory || rule.condition_category || getConditionCategory(conditionType);

      setEditedRule({
        ...rule,
        rule_id: rule.rule_id || rule.Rule_id || rule.id,
        columns: parsedColumns,
        rule_description: rule.rule_description || rule.description || "",
        severity: rule.severity || "Warning",
        violation_threshold: rule.violation_threshold || rule.violationThreshold || "",
        conditionCriteria: parsedCriteria,
        conditionCategory: conditionCategory,
        conditionType: conditionType,
        condition_criteria: JSON.stringify(parsedCriteria, null, 2),
        enforcement_action: rule.enforcement_action || "BLOCK_AND_AUDIT",
      });
    }
  }, [rule]);

  const handleChange = (field, value) => {
    // If field is condition_criteria and value is an object, stringify it
    if (field === "condition_criteria" && typeof value === 'object' && value !== null) {
      value = JSON.stringify(value, null, 2);
    }
    
 
    if (field === "condition_criteria" && editedRule.condition_criteria) {
      // Check if the new value is empty (empty string, "{}", or whitespace)
      const isEmpty = !value || 
                     value === "" || 
                     value === "{}" || 
                     value.trim() === "" || 
                     value.trim() === "{}";
      
      if (isEmpty) {
        return; // Don't update with empty value
      }
    }
    
    setEditedRule({ ...editedRule, [field]: value });
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };

  const handleSave = async () => {
    if (!editedRule || !editedRule.rule_id) {
      setSnackbarMessage("Error: Rule ID is missing.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return;
    }

   // Ensure conditionCriteria is properly formatted
    let criteriaToSave = editedRule.conditionCriteria || {};
    if (typeof criteriaToSave === 'string') {
      try {
        criteriaToSave = JSON.parse(criteriaToSave);
      } catch (e) {
        criteriaToSave = {};
      }
    }

    // Remove rawValue before saving (it's only for UI purposes)
    if (criteriaToSave.rawValue !== undefined) {
      const { rawValue, ...cleanCriteria } = criteriaToSave;
      criteriaToSave = cleanCriteria;
    }

    console.log("About to save - editedRule.conditionCriteria:", editedRule.conditionCriteria);
    console.log("About to save - criteriaToSave:", criteriaToSave);
    console.log("About to save - stringified:", JSON.stringify(criteriaToSave));

    const payload = {
      rule_description: editedRule.rule_description,
      severity: editedRule.severity,
      violation_threshold: editedRule.violation_threshold,
      column_name: (editedRule.columns || []).join(", "),
      condition_criteria: JSON.stringify(criteriaToSave),
      created_by: editedRule.created_by || "test_user",
      enforcement_action: editedRule.enforcement_action || "BLOCK_AND_AUDIT"
    };

    console.log("Full payload being sent:", payload);

    try {
      setSaving(true);
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/rules/${editedRule.rule_id}/save_request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (response.ok) {
        setSnackbarMessage(result.message || "Rule updated successfully!");
        setSnackbarSeverity("success");
        setSnackbarOpen(true);
        onSave();
        onClose();
      } else {
        setSnackbarMessage(result.error || "Failed to update rule.");
        setSnackbarSeverity("error");
        setSnackbarOpen(true);
      }
    } catch (error) {
      setSnackbarMessage(`Error: ${error.message}`);
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box p={1}>
      <Dialog
        open={open}
        onClose={onClose}
        maxWidth={false}
        sx={{
          "& .MuiDialog-paper": {
            width: "355px",  
            maxWidth: "90%",  
          },
        }}
      >
        {/* <DialogTitle>Edit Rule - {editedRule.conditionType}</DialogTitle> */}
         <DialogTitle sx={{ 
          wordBreak: 'break-word',
          overflowWrap: 'break-word',
          whiteSpace: 'normal'
        }}>
          Edit Rule - {editedRule.conditionType}
        </DialogTitle>
        <DialogContent dividers>
          <Box display="flex" flexDirection="column" gap={2}>
            {/* Columns */}
            <Box>
              <FormControl fullWidth size="small">
                <InputLabel>Columns</InputLabel>
                <Select
                  multiple
                  value={editedRule.columns || []}
                  onChange={(e) => {
                    console.log("Selected columns:", e.target.value);
                    handleChange("columns", e.target.value);
                  }}
                  input={<OutlinedInput label="Columns" />}
                  renderValue={(selected) => {
                    console.log("Render value - selected:", selected);
                    return selected.join(", ");
                  }}
                  disabled={columnsLoading}
                >
                  {columnsLoading ? (
                    <MenuItem disabled>Loading columns...</MenuItem>
                  ) : (
                    allColumns.map((col) => {
                      const isChecked = (editedRule.columns || []).includes(col);
                      if (isChecked) {
                        console.log(`Column "${col}" should be checked`);
                      }
                      return (
                        <MenuItem key={col} value={col}>
                          <Checkbox checked={isChecked} />
                          <ListItemText primary={col} />
                        </MenuItem>
                      );
                    })
                  )}
                </Select>
              </FormControl>
            </Box>

            {/* Description */}
            <Box>
              <textarea
                value={editedRule.rule_description || ""}
                onChange={(e) => handleChange("rule_description", e.target.value)}
                placeholder="Enter Rule description"
                rows={4}
                style={{
                  width: '100%',
                  padding: '10px 14px',
                  fontSize: '0.85rem',
                  borderRadius: '4px',
                  border: '1px solid rgba(0, 0, 0, 0.23)',
                  backgroundColor: '#fff',
                  fontFamily: 'Segoe-UI, Helvetica, Arial, sans-serif',
                  boxSizing: 'border-box',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                  outline: 'none',
                  resize: 'none',
                  lineHeight: 1.2,
                }}
                onFocus={(e) => {
                  e.target.style.border = '1px solid #1976d2';
                  e.target.style.boxShadow = '0 0 0 1px #1976d2';
                }}
                onBlur={(e) => {
                  e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </Box>

            {/* Condition Criteria Fields - Pre-populated */}
            <Box>
              {editedRule.conditionType === 'LENGTH_CHECK' && (
                <TextField
                  fullWidth
                  label="Expected Length"
                  type="number"
                  value={editedRule.conditionCriteria?.value || editedRule.conditionCriteria?.expected_length || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, value: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}
              
              {editedRule.conditionType === 'NOT_NULL_LENGTH_CHECK' && (
                <TextField
                  fullWidth
                  label="Minimum Length"
                  type="number"
                  value={editedRule.conditionCriteria?.value || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, value: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}
              
              {editedRule.conditionType === 'REGEX_MATCH' && (
                <TextField
                  fullWidth
                  label="Regex Pattern"
                  value={editedRule.conditionCriteria?.regex_pattern || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, regex_pattern: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}
              
              {editedRule.conditionType === 'DATE_RANGE' && (
                <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                  <TextField
                    label="Start Date"
                    type="date"
                    value={editedRule.conditionCriteria?.start_date || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, start_date: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                    slotProps={{ inputLabel: { shrink: true } }}
                  />
                  <TextField
                    label="End Date"
                    type="date"
                    value={editedRule.conditionCriteria?.end_date || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, end_date: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                    slotProps={{ inputLabel: { shrink: true } }}
                  />
                </Box>
              )}
              
              {editedRule.conditionType === 'RANGE_CHECK' && (
                <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                  <TextField
                    label="Minimum Value"
                    type="number"
                    value={editedRule.conditionCriteria?.min_value || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, min_value: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                  />
                  <TextField
                    label="Maximum Value"
                    type="number"
                    value={editedRule.conditionCriteria?.max_value || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, max_value: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                  />
                </Box>
              )}

              {editedRule.conditionType === 'VALUE_THRESHOLD' && (
                <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel>Operator</InputLabel>
                    <Select
                      value={editedRule.conditionCriteria?.operator || ""}
                      onChange={(e) => {
                        const updatedCriteria = { ...editedRule.conditionCriteria, operator: e.target.value };
                        setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                      }}
                      label="Operator"
                    >
                      <MenuItem value=">">&gt;</MenuItem>
                      <MenuItem value="<">&lt;</MenuItem>
                      <MenuItem value=">=">&gt;=</MenuItem>
                      <MenuItem value="<=">&lt;=</MenuItem>
                      <MenuItem value="==">=</MenuItem>
                      <MenuItem value="!=">!=</MenuItem>
                    </Select>
                  </FormControl>
                  <TextField
                    label="Threshold Value"
                    type="number"
                    value={editedRule.conditionCriteria?.value_threshold || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, value_threshold: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                  />
                </Box>
              )}

              {editedRule.conditionType === 'UNIQUE' && (
                <FormControl fullWidth size="small" sx={{ marginBottom: 2 }}>
                  <InputLabel>Identifier Column</InputLabel>
                  <Select
                    value={editedRule.conditionCriteria?.identifier_column || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, identifier_column: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    label="Identifier Column"
                    disabled={columnsLoading}
                  >
                    {columnsLoading ? (
                      <MenuItem disabled>Loading columns...</MenuItem>
                    ) : (
                      allColumns.map((col) => (
                        <MenuItem key={col} value={col}>
                          {col}
                        </MenuItem>
                      ))
                    )}
                  </Select>
                </FormControl>
              )}

              {editedRule.conditionType === 'MUST_HAVE_VALUE' && (
                <TextField
                  fullWidth
                  label="Valid Values (comma separated)"
                  value={editedRule.conditionCriteria?.rawValue !== undefined 
                    ? editedRule.conditionCriteria.rawValue 
                    : (editedRule.conditionCriteria?.value ? editedRule.conditionCriteria.value.join(', ') : "")}
                  onChange={(e) => {
                    // Store the raw input value without processing
                    const updatedCriteria = { 
                      ...editedRule.conditionCriteria, 
                      rawValue: e.target.value,
                      value: editedRule.conditionCriteria?.value || []
                    };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  onBlur={(e) => {
                    // Process the values only when focus leaves the field
                    const processedValues = e.target.value.split(',').map(v => v.trim()).filter(v => v);
                    const updatedCriteria = { 
                      ...editedRule.conditionCriteria, 
                      value: processedValues,
                      rawValue: processedValues.join(', ') // Store clean formatted version
                    };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                  helperText="Enter values separated by commas"
                />
              )}

              {editedRule.conditionType === 'OUTLIER_DETECTION' && (
                <TextField
                  fullWidth
                  label="Sensitivity Level"
                  type="number"
                  value={editedRule.conditionCriteria?.value || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, value: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}

              {editedRule.conditionType === 'TIME_STAMP_CHECK' && (
                <TextField
                  fullWidth
                  label="Timestamp Condition"
                  value={editedRule.conditionCriteria?.condition || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, condition: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}

              {editedRule.conditionType === 'FORMAT_CHECK' && (
                <TextField
                  fullWidth
                  label="Format Regex"
                  value={editedRule.conditionCriteria?.regex_pattern || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, regex_pattern: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                  sx={{ marginBottom: 2 }}
                />
              )}

             {editedRule.conditionType === 'MAPPING_CHECK' && (
              <TextField
                fullWidth
                label="Allowed Values (comma separated)"
                value={editedRule.conditionCriteria?.rawValue !== undefined 
                  ? editedRule.conditionCriteria.rawValue 
                  : (editedRule.conditionCriteria?.value ? editedRule.conditionCriteria.value.join(',') : "")}
                onChange={(e) => {
                  // Remove all spaces - only allow commas and alphanumeric characters
                  const noSpaces = e.target.value.replace(/\s/g, '');
                  const updatedCriteria = { 
                    ...editedRule.conditionCriteria, 
                    rawValue: noSpaces,
                    value: editedRule.conditionCriteria?.value || []
                  };
                  setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                }}
                onBlur={(e) => {
                  // Process the values when focus leaves - split by comma only
                  const processedValues = e.target.value.split(',').filter(v => v);
                  const updatedCriteria = { 
                    ...editedRule.conditionCriteria, 
                    value: processedValues,
                    rawValue: processedValues.join(',') // No spaces in stored format
                  };
                  setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                }}
                size="small"
                sx={{ marginBottom: 2 }}
                helperText="Enter values separated by commas (no spaces)"
              />
            )}

            {editedRule.conditionType === 'ROW_COUNT_TREND' && (
              <TextField
                fullWidth
                label="Interval"
                type="number"
                value={editedRule.conditionCriteria?.interval || ""}
                onChange={(e) => {
                  const updatedCriteria = { ...editedRule.conditionCriteria, interval: e.target.value };
                  setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                }}
                size="small"
                sx={{ marginBottom: 2 }}
              />
            )}
            
            {editedRule.conditionType === 'CASE_STANDARDIZATION' && (
              <FormControl fullWidth size="small" sx={{ marginBottom: 2 }}>
                <InputLabel>Standardization</InputLabel>
                <Select
                  value={editedRule.conditionCriteria?.case || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, case: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  label="Standardization"
                >
                  <MenuItem value="UPPER">UPPER</MenuItem>
                  <MenuItem value="LOWER">LOWER</MenuItem>
                </Select>
              </FormControl>
            )}

            {editedRule.conditionType === 'KPI_CHECK' && (
              <Box sx={{ marginBottom: 2 }}>
                <Box sx={{ marginBottom: 2 }}>
                  <Typography 
                    variant="caption" 
                    sx={{ 
                      color: 'rgba(0, 0, 0, 0.6)', 
                      marginBottom: '4px',
                      display: 'block',
                      fontSize: '0.75rem'
                    }}
                  >
                    Custom KPI Expression
                  </Typography>
                  <textarea
                    value={editedRule.conditionCriteria?.custom_query || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, custom_query: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    placeholder="Enter Custom KPI Expression"
                    rows={5}
                    style={{
                      width: '100%',
                      padding: '10px 14px',
                      fontSize: '0.85rem',
                      borderRadius: '4px',
                      border: '1px solid rgba(0, 0, 0, 0.23)',
                      backgroundColor: '#fff',
                      fontFamily: 'Segoe-UI, Helvetica, Arial, sans-serif',
                      boxSizing: 'border-box',
                      transition: 'border-color 0.2s, box-shadow 0.2s',
                      outline: 'none',
                      resize: 'vertical',
                      lineHeight: 1.2,
                      overflow: 'auto',
                    }}
                    onFocus={(e) => {
                      e.target.style.border = '1px solid #1976d2';
                      e.target.style.boxShadow = '0 0 0 1px #1976d2';
                    }}
                    onBlur={(e) => {
                      e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                      e.target.style.boxShadow = 'none';
                    }}
                  />
                </Box>
                <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
                  <TextField
                    label="Lower Threshold"
                    type="number"
                    value={editedRule.conditionCriteria?.lower_threshold || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, lower_threshold: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                  />
                  <TextField
                    label="Upper Threshold"
                    type="number"
                    value={editedRule.conditionCriteria?.upper_threshold || ""}
                    onChange={(e) => {
                      const updatedCriteria = { ...editedRule.conditionCriteria, upper_threshold: e.target.value };
                      setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                    }}
                    size="small"
                    sx={{ flex: 1 }}
                  />
                </Box>
                <TextField
                  fullWidth
                  label="Interval"
                  type="number"
                  value={editedRule.conditionCriteria?.interval || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, interval: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  size="small"
                />
              </Box>
            )}
            {editedRule.conditionCriteria?.custom_query !== undefined && editedRule.conditionType !== 'KPI_CHECK' && (
              <Box sx={{ marginBottom: 2 }}>
                <Typography 
                  variant="caption" 
                  sx={{ 
                    color: 'rgba(0, 0, 0, 0.6)', 
                    marginBottom: '4px',
                    display: 'block',
                    fontSize: '0.75rem'
                  }}
                >
                  Custom SQL Expression
                </Typography>
                <textarea
                  value={editedRule.conditionCriteria?.custom_query || ""}
                  onChange={(e) => {
                    const updatedCriteria = { ...editedRule.conditionCriteria, custom_query: e.target.value };
                    setEditedRule({ ...editedRule, conditionCriteria: updatedCriteria });
                  }}
                  placeholder="Enter Custom SQL Expression"
                  rows={5}
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    fontSize: '0.85rem',
                    borderRadius: '4px',
                    border: '1px solid rgba(0, 0, 0, 0.23)',
                    backgroundColor: '#fff',
                    fontFamily: 'Segoe-UI, Helvetica, Arial, sans-serif',
                    boxSizing: 'border-box',
                    transition: 'border-color 0.2s, box-shadow 0.2s',
                    outline: 'none',
                    resize: 'vertical',
                    lineHeight: 1.2,
                    overflow: 'auto',
                  }}
                  onFocus={(e) => {
                    e.target.style.border = '1px solid #1976d2';
                    e.target.style.boxShadow = '0 0 0 1px #1976d2';
                  }}
                  onBlur={(e) => {
                    e.target.style.border = '1px solid rgba(0, 0, 0, 0.23)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </Box>
            )}

            </Box>




              

              

            {/* Condition Parameters (Dynamic Fields) - Only for types not handled above
            {!['LENGTH_CHECK', 'NOT_NULL_LENGTH_CHECK', 'REGEX_MATCH', 'DATE_RANGE', 'RANGE_CHECK', 'VALUE_THRESHOLD', 'UNIQUE', 'MUST_HAVE_VALUE'].includes(editedRule.conditionType) && (
              <DynamicConditionFields
                category={editedRule.conditionCategory}
                type={editedRule.conditionType}
                columns={editedRule.columns}
                value={editedRule.conditionCriteria}
                defaultValue={editedRule.conditionCriteria}
                onCriteriaChange={(updated) => handleChange("condition_criteria", updated)}
              />
            )} */}


            {/* Condition Parameters (Dynamic Fields) - Only for types not handled above */}
            {!['LENGTH_CHECK', 'NOT_NULL_LENGTH_CHECK', 'REGEX_MATCH', 'DATE_RANGE', 'RANGE_CHECK', 'VALUE_THRESHOLD', 'UNIQUE', 'MUST_HAVE_VALUE', 'ROW_COUNT_TREND', 'TIME_STAMP_CHECK', 'OUTLIER_DETECTION', 'FORMAT_CHECK', 'MAPPING_CHECK', 'CASE_STANDARDIZATION','DUPLICATE','KPI_CHECK'].includes(editedRule.conditionType) && !editedRule.conditionCriteria?.custom_query && (              
              <Box sx={{ textAlign: 'center', width: '100%'  }}>
                <DynamicConditionFields
                  category={editedRule.conditionCategory}
                  type={editedRule.conditionType}
                  columns={editedRule.columns}
                  value={editedRule.conditionCriteria}
                  defaultValue={editedRule.conditionCriteria}
                  onCriteriaChange={(updated) => handleChange("condition_criteria", updated)}
                />
              </Box>
            )}
            <Grid container spacing={2} mt={1} justifyContent={"space-between"}>
              <Grid item xs={12} md={6}>
                <Box>
                  {/* Severity */}
                  <FormControl size="small" sx={{width: 145}}>
                    <InputLabel>Severity</InputLabel>
                    <Select
                      value={editedRule.severity || ""}
                      onChange={(e) => handleChange("severity", e.target.value)}
                      label="Severity"
                    >
                      <MenuItem value="Warning">Warning</MenuItem>
                      <MenuItem value="Critical">Critical</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
              </Grid>

              <Grid item xs={12} md={6}>
                <Box>
                  {/* Threshold */}
                  <TextField
                    label="Violation Threshold (%)"
                    type="number"
                    size="small"
                    value={editedRule.violation_threshold || ""}
                    onChange={(e) => handleChange("violation_threshold", e.target.value)}
                    sx={{width: 145}}
                  />
                </Box>
              </Grid>
            </Grid>

            <Box mt={2}>
              <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 0.5 }}>
                On failure
              </Typography>
              <ToggleButtonGroup
                value={editedRule.enforcement_action || "BLOCK_AND_AUDIT"}
                exclusive
                size="small"
                fullWidth
                onChange={(event, newValue) => {
                  if (newValue) handleChange("enforcement_action", newValue);
                }}
              >
                <ToggleButton value="BLOCK_AND_AUDIT" sx={{ textTransform: "none", gap: 0.75 }}>
                  <Tooltip title="Bad records are held back from Silver and logged to dq_bad_records">
                    <Box display="flex" alignItems="center" gap={0.75}>
                      <FilterAltIcon fontSize="small" />
                      Filter & audit
                    </Box>
                  </Tooltip>
                </ToggleButton>
                <ToggleButton value="AUDIT_ONLY" sx={{ textTransform: "none", gap: 0.75 }}>
                  <Tooltip title="Bad records still move to Silver, but are also logged to dq_bad_records">
                    <Box display="flex" alignItems="center" gap={0.75}>
                      <FactCheckIcon fontSize="small" />
                      Audit only
                    </Box>
                  </Tooltip>
                </ToggleButton>
              </ToggleButtonGroup>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose} color="inherit" disabled={saving}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            color="primary"
            disabled={saving}
          >
            {saving ? <CircularProgress size={20} /> : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setSnackbarOpen(false)}
          severity={snackbarSeverity}
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ModifyRules;
