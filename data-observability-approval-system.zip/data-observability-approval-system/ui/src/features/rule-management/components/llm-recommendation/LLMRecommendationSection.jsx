import React, { useState, useEffect } from "react";
import {
    Box, Button, Typography, TextField, Select, MenuItem, FormControl,
    InputLabel, OutlinedInput, CircularProgress, Alert, Table, TableBody,
    TableCell, TableContainer, TableHead, TableRow, Paper, Chip, Tooltip, IconButton
} from "@mui/material";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

const API_BASE_URL = import.meta.env.VITE_API_URL;

const severityColor = (severity) => {
    switch (severity) {
        case "Critical": return "error";
        case "Warning": return "warning";
        default: return "info";
    }
};

/**
 * LLM Recommendation section shown on the Add Rules page, above the
 * manual "Add Rule" forms. Takes catalog (fixed from app config),
 * schema and table, and generates rule recommendations using the
 * Databricks LLM. Recommended rules can be pushed into the manual
 * rule list below for review and submission.
 */
const LLMRecommendationSection = ({ config, onAddRules }) => {
    const defaultCatalog = config?.catalog || "";

    const [catalogs, setCatalogs] = useState([]);
    const [schemas, setSchemas] = useState([]);
    const [tables, setTables] = useState([]);
    const [selectedCatalog, setSelectedCatalog] = useState("");
    const [selectedSchema, setSelectedSchema] = useState("");
    const [selectedTable, setSelectedTable] = useState("");

    const [loadingMeta, setLoadingMeta] = useState({ catalogs: false, schemas: false, tables: false });
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState(null);
    const [recommendations, setRecommendations] = useState([]);
    const [addedIndexes, setAddedIndexes] = useState([]);

    // Load ALL catalogs in the environment; default selection to the configured catalog
    useEffect(() => {
        setLoadingMeta(prev => ({ ...prev, catalogs: true }));
        fetch(`${API_BASE_URL}/api/catalog-meta`)
            .then(res => res.json())
            .then(data => {
                let list = Array.isArray(data) ? data.map(row => row.catalog_name) : [];
                if (defaultCatalog && !list.includes(defaultCatalog)) {
                    list = [defaultCatalog, ...list];
                }
                setCatalogs(list);
                setSelectedCatalog(prev => prev || defaultCatalog || list[0] || "");
            })
            .catch(err => {
                console.error("Failed to load catalogs:", err);
                if (defaultCatalog) {
                    setCatalogs([defaultCatalog]);
                    setSelectedCatalog(defaultCatalog);
                }
            })
            .finally(() => setLoadingMeta(prev => ({ ...prev, catalogs: false })));
    }, [defaultCatalog]);

    // Load schemas whenever the selected catalog changes
    useEffect(() => {
        setSelectedSchema("");
        setSchemas([]);
        if (!selectedCatalog) return;
        setLoadingMeta(prev => ({ ...prev, schemas: true }));
        fetch(`${API_BASE_URL}/api/schema-meta?catalog=${selectedCatalog}`)
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    setSchemas(data.map(row => row.schema_name));
                }
            })
            .catch(err => console.error("Failed to load schemas:", err))
            .finally(() => setLoadingMeta(prev => ({ ...prev, schemas: false })));
    }, [selectedCatalog]);

    // Load tables when the schema changes
    useEffect(() => {
        setSelectedTable("");
        setTables([]);
        if (!selectedCatalog || !selectedSchema) return;
        setLoadingMeta(prev => ({ ...prev, tables: true }));
        fetch(`${API_BASE_URL}/api/table-meta?catalog=${selectedCatalog}&schema=${selectedSchema}`)
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    setTables(data.map(row => row.table_name));
                }
            })
            .catch(err => console.error("Failed to load tables:", err))
            .finally(() => setLoadingMeta(prev => ({ ...prev, tables: false })));
    }, [selectedCatalog, selectedSchema]);

    const handleGenerate = async () => {
        setGenerating(true);
        setError(null);
        setRecommendations([]);
        setAddedIndexes([]);

        try {
            const response = await fetch(`${API_BASE_URL}/api/rules/recommend`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    catalog: selectedCatalog,
                    schema: selectedSchema,
                    table: selectedTable,
                }),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.error || `Request failed with status ${response.status}`);
            }
            if (data.results && data.results.length > 0) {
                setRecommendations(data.results);
            } else {
                setError("No recommendations were generated for this table.");
            }
        } catch (err) {
            setError(err.message || "Failed to communicate with the LLM engine.");
        } finally {
            setGenerating(false);
        }
    };

    // Convert a backend recommendation into the shape used by the manual RuleForm
    const toFormRule = (rec) => {
        let criteria = {};
        if (rec.condition_criteria) {
            try {
                const parsed = typeof rec.condition_criteria === "string"
                    ? JSON.parse(rec.condition_criteria)
                    : rec.condition_criteria;
                if (parsed && typeof parsed === "object") criteria = parsed;
            } catch {
                criteria = {};
            }
        }
        return {
            catalog: rec.catalog,
            schema: rec.schema,
            table: rec.table_name,
            columns: rec.column_name ? rec.column_name.split(",") : [],
            conditionCategory: rec.condition_category,
            conditionType: rec.condition_type,
            ruleDescription: rec.rule_description || "",
            severity: rec.severity || "Warning",
            threshold: rec.violation_threshold ?? "",
            criteria: criteria,
            source: "llm_generated",
            enforcementAction: rec.enforcement_action || "BLOCK_AND_AUDIT",
        };
    };

    const handleAddOne = (index) => {
        onAddRules([toFormRule(recommendations[index])]);
        setAddedIndexes(prev => [...prev, index]);
    };

    const handleAddAll = () => {
        const remaining = recommendations
            .map((rec, i) => ({ rec, i }))
            .filter(({ i }) => !addedIndexes.includes(i));
        onAddRules(remaining.map(({ rec }) => toFormRule(rec)));
        setAddedIndexes(recommendations.map((_, i) => i));
    };

    return (
        <Box
            mt={2}
            mb={3}
            p={3}
            sx={{
                border: "1px solid #e0e0e0",
                borderRadius: 2,
                background: "linear-gradient(180deg, #f8fbff 0%, #ffffff 60%)",
            }}
        >
            <Box display="flex" alignItems="center" gap={1} mb={2}>
                <AutoAwesomeIcon fontSize="small" color="primary" />
                <Typography variant="subtitle1" fontWeight={600}>
                    LLM Recommendation
                </Typography>
                <Typography variant="caption" color="text.secondary">
                    — select a table and let the Databricks LLM suggest data quality rules
                </Typography>
            </Box>

            <Box display="flex" gap={2} alignItems="center" flexWrap="wrap">
                <FormControl size="small" sx={{ minWidth: 200 }}>
                    <InputLabel>Catalog *</InputLabel>
                    <Select
                        value={selectedCatalog}
                        onChange={(e) => setSelectedCatalog(e.target.value)}
                        input={<OutlinedInput label="Catalog *" />}
                        disabled={loadingMeta.catalogs}
                    >
                        {catalogs.map((c) => (
                            <MenuItem key={c} value={c}>{c}</MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <FormControl size="small" sx={{ minWidth: 200 }}>
                    <InputLabel>Schema *</InputLabel>
                    <Select
                        value={selectedSchema}
                        onChange={(e) => setSelectedSchema(e.target.value)}
                        input={<OutlinedInput label="Schema *" />}
                        disabled={!selectedCatalog || loadingMeta.schemas}
                    >
                        {schemas.map((s) => (
                            <MenuItem key={s} value={s}>{s}</MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <FormControl size="small" sx={{ minWidth: 200 }}>
                    <InputLabel>Table *</InputLabel>
                    <Select
                        value={selectedTable}
                        onChange={(e) => setSelectedTable(e.target.value)}
                        input={<OutlinedInput label="Table *" />}
                        disabled={!selectedSchema || loadingMeta.tables}
                    >
                        {tables.map((t) => (
                            <MenuItem key={t} value={t}>{t}</MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <Button
                    variant="contained"
                    onClick={handleGenerate}
                    disabled={!selectedTable || generating}
                    startIcon={generating
                        ? <CircularProgress size={16} color="inherit" />
                        : <AutoAwesomeIcon fontSize="small" />}
                    sx={{ textTransform: "none" }}
                >
                    {generating ? "Generating..." : "Generate"}
                </Button>
            </Box>

            {generating && (
                <Typography variant="body2" color="primary" mt={2}>
                    Profiling the table and asking the LLM for recommendations… this can take a minute.
                </Typography>
            )}

            {error && (
                <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>
            )}

            {recommendations.length > 0 && (
                <Box mt={3}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                        <Typography variant="body2" color="text.secondary">
                            {recommendations.length} rules recommended — review and add the ones you want, then submit below.
                        </Typography>
                        <Button
                            size="small"
                            variant="outlined"
                            onClick={handleAddAll}
                            disabled={addedIndexes.length === recommendations.length}
                            sx={{ textTransform: "none" }}
                        >
                            Add All to Rules
                        </Button>
                    </Box>

                    <TableContainer component={Paper} variant="outlined">
                        <Table size="small">
                            <TableHead>
                                <TableRow sx={{ background: "#f8fafc" }}>
                                    <TableCell>Column</TableCell>
                                    <TableCell>Rule Description</TableCell>
                                    <TableCell>Category</TableCell>
                                    <TableCell>Condition Type</TableCell>
                                    <TableCell>Severity</TableCell>
                                    <TableCell align="center">Add</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {recommendations.map((rule, index) => (
                                    <TableRow key={index} hover>
                                        <TableCell><b>{rule.column_name}</b></TableCell>
                                        <TableCell>{rule.rule_description}</TableCell>
                                        <TableCell>{rule.condition_category}</TableCell>
                                        <TableCell><code>{rule.condition_type}</code></TableCell>
                                        <TableCell>
                                            <Chip
                                                label={rule.severity}
                                                size="small"
                                                color={severityColor(rule.severity)}
                                                variant="outlined"
                                            />
                                        </TableCell>
                                        <TableCell align="center">
                                            <Tooltip title={addedIndexes.includes(index) ? "Added" : "Add to rules below"}>
                                                <span>
                                                    <IconButton
                                                        size="small"
                                                        color="primary"
                                                        disabled={addedIndexes.includes(index)}
                                                        onClick={() => handleAddOne(index)}
                                                    >
                                                        <AddCircleOutlineIcon fontSize="small" />
                                                    </IconButton>
                                                </span>
                                            </Tooltip>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            )}
        </Box>
    );
};

export default LLMRecommendationSection;
