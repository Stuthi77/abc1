import time
import requests
import json
import yaml
import os
from config import config

# --- Configuration Loading ---
# Load config.yaml, assuming it's one directory level up from the current file's location.
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")

with open(CONFIG_PATH, "r") as f:
    yaml_config = yaml.safe_load(f)

# Assign global configuration variables
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
RULE_TABLE = yaml_config.get("rule_table")
TABLE_CONFIG = yaml_config.get("table_config")
PIPELINE_METADATA = yaml_config.get("pipeline_metadata")


# --- Databricks Query Engine ---
def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API.

    Polls for the result and returns formatted data upon success, or raises
    an exception on failure.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    # Add parameters to the payload if they are provided
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    # Poll for the statement status
    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            schema = manifest.get("schema", {})
            columns = [col["name"] for col in schema.get("columns", [])]
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            
            # Format data as a list of dictionaries
            formatted_data = [dict(zip(columns, row)) for row in data_array]
            return formatted_data
        
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            error_message = error.get('message', 'Unknown error')
            raise Exception(f"Query '{name}' failed: {error_message}")
        
        time.sleep(1)


# --- Data Retrieval Functions ---

def get_tables_data(search=None, severity=None, group_id=None, status=None, **kwargs):
    """
    Builds and executes the SQL for the main card view, fetching table metadata.
    If a group_id is provided, it joins with the table configuration to filter results.
    """
    params = []
    
    # Conditionally build the subquery based on whether a group_id is provided
    if group_id:
        t1_subquery = f"""
            (
                SELECT
                    r.table_name,
                    r.schema_name,
                    r.catalog_name,
                    COUNT(r.rule_id) AS rules_count
                FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
                JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS tbls
                    ON r.catalog_name = tbls.catalog_name
                    AND r.schema_name = tbls.schema_name
                    AND r.table_name = tbls.table_name
                WHERE
                    tbls.group_id = :group_id AND year(effective_date_to) = 9999
                GROUP BY
                    r.catalog_name, r.schema_name, r.table_name
            ) AS t1
        """
        params.append({"name": "group_id", "type": "STRING", "value": str(group_id)})
    else:
        t1_subquery = f"""
            (
                SELECT
                    table_name,
                    schema_name,
                    catalog_name,
                    COUNT(rule_id) AS rules_count
                FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
                GROUP BY
                    table_name, schema_name, catalog_name
            ) AS t1
        """

    # Construct the main query using the subquery
    base_query = f"""
        SELECT
            t1.table_name,
            t1.schema_name,
            t1.catalog_name,
            t1.rules_count,
            COALESCE(t2.column_count, 0) AS column_count,
            COALESCE(t2.columns, '') AS columns
        FROM {t1_subquery}
        LEFT JOIN (
            SELECT
                table_name,
                table_schema,
                table_catalog,
                COUNT(DISTINCT column_name) AS column_count,
                concat_ws(', ', collect_list(DISTINCT column_name)) AS columns
            FROM {CATALOG}.information_schema.columns
            GROUP BY
                table_name, table_schema, table_catalog
        ) AS t2
            ON t1.table_name = t2.table_name
            AND t1.schema_name = t2.table_schema
            AND t1.catalog_name = t2.table_catalog
    """
    
    # Append a search filter if provided
    if search:
        base_query += " WHERE t1.table_name LIKE :search OR t1.catalog_name LIKE :search"
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})
            
    return query_table("get_tables_data", base_query, params)


def get_filters_data(group_id=None):
    """
    Executes multiple queries to get all unique values for filter dropdowns.
    """
    base_from_clause = f"""
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS t1
        JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
            ON t1.catalog_name = t2.catalog_name
            AND t1.schema_name = t2.schema_name
            AND t1.table_name = t2.table_name
    """
    
    where_clauses = []
    params = []
    
    if group_id:
        where_clauses.append("t2.group_id = ?")
        params.append({"value": group_id, "type": "STRING"})

    where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

    filter_queries = {
        "schemas": f"SELECT DISTINCT t1.schema_name {base_from_clause} {where_clause_str}",
        "table_names": f"SELECT DISTINCT t1.table_name {base_from_clause} {where_clause_str}",
        "user": f"SELECT DISTINCT t1.owner {base_from_clause} {where_clause_str}"
    }

    results = {}
    for name, query in filter_queries.items():
        try:
            data = query_table(name, query, params)
            normalized_list = [str(list(row.values())[0]).lower() for row in data]
            results[name] = sorted(list(set(normalized_list)))
        except Exception as e:
            results[name] = {"error": str(e)}
            
    return results


def get_rules_for_table_data(tableId, search=None, **kwargs):
    """
    Retrieves all active rules for a specific table, identified by 'catalog-schema-table'.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")

    query = f"""
        SELECT
            r.condition_type AS Rule_name,
            r.column_name AS Column_name,
            r.rule_description AS Rule_description,
            r.condition_category AS Condition_category,
            r.condition_type AS Condition_type,
            r.condition_criteria AS Condition_criteria,
            r.severity AS Severity
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
        WHERE
            r.table_name = :tableName
            AND r.schema_name = :schemaName
            AND r.catalog_name = :catalogName
            AND year(effective_date_to) = 9999
    """
    
    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]

    if search:
        query += " AND r.condition_type LIKE :search"
        params.append({"name": "search", "type": "STRING", "value": f"%{search}%"})
    
    return query_table(f"get_rules_for_{tableId}", query, params)


def get_filters_for_table(tableId):
    """
    Gets all unique filter options for the rules within a specific table.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")
            
    filter_queries = {
        "condition_category": f"""
            SELECT DISTINCT r.condition_category
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """,
        "condition_type": f"""
            SELECT DISTINCT r.condition_type
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """,
        "severity": f"""
            SELECT DISTINCT r.severity
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE r.table_name = :tableName
              AND r.schema_name = :schemaName
              AND r.catalog_name = :catalogName
        """
    }

    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]

    results = {}
    for name, query in filter_queries.items():
        try:
            data = query_table(name, query, params)
            results[name] = [list(row.values())[0] for row in data]
        except Exception as e:
            results[name] = {"error": str(e)}
            
    # Add a static list for 'status' since it's computed in the business logic
    results['status'] = ['active', 'inactive']
            
    return results


def get_rule_details(ruleId):
    """
    Builds and executes SQL to get the full details for a single rule by its ID.
    This query distinguishes between creation and review metadata.
    """
    query = f"""
        WITH active_rule AS (
            SELECT *
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = :ruleId AND year(effective_date_to) = 9999
        ),
        previous_rule AS (
            SELECT rule_id, owner, created_at
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = :ruleId AND year(effective_date_to) <> 9999
            ORDER BY effective_date_to DESC
            LIMIT 1
        )
        SELECT
            a.condition_category,
            a.condition_criteria,
            CASE
                WHEN a.updated_at IS NULL THEN a.created_at
                ELSE p.created_at
            END AS created_at,
            CASE
                WHEN a.updated_at IS NULL THEN NULL
                ELSE a.updated_at
            END AS reviewed_at,
            CASE
                WHEN a.updated_at IS NULL THEN a.owner
                ELSE p.owner
            END AS created_by,
            CASE
                WHEN a.updated_at IS NULL THEN NULL
                ELSE a.owner
            END AS reviewed_by
        FROM active_rule AS a
        LEFT JOIN previous_rule AS p ON a.rule_id = p.rule_id
    """

    param_type = "BIGINT" if isinstance(ruleId, int) else "STRING"
    params = [{"name": "ruleId", "type": param_type, "value": ruleId}]
    
    result = query_table(f"get_rule_{ruleId}", query, params)
    return result[0] if result else None


def get_active_or_inactive_rules_for_table(tableId, status=None, severity=None, Condition_Type=None, Condition_Category=None, **kwargs):
    """
    Builds and executes SQL to get rules for a specific table, with dynamic filters.
    Computes rule status ('active'/'inactive') on the fly.
    """
    try:
        catalog, schema, table = tableId.split('-')
    except ValueError:
        raise ValueError("tableId must be in the format 'catalog-schema-table'.")
    
    base_query = f"""
        WITH RulesWithStatus AS (
            SELECT
                r.severity,
                r.rule_id,
                r.column_name,
                r.rule_description,
                r.violation_threshold,
                r.condition_criteria,
                r.condition_type,
                r.enforcement_action,
                CASE
                    WHEN CURRENT_TIMESTAMP() >= r.effective_date_from AND CURRENT_TIMESTAMP() < r.effective_date_to
                    THEN 'active'
                    ELSE 'inactive'
                END AS computed_status
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE} AS r
            WHERE
                r.table_name = :tableName
                AND r.schema_name = :schemaName
                AND r.catalog_name = :catalogName
        )
        SELECT * FROM RulesWithStatus
    """
    
    params = [
        {"name": "tableName", "type": "STRING", "value": table},
        {"name": "schemaName", "type": "STRING", "value": schema},
        {"name": "catalogName", "type": "STRING", "value": catalog}
    ]
    
    where_clauses = []
    
    if status:
        where_clauses.append("computed_status = :status")
        params.append({"name": "status", "type": "STRING", "value": status})
        
    if severity:
        where_clauses.append("severity = :severity")
        params.append({"name": "severity", "type": "STRING", "value": severity})

    if Condition_Type:
        where_clauses.append("condition_type = :Condition_Type")
        params.append({"name": "Condition_Type", "type": "STRING", "value": Condition_Type})

    if Condition_Category:
        where_clauses.append("condition_category = :Condition_Category")
        params.append({"name": "Condition_Category", "type": "STRING", "value": Condition_Category})

    final_query = base_query
    if where_clauses:
        final_query += " WHERE " + " AND ".join(where_clauses)
            
    results = query_table(f"get_rules_for_{tableId}", final_query, params)
    
    # Attempt to convert rule_id to integer for consistency
    for row in results:
        if "rule_id" in row and row["rule_id"] is not None:
            try:
                row["rule_id"] = int(row["rule_id"])
            except (ValueError, TypeError):
                pass  # Keep as-is if it’s not a valid number
    return results


def get_columns_for_rule_from_info_schema(rule_id):
    """
    Finds the table for a rule_id, then fetches its column names from information_schema.
    """
    # Step 1: Find the catalog, schema, and table for the given rule_id
    get_rule_query = f"""
        SELECT catalog_name, schema_name, table_name
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = ?
    """
    rule_params = [{"type": "STRING", "value": rule_id}]
    rule_details = query_table("get_rule_details_for_columns", get_rule_query, rule_params)
    
    if not rule_details:
        raise Exception(f"No rule found with rule_id: {rule_id}")
            
    catalog = rule_details[0]["catalog_name"]
    schema = rule_details[0]["schema_name"]
    table = rule_details[0]["table_name"]
    
    # Step 2: Use the details to query the information_schema
    get_columns_query = f"""
        SELECT column_name
        FROM {CATALOG}.information_schema.columns
        WHERE
            table_catalog = ?
            AND table_schema = ?
            AND table_name = ?
        ORDER BY ordinal_position
    """
    column_params = [
        {"type": "STRING", "value": catalog},
        {"type": "STRING", "value": schema},
        {"type": "STRING", "value": table}
    ]
    column_data = query_table("get_columns_from_info_schema", get_columns_query, column_params)
    
    column_names = [row["column_name"] for row in column_data]
    return column_names


def insert_rule_request(rule_id, popup_data, data):
    """
    Inserts a new record into the rule requests table, preserving data types
    in the condition_criteria JSON.
    """
    get_rule_query = f"""
        SELECT
            rule_id, catalog_name, schema_name, table_name,
            condition_category, condition_type, owner, condition_criteria,
            enforcement_action
        FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = :ruleId
    """
    params = [{"name": "ruleId", "type": "STRING", "value": rule_id}]
    rule_details = query_table(f"get_rule_details_for_request_{rule_id}", get_rule_query, params)
    
    if not rule_details:
        raise Exception(f"No rule found with rule_id: {rule_id}")
    rule = rule_details[0]

    # --- Robustly handle condition_criteria (could be dict or JSON string) ---
    raw_new_criteria = popup_data.get("condition_criteria")
    new_criteria_dict = {}

    if isinstance(raw_new_criteria, str):
        try:
            new_criteria_dict = json.loads(raw_new_criteria)
        except json.JSONDecodeError:
            new_criteria_dict = {} # Gracefully handle bad JSON string
    elif isinstance(raw_new_criteria, dict):
        new_criteria_dict = raw_new_criteria
    
    final_criteria = new_criteria_dict.copy()

    # Mirror data types from the original rule's criteria
    original_criteria_str = rule.get("condition_criteria")
    if original_criteria_str and new_criteria_dict:
        try:
            original_criteria = json.loads(original_criteria_str)
            for key, new_value in new_criteria_dict.items():
                if key in original_criteria:
                    original_value = original_criteria[key]
                    if isinstance(original_value, (int, float)):
                        try:
                            # Attempt to cast new value to the original type
                            final_criteria[key] = type(original_value)(new_value)
                        except (ValueError, TypeError):
                            final_criteria[key] = new_value # Keep new value if cast fails
        except json.JSONDecodeError:
            pass # Ignore if original criteria is not valid JSON

    final_criteria_json_string = json.dumps(final_criteria) if final_criteria else None

    # Enforcement action: use the value the edit dialog sent if present and
    # valid; otherwise keep whatever the rule already had (so editing e.g.
    # just the description doesn't accidentally reset this field).
    VALID_ENFORCEMENT_ACTIONS = ("BLOCK_AND_AUDIT", "AUDIT_ONLY")
    enforcement_action = data.get("enforcement_action") or popup_data.get("enforcement_action")
    if enforcement_action not in VALID_ENFORCEMENT_ACTIONS:
        enforcement_action = rule.get("enforcement_action") or "BLOCK_AND_AUDIT"

    # --- Insert the formatted data into the requests table ---
    insert_query = f"""
        INSERT INTO {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        (
            request_id, catalog, schema, table_name, column_name, rule_description,
            status, created_by, created_at, reviewed_by, reviewed_at, review_comments,
            condition_category, condition_type, condition_criteria, operation,
            severity, violation_threshold, enforcement_action
        )
        VALUES
        (
            :request_id, :catalog, :schema, :table_name, :column_name, :rule_description,
            :status, :created_by, current_timestamp(), NULL, NULL, NULL,
            :condition_category, :condition_type, :condition_criteria, :operation,
            :severity, :violation_threshold, :enforcement_action
        )
    """
    insert_params = [
        {"name": "request_id", "type": "STRING", "value": str(rule_id)},
        {"name": "catalog", "type": "STRING", "value": rule["catalog_name"]},
        {"name": "schema", "type": "STRING", "value": rule["schema_name"]},
        {"name": "table_name", "type": "STRING", "value": rule["table_name"]},
        {"name": "column_name", "type": "STRING", "value": popup_data["column_name"]},
        {"name": "rule_description", "type": "STRING", "value": popup_data["rule_description"]},
        {"name": "status", "type": "STRING", "value": "pending"},
        {"name": "created_by", "type": "STRING", "value": rule["owner"]},
        {"name": "condition_category", "type": "STRING", "value": rule["condition_category"]},
        {"name": "condition_type", "type": "STRING", "value": rule["condition_type"]},
        {"name": "condition_criteria", "type": "STRING", "value": final_criteria_json_string},
        {"name": "operation", "type": "STRING", "value": "UPDATE"},
        {"name": "severity", "type": "STRING", "value": popup_data["severity"]},
        {"name": "violation_threshold", "type": "FLOAT", "value": float(popup_data["violation_threshold"])},
        {"name": "enforcement_action", "type": "STRING", "value": enforcement_action}
    ]

    return query_table(f"insert_rule_request_{rule_id}", insert_query, insert_params)


def delete_rule_data(ruleId):
    """
    Deletes a rule by its string-based rule_id.
    """
    query = f"""
        DELETE FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
        WHERE rule_id = :ruleId
    """
    params = [{"name": "ruleId", "type": "STRING", "value": ruleId}]
    
    return query_table(f"delete_rule_{ruleId}", query, params)

