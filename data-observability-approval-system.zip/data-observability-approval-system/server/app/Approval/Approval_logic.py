# server/app/RuleManagement/rule_management_logic.py
import uuid
import time
import requests
from config import config # Imports from the config.py file at the top level

import yaml
import os

# Load config.yaml
# Always point to server/config.yaml (one level up from app/)
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml")

# CONFIG_PATH = os.path.abspath(CONFIG_PATH)

with open(CONFIG_PATH, "r") as f:
    yaml_config = yaml.safe_load(f)

# Assign values
CATALOG = yaml_config.get("catalog")
SCHEMA = yaml_config.get("schema")
RULE_REQUESTS_TABLE = yaml_config.get("rule_requests_table")
RULE_TABLE = yaml_config.get("rule_table")
TABLE_CONFIG = yaml_config.get("table_config")
PIPELINE_METADATA = yaml_config.get("pipeline_metadata") 


# --- CORRECTED and FINAL "Engine" to Run Queries ---
def query_table(name, query, params=None):
    """
    Executes a SQL query on Databricks using the Statement Execution API.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    # --- THIS IS THE MISSING PIECE ---
    # Add the parameters to the payload if they exist
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"

    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            schema = manifest.get("schema", {})
            columns = [col["name"] for col in schema.get("columns", [])]
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            formatted_data = [dict(zip(columns, row)) for row in data_array]
            return formatted_data
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
        
        time.sleep(1)

def query_scalar(name, query, params=None):
    """
    Executes a SQL query on Databricks expecting a single scalar value.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")

    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"

    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            full_result = status_json.get("result", {})
            data_array = full_result.get("data_array", [])
            
            # Check for empty results
            if not data_array or not data_array[0]:
                return 0 # Return 0 for count queries with no results
            
            # Extract and return the single scalar value
            return data_array[0][0]
            
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
            
        time.sleep(1)

def execute_query(name, query, params=None):
    """
    Executes a SQL statement on Databricks that modifies data (INSERT/UPDATE/DELETE).
    Does not expect a result set.
    """
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }
    
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")
    
    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    
    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")
        
        if state == "SUCCEEDED":
            # The query succeeded, so we can return success
            return True
        elif state in ["FAILED", "CANCELED", "CLOSED"]:
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")

        time.sleep(1)

# # --- Logic for the /api/tables Endpoint ---

# def get_approval_data(search=None, schemas=None, tables=None, owners=None, statuses=None, page=1, limit=10):
#     where_clauses = []
#     params = []
    
#     if search and search.strip():
#         where_clauses.append("(t1.table_name ILIKE ? OR t1.rule_description ILIKE ?)")
#         params.extend([{"value": f"%{search}%", "type": "STRING"}, {"value": f"%{search}%", "type": "STRING"}])

#     filtered_schemas = [s for s in schemas if s]
#     if filtered_schemas:
#         placeholders = ','.join(['?'] * len(filtered_schemas))
#         where_clauses.append(f"t1.schema IN ({placeholders})")
#         params.extend([{"value": s, "type": "STRING"} for s in filtered_schemas])
        
#     filtered_tables = [t for t in tables if t]
#     if filtered_tables:
#         placeholders = ','.join(['?'] * len(filtered_tables))
#         where_clauses.append(f"t1.table_name IN ({placeholders})")
#         params.extend([{"value": t, "type": "STRING"} for t in filtered_tables])
        
#     filtered_owners = [o for o in owners if o]
#     if filtered_owners:
#         placeholders = ','.join(['?'] * len(filtered_owners))
#         where_clauses.append(f"t1.created_by IN ({placeholders})")
#         params.extend([{"value": o, "type": "STRING"} for o in filtered_owners])
    
#     filtered_statuses = [s for s in statuses if s]
#     if filtered_statuses:
#         normalized_statuses = [s.lower() if s != "Yet to Approve" else "pending" for s in filtered_statuses]
#         placeholders = ','.join(['?'] * len(normalized_statuses))
#         where_clauses.append(f"t1.status IN ({placeholders})")
#         params.extend([{"value": s, "type": "STRING"} for s in normalized_statuses])

#     where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    
#     count_query = f"""
#         SELECT COUNT(*)
#         FROM ds_training_1.dq_config.dq_rule_requests AS t1
#         {where_clause_str}
#     """
#     total_count = query_scalar("count_approvals", count_query, params)
    
#     offset = (page - 1) * limit
#     data_query = f"""
#         SELECT
#             request_id,
#             catalog,
#             schema,
#             table_name,
#             column_name,
#             rule_description,
#             condition_category,
#             condition_type AS rule_name,
#             condition_criteria,
#             severity,
#             created_by,
#             violation_threshold,
#             status
#         FROM ds_training_1.dq_config.dq_rule_requests AS t1
#         {where_clause_str}
#         ORDER BY t1.request_id DESC
#         LIMIT ? OFFSET ?
#     """
    
#     final_params = params + [{"value": limit, "type": "INT"}, {"value": offset, "type": "INT"}]
    
#     paginated_data = query_table("get_paginated_approvals", data_query, final_params)
    
#     return paginated_data, total_count

# def get_approval_data(search=None, schemas=None, tables=None, owners=None, statuses=None, groupId=None, page=1, limit=10):
#     where_clauses = []
#     params = []
    
#     base_from_clause = """
#     FROM ds_training_1.dq_config.dq_rule_requests AS t1
#     LEFT JOIN ds_training_1.dq_config.tables AS t2
#         ON t1.catalog = t2.catalog_name
#         AND t1.schema = t2.schema_name
#         AND t1.table_name = t2.table_name
#     """
    
#     # Filter to include only 'pending' and 'rejected' statuses.
#     where_clauses.append("LOWER(t1.status) IN ('pending', 'rejected')")

#     # This logic correctly handles the single string groupId
#     if groupId:
#         where_clauses.append("t2.group_id = ?")
#         params.append({"value": groupId, "type": "STRING"})

#     if search and search.strip():
#         where_clauses.append("(t1.table_name ILIKE ? OR t1.rule_description ILIKE ?)")
#         params.extend([{"value": f"%{search}%", "type": "STRING"}, {"value": f"%{search}%", "type": "STRING"}])

#     filtered_schemas = [s for s in schemas if s]
#     if filtered_schemas:
#         placeholders = ','.join(['?'] * len(filtered_schemas))
#         where_clauses.append(f"t1.schema IN ({placeholders})")
#         params.extend([{"value": s, "type": "STRING"} for s in filtered_schemas])
        
#     filtered_tables = [t for t in tables if t]
#     if filtered_tables:
#         placeholders = ','.join(['?'] * len(filtered_tables))
#         where_clauses.append(f"t1.table_name IN ({placeholders})")
#         params.extend([{"value": t, "type": "STRING"} for t in filtered_tables])
        
#     filtered_owners = [o for o in owners if o]
#     if filtered_owners:
#         placeholders = ','.join(['?'] * len(filtered_owners))
#         where_clauses.append(f"t1.created_by IN ({placeholders})")
#         params.extend([{"value": o, "type": "STRING"} for o in filtered_owners])
    
#     filtered_statuses = [s for s in statuses if s]
#     if filtered_statuses:
#         normalized_statuses = [s.lower() if s != "Yet to Approve" else "pending" for s in filtered_statuses]
#         placeholders = ','.join(['?'] * len(normalized_statuses))
#         where_clauses.append(f"LOWER(t1.status) IN ({placeholders})")
#         params.extend([{"value": s, "type": "STRING"} for s in normalized_statuses])

#     where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    
#     count_query = f"""
#         SELECT COUNT(*)
#         {base_from_clause}
#         {where_clause_str}
#     """
#     total_count = query_scalar("count_approvals", count_query, params)
    
#     offset = (page - 1) * limit
#     data_query = f"""
#         SELECT
#             t1.request_id,
#             t1.catalog,
#             t1.schema,
#             t1.table_name,
#             t1.column_name,
#             t1.rule_description,
#             t1.condition_category,
#             t1.condition_type AS rule_name,
#             t1.condition_criteria,
#             t1.condition_type,
#             t1.operation,
#             t1.created_at,
#             t1.severity,
#             t1.created_by,
#             t1.violation_threshold,
#             t1.status
#         {base_from_clause}
#         {where_clause_str}
#         ORDER BY
#             CASE
#                 WHEN LOWER(t1.status) = 'pending' THEN 1
#                 WHEN LOWER(t1.status) = 'rejected' THEN 2
#                 ELSE 3
#             END,
#             t1.created_at DESC,
#              t1.request_id DESC
#         LIMIT ? OFFSET ?
#     """
    
#     final_params = params + [{"value": limit, "type": "INT"}, {"value": offset, "type": "INT"}]
    
#     paginated_data = query_table("get_paginated_approvals", data_query, final_params)
    
#     return paginated_data, total_count

def get_approval_data(search=None, schemas=None, tables=None, owners=None, statuses=None, groupId=None, page=1, limit=10):
    where_clauses = []
    params = []
    
    base_from_clause = f"""
    FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE} AS t1
    LEFT JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
        ON t1.catalog = t2.catalog_name
        AND t1.schema = t2.schema_name
        AND t1.table_name = t2.table_name
    LEFT JOIN {CATALOG}.{SCHEMA}.{PIPELINE_METADATA} AS pm
        ON pm.catalog_name = t1.catalog
        AND pm.schema_name = t1.schema
        AND pm.table_name = t1.table_name
    """
    
    # Filter to include only 'pending' and 'rejected' statuses.
    # where_clauses.append("t1.status IN ('pending', 'rejected','PENDING','REJECTED')")
    where_clauses.append("LOWER(t1.status) IN ('pending', 'rejected')")

    # This logic correctly handles the single string groupId
    if groupId:
        where_clauses.append("t2.group_id = ?")
        params.append({"value": groupId, "type": "STRING"})

    if search and search.strip():
        where_clauses.append("(t1.table_name ILIKE ? OR t1.rule_description ILIKE ?)")
        params.extend([{"value": f"%{search}%", "type": "STRING"}, {"value": f"%{search}%", "type": "STRING"}])

    filtered_schemas = [s for s in schemas if s]
    if filtered_schemas:
        placeholders = ','.join(['?'] * len(filtered_schemas))
        where_clauses.append(f"t1.schema IN ({placeholders})")
        params.extend([{"value": s, "type": "STRING"} for s in filtered_schemas])
        
    filtered_tables = [t for t in tables if t]
    if filtered_tables:
        placeholders = ','.join(['?'] * len(filtered_tables))
        where_clauses.append(f"t1.table_name IN ({placeholders})")
        params.extend([{"value": t, "type": "STRING"} for t in filtered_tables])
        
    # filtered_owners = [o for o in owners if o]
    # if filtered_owners:
    #     placeholders = ','.join(['?'] * len(filtered_owners))
    #     where_clauses.append(f"t1.created_by IN ({placeholders})")
    #     params.extend([{"value": o, "type": "STRING"} for o in filtered_owners])
    # --- Owner filter ---
    if owners:
    # Ensure owners is always a list
        if isinstance(owners, str):
            filtered_owners = [owners]
        else:
            filtered_owners = [o for o in owners if o]

        if filtered_owners:
            placeholders = ','.join(['?'] * len(filtered_owners))
            # Case-insensitive match
            where_clauses.append(f"LOWER(t1.created_by) IN ({placeholders})")
            params.extend([{"value": o.lower(), "type": "STRING"} for o in filtered_owners])

    
    filtered_statuses = [s for s in statuses if s]
    if filtered_statuses:
        normalized_statuses = [s.lower() if s.lower() != "Yet to Approve" else "pending" for s in filtered_statuses]
        placeholders = ','.join(['?'] * len(normalized_statuses))
        where_clauses.append(f"LOWER(t1.status) IN ({placeholders})")
        params.extend([{"value": s, "type": "STRING"} for s in normalized_statuses])

    where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    
    count_query = f"""
        SELECT COUNT(*)
        {base_from_clause}
        {where_clause_str}
    """
    total_count = query_scalar("count_approvals", count_query, params)
    
    offset = (page - 1) * limit
    data_query = f"""
        SELECT
            t1.request_id,
            t1.catalog,
            t1.schema,
            t1.table_name,
            pm.pipeline_key,
            t1.column_name,
            t1.rule_description,
            t1.condition_category,
            t1.condition_type AS rule_name,
            t1.condition_criteria,
            t1.condition_type,
            t1.operation,
            t1.created_at,
            t1.severity,
            t1.created_by,
            t1.violation_threshold,
            t1.status
        {base_from_clause}
        {where_clause_str}
        ORDER BY
            CASE
                WHEN LOWER(t1.status) = 'pending' THEN 1
                WHEN LOWER(t1.status) = 'rejected' THEN 2
                ELSE 3
            END,
             t1.created_at DESC ,
             t1.request_id DESC
        LIMIT ? OFFSET ?
    """
    
    final_params = params + [{"value": limit, "type": "INT"}, {"value": offset, "type": "INT"}]
    
    paginated_data = query_table("get_paginated_approvals", data_query, final_params)
    
    return paginated_data, total_count






# def get_approval_status_counts():
#     # This query will return a single row with three columns
#     query = """
#         SELECT
#             SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
#             SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved,
#             SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected
#         FROM ds_training_1.dq_config.dq_rule_requests
#     """
    
#     # Use query_table, which returns a list of dictionaries
#     result_list = query_table("total_status_counts", query)
    
#     # Check if the result list is not empty
#     if result_list:
#         # The result will be a list with a single dictionary, e.g.,
#         # [{'pending': 10, 'approved': 5, 'rejected': 2}]
#         counts = result_list[0]
#         return {
#             "pending": int(counts.get('pending', 0)),
#             "approved": int(counts.get('approved', 0)),
#             "rejected": int(counts.get('rejected', 0)),
#         }
    
#     # If no results are returned, handle gracefully
#     return {
#         "pending": 0,
#         "approved": 0,
#         "rejected": 0,
#     }

def get_approval_status_counts(groupId=None):
    """
    Returns the count of pending, approved, and rejected rule requests,
    optionally filtered by a specific groupId.
    """
    
    # Base from clause with a LEFT JOIN to the tables table
    from_clause = f"""
    FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE} AS t1
    LEFT JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
        ON t1.catalog = t2.catalog_name
        AND t1.schema = t2.schema_name
        AND t1.table_name = t2.table_name
    """
    
    where_clause = ""
    params = []
    
    # Add a WHERE clause to filter by groupId if provided
    if groupId:
        where_clause = "WHERE t2.group_id = ?"
        params.append({"value": groupId, "type": "STRING"})

    query = f"""
        SELECT
            SUM(CASE WHEN LOWER(t1.status) = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN LOWER(t1.status) = 'approved' THEN 1 ELSE 0 END) AS approved,
            SUM(CASE WHEN LOWER(t1.status) = 'rejected' THEN 1 ELSE 0 END) AS rejected
        {from_clause}
        {where_clause}
    """
    
    # Use query_table, which returns a list of dictionaries
    result_list = query_table("total_status_counts", query, params)
    
    if result_list:
        counts = result_list[0]
        return {
            "pending": int(counts.get('pending', 0)),
            "approved": int(counts.get('approved', 0)),
            "rejected": int(counts.get('rejected', 0)),
        }
    
    return {
        "pending": 0,
        "approved": 0,
        "rejected": 0,
    }
# Add this new function to your logic file

# def get_filter():
#     """
#     Executes multiple queries to get all unique values for the filter dropdowns.
#     """
#     filter_queries = {
#         "status": "SELECT DISTINCT status FROM ds_training_1.dq_config.dq_rule_requests",
#         "schema": "SELECT DISTINCT schema FROM ds_training_1.dq_config.dq_rule_requests",
#         "table":"SELECT DISTINCT table_name FROM ds_training_1.dq_config.dq_rule_requests",
#         "user":"SELECT DISTINCT created_by FROM ds_training_1.dq_config.dq_rule_requests"
#     }

#     results = {}
#     for name, query in filter_queries.items():
#         try:
#             data = query_table(name, query)
#             # if name == "status":
#                 # results[name] = list(set([str(list(row.values())[0]).upper() for row in data]))
#             # results[name] = [list(row.values())[0] for row in data]
#             normalized_list = [str(list(row.values())[0]).lower() for row in data]
#             results[name] = sorted(list(set(normalized_list)))

#         except Exception as e:
#             results[name] = {"error": str(e)}
            
#     return results

# def get_filter(groupId=None):
#     """
#     Executes multiple queries to get all unique values for the filter dropdowns.
    
#     Args:
#         groupId (str, optional): A group ID to filter the results by.
#     """
    
#     base_from_clause = """
#     FROM ds_training_1.dq_config.dq_rule_requests AS t1
#     LEFT JOIN ds_training_1.dq_config.tables AS t2
#         ON t1.catalog = t2.catalog_name
#         AND t1.schema = t2.schema_name
#         AND t1.table_name = t2.table_name
#     """
    
#     where_clauses = []
#     params = []
#     where_clauses.append("t1.status IN ('pending','rejected','PENDING','REJECTED')")
    
#     # Add a filter for groupId if it's provided
#     if groupId:
#         where_clauses.append("t2.group_id = ?")
#         params.append({"value": groupId, "type": "STRING"})

#     where_clause_str = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

#     filter_queries = {
#         "status": f"SELECT DISTINCT t1.status {base_from_clause} {where_clause_str}",
#         "schema": f"SELECT DISTINCT t1.schema {base_from_clause} {where_clause_str}",
#         "table": f"SELECT DISTINCT t1.table_name {base_from_clause} {where_clause_str}",
#         "user": f"SELECT DISTINCT t1.created_by {base_from_clause} {where_clause_str}"
#     }

#     results = {}
#     for name, query in filter_queries.items():
#         try:
#             data = query_table(name, query, params)
#             normalized_list = [str(list(row.values())[0]).lower() for row in data
#                                if list(row.values())[0]]
#             results[name] = sorted(list(set(normalized_list)))
#         except Exception as e:
#             results[name] = {"error": str(e)}
            
#     return results

# def get_filter(groupId=None, schemas=None, tables=None, owners=None, statuses=None, search=None):
#     base_from_clause = """
#         FROM ds_training_1.dq_config.dq_rule_requests AS t1
#         LEFT JOIN ds_training_1.dq_config.tables AS t2
#         ON t1.catalog = t2.catalog_name
#         AND t1.schema = t2.schema_name
#         AND t1.table_name = t2.table_name
#     """

#     # Helper to build where clauses for each filter query
#     def build_where(exclude_filter=None):
#         clauses = ["LOWER(t1.status) IN ('pending','rejected')"]
#         params = []

#         if groupId:
#             clauses.append("t2.group_id = ?")
#             params.append({"value": groupId, "type": "STRING"})

#         if exclude_filter != "schemas" and schemas:
#             placeholders = ",".join(["?"] * len(schemas))
#             clauses.append(f"t1.schema IN ({placeholders})")
#             params.extend([{"value": s, "type": "STRING"} for s in schemas])

#         if exclude_filter != "tables" and tables:
#             placeholders = ",".join(["?"] * len(tables))
#             clauses.append(f"t1.table_name IN ({placeholders})")
#             params.extend([{"value": t, "type": "STRING"} for t in tables])

#         if exclude_filter != "owners" and owners:
#             placeholders = ",".join(["?"] * len(owners))
#             clauses.append(f"t1.created_by IN ({placeholders})")
#             params.extend([{"value": o, "type": "STRING"} for o in owners])

#         if exclude_filter != "statuses" and statuses:
#             placeholders = ",".join(["?"] * len(statuses))
#             clauses.append(f"LOWER(t1.status) IN ({placeholders})")
#             params.extend([{"value": s.lower(), "type": "STRING"} for s in statuses])

#         if search and search.strip():
#             clauses.append("(t1.table_name ILIKE ? OR t1.rule_description ILIKE ?)")
#             params.extend([{"value": f"%{search}%", "type": "STRING"} for _ in range(2)])

#         return ("WHERE " + " AND ".join(clauses)) if clauses else "", params

#     # Build each filter query with all other filters applied
#     filter_queries = {
#         "statuses": "SELECT DISTINCT LOWER(t1.status) as status",
#         "schemas": "SELECT DISTINCT t1.schema",
#         "tables": "SELECT DISTINCT t1.table_name",
#         "owners": "SELECT DISTINCT t1.created_by"
#     }

#     results = {}

#     for name in filter_queries:
#         try:
#             # Re-build where for each filter to get the correct params
#             where_clause, query_params = build_where(exclude_filter=name)
#             full_query = f"{filter_queries[name]} {base_from_clause} {where_clause}"
#             data = query_table(name, full_query, query_params)
#             normalized_list = [str(list(row.values())[0]).lower() for row in data if list(row.values())[0]]
#             results[name] = sorted(set(normalized_list))
#         except Exception as e:
#             results[name] = {"error": str(e)}

#     return results

def get_filter(groupId=None, schemas=None, tables=None, owners=None, statuses=None, search=None):
    base_from_clause = f"""
        FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE} AS t1
        LEFT JOIN {CATALOG}.{SCHEMA}.{TABLE_CONFIG} AS t2
        ON t1.catalog = t2.catalog_name
        AND t1.schema = t2.schema_name
        AND t1.table_name = t2.table_name
    """




    # Helper to build where clauses for each filter query
    def build_where(exclude_filter=None):
        clauses = ["LOWER(t1.status) IN ('pending','rejected')"]
        params = []




        if groupId:
            clauses.append("t2.group_id = ?")
            params.append({"value": groupId, "type": "STRING"})




        if exclude_filter != "schemas" and schemas:
            placeholders = ",".join(["?"] * len(schemas))
            clauses.append(f"t1.schema IN ({placeholders})")
            params.extend([{"value": s, "type": "STRING"} for s in schemas])




        if exclude_filter != "tables" and tables:
            placeholders = ",".join(["?"] * len(tables))
            clauses.append(f"t1.table_name IN ({placeholders})")
            params.extend([{"value": t, "type": "STRING"} for t in tables])




        if exclude_filter != "owners" and owners:
            placeholders = ",".join(["?"] * len(owners))
            clauses.append(f"t1.created_by IN ({placeholders})")
            params.extend([{"value": o, "type": "STRING"} for o in owners])




        if exclude_filter != "statuses" and statuses:
            placeholders = ",".join(["?"] * len(statuses))
            clauses.append(f"LOWER(t1.status) IN ({placeholders})")
            params.extend([{"value": s.lower(), "type": "STRING"} for s in statuses])




        if search and search.strip():
            clauses.append("(t1.table_name ILIKE ? OR t1.rule_description ILIKE ?)")
            params.extend([{"value": f"%{search}%", "type": "STRING"} for _ in range(2)])




        return ("WHERE " + " AND ".join(clauses)) if clauses else "", params




    # Build each filter query with all other filters applied
    filter_queries = {
        "statuses": "SELECT DISTINCT LOWER(t1.status) as status",
        "schemas": "SELECT DISTINCT t1.schema",
        "tables": "SELECT DISTINCT t1.table_name",
        "owners": "SELECT DISTINCT t1.created_by"
    }




    results = {}




    for name in filter_queries:
        try:
            # Re-build where for each filter to get the correct params
            where_clause, query_params = build_where(exclude_filter=name)
            full_query = f"{filter_queries[name]} {base_from_clause} {where_clause}"
            data = query_table(name, full_query, query_params)
            normalized_list = [str(list(row.values())[0]).lower() for row in data if list(row.values())[0]]
            results[name] = sorted(set(normalized_list))
        except Exception as e:
            results[name] = {"error": str(e)}




    return results


# --- Core Logic for Rule Approval ---
# def approve_rule_request(request_id, approved_by):
#     """
#     Approves a pending rule request.
#     - Fetches details from dq_rule_requests.
#     - Inserts a new record into dq_rules.
#     - Updates the status in dq_rule_requests.
#     """
#     # Step 1: Fetch the pending rule request details
#     fetch_query = """
#         SELECT
#             request_id,
#             catalog,
#             schema,
#             table_name,
#             column_name,
#             rule_description,
#             condition_category,
#             condition_type,
#             condition_criteria,
#             severity,
#             created_by,
#             violation_threshold
#         FROM ds_training_1.dq_config.dq_rule_requests
#         WHERE request_id = ? AND status = 'pending'
#     """
#     params = [{"type": "STRING", "value": request_id, "name": "p1"}]
#     rule_requests = query_table("fetch_rule_request", fetch_query, params)

#     if not rule_requests:
#         raise Exception("Rule request not found or already processed.")

#     rule = rule_requests[0]
    
#     # Step 2: Fetch the pipeline_key using the JOIN query
#     pipeline_key_query = """
#         SELECT p.pipeline_key
#         FROM ds_training_1.dq_config.pipeline_metadata AS p
#         JOIN ds_training_1.dq_config.dq_rule_requests AS r
#           ON p.table_name = r.table_name
#         WHERE r.request_id = ?
#     """
#     pipeline_key_params = [{"type": "STRING", "value": request_id, "name": "p1"}]
#     pipeline_data = query_table("fetch_pipeline_key", pipeline_key_query, pipeline_key_params)

#     if not pipeline_data:
#         raise Exception(f"Pipeline key not found for request ID: {request_id}")

#     pipeline_key = pipeline_data[0]["pipeline_key"]

#     # Step 3: Insert into dq_rules with all required columns
#     insert_query = """
#         INSERT INTO ds_training_1.dq_config.dq_rules (
#             rule_id, catalog_name, schema_name, table_name, column_name,
#             rule_description, condition_category, condition_type, condition_criteria,
#             severity, effective_date_from, effective_date_to, created_by,
#             violation_threshold, pipeline_key, updated_at
#         )
#         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, current_timestamp, '9999-12-31T00:00:00.000+00:00', ?, ?, ?, NULL)
#     """
#     insert_params = [
#         {"type": "STRING", "value": rule["request_id"], "name": "p1"},
#         {"type": "STRING", "value": rule["catalog"], "name": "p2"},
#         {"type": "STRING", "value": rule["schema"], "name": "p3"},
#         {"type": "STRING", "value": rule["table_name"], "name": "p4"},
#         {"type": "STRING", "value": rule["column_name"], "name": "p5"},
#         {"type": "STRING", "value": rule["rule_description"], "name": "p6"},
#         {"type": "STRING", "value": rule["condition_category"], "name": "p7"},
#         {"type": "STRING", "value": rule["condition_type"], "name": "p8"},
#         {"type": "STRING", "value": rule["condition_criteria"], "name": "p9"},
#         {"type": "STRING", "value": rule["severity"], "name": "p10"},
#         {"type": "STRING", "value": rule["violation_threshold"], "name": "p12"},
#         {"type": "STRING", "value": pipeline_key, "name": "p13"}
#     ]
#     execute_query("insert_rule", insert_query, insert_params)

#     # Step 4: Update the status in dq_rule_requests to 'approved'
#     update_query = """
#         UPDATE ds_training_1.dq_config.dq_rule_requests
#         SET status = 'approved'
#         WHERE request_id = ?
#     """
#     update_params = [{"type": "STRING", "value": request_id, "name": "p1"}]
#     execute_query("update_rule_request", update_query, update_params)

#     return {"message": "Rule approved successfully", "rule_id": request_id}
# --- Core Logic for Rule Approval ---
# def approve_rule_request(request_id, approved_by):
#     """
#     Approves a pending rule request.
#     - Fetches details from dq_rule_requests.
#     - Inserts a new record into dq_rules.
#     - Updates the status in dq_rule_requests.
#     """
#     # Step 1: Fetch the pending rule request details
#     fetch_query = """
#         SELECT
#             request_id,
#             catalog,
#             schema,
#             table_name,
#             column_name,
#             rule_description,
#             condition_category,
#             condition_type,
#             condition_criteria,
#             severity,
#             violation_threshold
#         FROM ds_training_1.dq_config.dq_rule_requests
#         WHERE request_id = ? AND UPPER(status) = 'PENDING' 
#     """
#     # Correctly format the parameters for the Databricks API
#     fetch_params = [{"type": "STRING", "value": request_id}]
#     rule_requests = query_table("fetch_rule_request", fetch_query, fetch_params)


#     if not rule_requests:
#         raise Exception("Rule request not found or already processed.")


#     rule = rule_requests[0]


#     # Step 2: Insert into dq_rules with all required columns
#     insert_query = """
#         INSERT INTO ds_training_1.dq_config.dq_rules (
#             rule_id, catalog_name, schema_name, table_name, column_name,
#             condition_category, condition_type, condition_criteria, rule_description,
#             severity, violation_threshold, created_at, updated_at, effective_date_from,
#             effective_date_to, owner, pipeline_key
#         )
#         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, current_timestamp, current_timestamp, current_timestamp, '9999-12-31T00:00:00.000+00:00', ?, ?)
#     """
   
#     # Correctly format the parameters for the Databricks API
#     insert_params = [
#         {"type": "STRING", "value": rule["request_id"]},
#         {"type": "STRING", "value": rule["catalog"]},
#         {"type": "STRING", "value": rule["schema"]},
#         {"type": "STRING", "value": rule["table_name"]},
#         {"type": "STRING", "value": rule["column_name"]},
#         {"type": "STRING", "value": rule["condition_category"]},
#         {"type": "STRING", "value": rule["condition_type"]},
#         {"type": "STRING", "value": rule["condition_criteria"]},
#         {"type": "STRING", "value": rule["rule_description"]},
#         {"type": "STRING", "value": rule["severity"]},
#         {"type": "STRING", "value": rule["violation_threshold"]},
#         {"type": "STRING", "value": approved_by},
#         {"type": "STRING", "value": None}
#     ]
#     execute_query("insert_rule", insert_query, insert_params)


#     # Step 3: Update the status in dq_rule_requests to 'approved'
#     update_query = """
#         UPDATE ds_training_1.dq_config.dq_rule_requests
#         SET status = 'approved', reviewed_by = ?, reviewed_at = current_timestamp
#         WHERE request_id = ?
#     """
#     # Correctly format the parameters for the Databricks API
#     update_params = [
#         {"type": "STRING", "value": approved_by},
#         {"type": "STRING", "value": request_id}
#     ]
#     execute_query("update_rule_request", update_query, update_params)


#     return {"message": "Rule approved successfully", "rule_id": request_id}

def approve_rule_request(request_id, approved_by):
    """
    Approves a pending rule request.
    - CREATE: Inserts new rule into dq_rules.
    - UPDATE: Closes existing rule (effective_date_to) and inserts updated rule version.
    """

    # Step 1: Fetch the pending rule request details
    fetch_query = f"""
        SELECT
            request_id,
            catalog,
            schema,
            table_name,
            column_name,
            rule_description,
            condition_category,
            condition_type,
            condition_criteria,
            severity,
            violation_threshold,
            operation,
            created_at,
            enforcement_action
        FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        WHERE request_id = ? AND UPPER(status) = 'PENDING' 
    """
    fetch_params = [{"type": "STRING", "value": request_id}]
    rule_requests = query_table("fetch_rule_request", fetch_query, fetch_params)

    if not rule_requests:
        raise Exception("Rule request not found or already processed.")

    rule = rule_requests[0]
    operation = rule["operation"].upper()

    # Requests created before this feature existed will have NULL here;
    # default to the safer option rather than silently disabling filtering.
    enforcement_action = rule.get("enforcement_action") or "BLOCK_AND_AUDIT"
    if enforcement_action not in ("BLOCK_AND_AUDIT", "AUDIT_ONLY"):
        enforcement_action = "BLOCK_AND_AUDIT"

    # Step 0: Fetch pipeline_key for this request
    pipeline_query = f"""
    SELECT pm.pipeline_key
    FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE} AS t1
    LEFT JOIN {CATALOG}.{SCHEMA}.{PIPELINE_METADATA} AS pm
        ON pm.catalog_name = t1.catalog
       AND pm.schema_name = t1.schema
       AND pm.table_name = t1.table_name
    WHERE t1.request_id = ?
    """
    pipeline_params = [{"type": "STRING", "value": request_id}]
    pipeline_result = query_table("fetch_pipeline_key", pipeline_query, pipeline_params)
    pipeline_key = pipeline_result[0]["pipeline_key"] if pipeline_result else None

    if operation == "CREATE":
        # Case 1: CREATE -> insert new record with dq_rule_requests.created_at
        insert_query = f"""
            INSERT INTO {CATALOG}.{SCHEMA}.{RULE_TABLE} (
                rule_id, catalog_name, schema_name, table_name, column_name,
                condition_category, condition_type, condition_criteria, rule_description,
                severity, violation_threshold, created_at, updated_at, effective_date_from,
                effective_date_to, owner, pipeline_key, enforcement_action
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, '9999-12-31T00:00:00.000+00:00', ?, ?, ?)
        """
        insert_params = [
            {"type": "STRING", "value": rule["request_id"]},
            {"type": "STRING", "value": rule["catalog"]},
            {"type": "STRING", "value": rule["schema"]},
            {"type": "STRING", "value": rule["table_name"]},
            {"type": "STRING", "value": rule["column_name"]},
            {"type": "STRING", "value": rule["condition_category"]},
            {"type": "STRING", "value": rule["condition_type"]},
            {"type": "STRING", "value": rule["condition_criteria"]},
            {"type": "STRING", "value": rule["rule_description"]},
            {"type": "STRING", "value": rule["severity"]},
            {"type": "STRING", "value": rule["violation_threshold"]},
            {"type": "TIMESTAMP", "value": rule["created_at"]},  # created_at
            {"type": "TIMESTAMP", "value": rule["created_at"]},  # effective_date_from
            {"type": "STRING", "value": approved_by},
            # {"type": "STRING", "value": None}
            {"type": "STRING", "value": pipeline_key}, # <-- set pipeline_key
            {"type": "STRING", "value": enforcement_action}
        ]
        execute_query("insert_rule", insert_query, insert_params)

    elif operation == "UPDATE":
        # Case 2: UPDATE
        # Step A: Fetch existing rule to copy created_at
        fetch_existing_query = f"""
            SELECT created_at
            FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = ?
              AND effective_date_to = '9999-12-31T00:00:00.000+00:00'
        """
        fetch_existing_params = [{"type": "STRING", "value": rule["request_id"]}]
        existing_rules = query_table("fetch_existing_rule", fetch_existing_query, fetch_existing_params)

        if not existing_rules:
            raise Exception("No active rule found to update for request_id: " + request_id)

        old_created_at = existing_rules[0]["created_at"]

        # Step B: Close the old rule (set effective_date_to)
        update_old_rule_query = f"""
            UPDATE {CATALOG}.{SCHEMA}.{RULE_TABLE}
            SET effective_date_to = ?
            WHERE rule_id = ?
              AND effective_date_to = '9999-12-31T00:00:00.000+00:00'
        """
        update_old_rule_params = [
            {"type": "TIMESTAMP", "value": rule["created_at"]},  # dq_rule_requests.created_at
            {"type": "STRING", "value": request_id}
        ]
        execute_query("close_old_rule", update_old_rule_query, update_old_rule_params)

        # Step C: Insert updated rule version
        insert_query = f"""
            INSERT INTO {CATALOG}.{SCHEMA}.{RULE_TABLE} (
                rule_id, catalog_name, schema_name, table_name, column_name,
                condition_category, condition_type, condition_criteria, rule_description,
                severity, violation_threshold, created_at, updated_at, effective_date_from,
                effective_date_to, owner, pipeline_key, enforcement_action
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '9999-12-31T00:00:00.000+00:00', ?, ?, ?)
        """
        insert_params = [
            {"type": "STRING", "value": rule["request_id"]},
            {"type": "STRING", "value": rule["catalog"]},
            {"type": "STRING", "value": rule["schema"]},
            {"type": "STRING", "value": rule["table_name"]},
            {"type": "STRING", "value": rule["column_name"]},
            {"type": "STRING", "value": rule["condition_category"]},
            {"type": "STRING", "value": rule["condition_type"]},
            {"type": "STRING", "value": rule["condition_criteria"]},
            {"type": "STRING", "value": rule["rule_description"]},
            {"type": "STRING", "value": rule["severity"]},
            {"type": "STRING", "value": rule["violation_threshold"]},
            {"type": "TIMESTAMP", "value": old_created_at},     # created_at (from old rule)
            {"type": "TIMESTAMP", "value": rule["created_at"]}, # updated_at (from requests)
            {"type": "TIMESTAMP", "value": rule["created_at"]}, # effective_date_from
            {"type": "STRING", "value": approved_by},
            # {"type": "STRING", "value": None}
            {"type": "STRING", "value": pipeline_key}, # <-- set pipeline_key
            {"type": "STRING", "value": enforcement_action}
        ]
        execute_query("insert_updated_rule", insert_query, insert_params)

    else:
        raise Exception(f"Unsupported operation type: {operation}")

    # Step 3: Update the status in dq_rule_requests to 'approved'
    update_query = f"""
        UPDATE {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        SET status = 'approved', reviewed_by = ?, reviewed_at = current_timestamp
        WHERE request_id = ?
    """
    update_params = [
        {"type": "STRING", "value": approved_by},
        {"type": "STRING", "value": request_id}
    ]
    execute_query("update_rule_request", update_query, update_params)

    return {"message": f"Rule approved successfully for operation {operation}", "rule_id": request_id}


def reject_rule_request(request_id, rejected_by, reason):
    """
    Rejects a pending rule request.
    - Fetches details from dq_rule_requests to validate the request.
    - Updates the status in dq_rule_requests to 'rejected'.
    - Records the rejection reason and who rejected it.
    """
    # Step 1: Fetch the pending rule request details
    # The purpose of this step is to validate if the request exists and is pending.
    # The query is simplified as we only need the request_id for validation.
    fetch_query = f"""
        SELECT request_id
        FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        WHERE request_id = ? AND UPPER(status) = 'PENDING'
    """
    # Correctly format the parameters for the Databricks API.
    fetch_params = [{"type": "STRING", "value": request_id}]
    rule_requests = query_table("fetch_rule_request", fetch_query, fetch_params)


    if not rule_requests:
        raise Exception("Rule request not found or already processed.")
   
    # Step 2: Update the status to 'rejected' and record rejection details
    # The query is updated to include reviewed_by and reviewed_at for an audit trail,
    # and the column name for the reason is changed to 'review_comments'.
    update_query = f"""
        UPDATE {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        SET status = 'rejected',
            review_comments = ?,
            reviewed_by = ?,
            reviewed_at = current_timestamp
        WHERE request_id = ?
    """
    # The parameters now correctly match the placeholders in the query.
    # The `reviewed_by` and `reason` are properly included.
    update_params = [
        {"type": "STRING", "value": reason},
        {"type": "STRING", "value": rejected_by},
        {"type": "STRING", "value": request_id}
    ]
    execute_query("reject_rule_request", update_query, update_params)


    return {"message": "Rule request rejected successfully", "request_id": request_id}



def revert_rule_request(request_id, reverted_by):
    """
    Reverts a rule request back to 'pending' status.
    - If the rule was approved, it deletes the rule from dq_rules.
    - Updates the status in dq_rule_requests and clears rejection/approval details.
    """
    # Step 1: Fetch the current status of the request
    fetch_status_query = f"""
        SELECT status
        FROM {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        WHERE request_id = ?
    """
    params = [{"type": "STRING", "value": request_id, "name": "p1"}]
    status_data = query_table("fetch_status", fetch_status_query, params)

    if not status_data:
        raise Exception("Rule request not found.")

    current_status = status_data[0]["status"]

    # Step 2: Conditionally perform operations based on the current status
    if current_status == 'approved':
        # If approved, delete the record from dq_rules first
        delete_query = f"""
            DELETE FROM {CATALOG}.{SCHEMA}.{RULE_TABLE}
            WHERE rule_id = ?
        """
        delete_params = [{"type": "STRING", "value": request_id, "name": "p1"}]
        execute_query("delete_approved_rule", delete_query, delete_params)

    elif current_status == 'pending':
        raise Exception("Rule request is already pending. No action needed.")

    # Step 3: Update the status in dq_rule_requests to 'pending' and clear details
    update_query = f"""
        UPDATE {CATALOG}.{SCHEMA}.{RULE_REQUESTS_TABLE}
        SET status = 'pending',
            reason = NULL
        WHERE request_id = ?
    """
    update_params = [
        {"type": "STRING", "value": reverted_by, "name": "p1"},
        {"type": "STRING", "value": request_id, "name": "p2"},
    ]
    execute_query("revert_rule_request", update_query, update_params)

    return {"message": "Rule request reverted successfully", "request_id": request_id}

