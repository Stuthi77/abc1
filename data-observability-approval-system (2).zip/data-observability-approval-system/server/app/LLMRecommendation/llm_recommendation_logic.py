# # server/app/LLMRecommendation/llm_recommendation_logic.py
# #
# # Generates DQ rule recommendations using a Databricks LLM (ai_query on the
# # SQL warehouse). NOTE: this deliberately does NOT use PySpark, because
# # Databricks Apps containers do not have Spark. Everything goes through the
# # Statement Execution API, exactly like the rest of the backend.

# import json
# import re
# import time

# import requests

# from config import config

# # The Databricks foundation-model serving endpoint used for generation.
# LLM_ENDPOINT = "databricks-meta-llama-3-3-70b-instruct"

# # Cap how many columns we profile / send to the LLM (keeps queries + prompt small)
# MAX_PROFILE_COLUMNS = 40
# MAX_TOTAL_RULES = 20

# # Must match categoryToTypes in ui RuleForm.jsx so the recommendations
# # drop cleanly into the manual Add Rule form.
# TYPE_TO_CATEGORY = {
#     "NOT_NULL": "Completeness Rules",
#     "BLANK": "Completeness Rules",
#     "MUST_HAVE_VALUE": "Completeness Rules",
#     "NOT_NULL_LENGTH_CHECK": "Completeness Rules",
#     "REGEX_MATCH": "Format & Pattern Validation",
#     "LENGTH_CHECK": "Format & Pattern Validation",
#     "FORMAT_CHECK": "Format & Pattern Validation",
#     "RANGE_CHECK": "Range & Threshold Rules",
#     "VALUE_THRESHOLD": "Range & Threshold Rules",
#     "DATE_RANGE": "Range & Threshold Rules",
#     "UNIQUE": "Uniqueness & Duplicate Checks",
#     "DUPLICATE": "Uniqueness & Duplicate Checks",
#     "CUSTOM_RULE": "Business Logic Rules",
#     "CASE_STANDARDIZATION": "Consistency & Standardization Checks",
#     "MAPPING_CHECK": "Consistency & Standardization Checks",
#     "OUTLIER_DETECTION": "Anomaly Detection",
#     "TIME_STAMP_CHECK": "Time-based Validations",
#     "ROW_COUNT_TREND": "Trend Analysis",
#     "KPI_CHECK": "KPI Statistics",
# }

# CRITERIA_FORMATS = {
#     "NOT_NULL": "null (no criteria needed)",
#     "BLANK": "null (no criteria needed)",
#     "LENGTH_CHECK": '{"value": <exact_length>}',
#     "NOT_NULL_LENGTH_CHECK": '{"value": <exact_length>}',
#     "MUST_HAVE_VALUE": '{"value": [<allowed_values>]}',
#     "REGEX_MATCH": '{"regex_pattern": "<pattern>"}',
#     "FORMAT_CHECK": '{"regex_pattern": "<pattern>"}',
#     "UNIQUE": '{"identifier_column": "<column_name>"}',
#     "DUPLICATE": "null (columns go in column_name field)",
#     "RANGE_CHECK": '{"min_value": <min>, "max_value": <max>}',
#     "VALUE_THRESHOLD": '{"operator": "<op>", "value_threshold": <val>}',
#     "TIME_STAMP_CHECK": '{"condition": "<sql_condition>"}',
#     "DATE_RANGE": '{"start_date": "<start>", "end_date": "<end>"}',
#     "OUTLIER_DETECTION": '{"value": <num_std_devs>}',
#     "MAPPING_CHECK": '{"value": [<mapped_values>]}',
#     "ROW_COUNT_TREND": '{"interval": <days>}',
#     "KPI_CHECK": '{"custom_query": "<sql>", "interval": <days>, '
#                  '"lower_threshold": <val>, "upper_threshold": <val>}',
# }


# def is_valid_identifier(name):
#     """Only allow alphanumerics + underscore to prevent SQL injection."""
#     return isinstance(name, str) and bool(re.match(r"^[a-zA-Z0-9_]+$", name))


# def execute_sql(name, query, params=None, timeout_seconds=180):
#     """Run a statement on the SQL warehouse and wait for the result."""
#     url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
#     headers = {
#         "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
#         "Content-Type": "application/json",
#     }
#     payload = {
#         "statement": query,
#         "warehouse_id": config.SQL_WAREHOUSE_ID,
#         "wait_timeout": "10s",
#     }
#     if params:
#         payload["parameters"] = params

#     res = requests.post(url, headers=headers, json=payload)
#     res.raise_for_status()
#     response_json = res.json()
#     statement_id = response_json.get("statement_id")
#     if not statement_id:
#         raise Exception(f"No statement_id returned for query '{name}'")

#     status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
#     deadline = time.time() + timeout_seconds

#     while True:
#         status_res = requests.get(status_url, headers=headers)
#         status_res.raise_for_status()
#         status_json = status_res.json()
#         state = status_json.get("status", {}).get("state")

#         if state == "SUCCEEDED":
#             manifest = status_json.get("manifest", {})
#             columns = [c["name"] for c in manifest.get("schema", {}).get("columns", [])]
#             data_array = status_json.get("result", {}).get("data_array", [])
#             return [dict(zip(columns, row)) for row in data_array]
#         if state in ("FAILED", "CANCELED", "CLOSED"):
#             error = status_json.get("status", {}).get("error", {})
#             raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
#         if time.time() > deadline:
#             raise Exception(f"Query '{name}' timed out after {timeout_seconds}s")
#         time.sleep(2)


# def get_column_metadata(catalog, schema, table):
#     query = f"""
#         SELECT column_name, data_type, is_nullable, comment
#         FROM {catalog}.information_schema.columns
#         WHERE table_catalog = :catalog
#           AND table_schema  = :schema
#           AND table_name    = :table
#         ORDER BY ordinal_position
#     """
#     params = [
#         {"name": "catalog", "type": "STRING", "value": catalog},
#         {"name": "schema", "type": "STRING", "value": schema},
#         {"name": "table", "type": "STRING", "value": table},
#     ]
#     return execute_sql("get_column_metadata", query, params)


# def profile_table(catalog, schema, table):
#     """
#     Lightweight profile built with ONE aggregate query:
#     row count + per-column null count + approx distinct count.
#     """
#     columns = get_column_metadata(catalog, schema, table)
#     if not columns:
#         raise Exception(f"Table {catalog}.{schema}.{table} has no columns or was not found.")

#     columns = columns[:MAX_PROFILE_COLUMNS]

#     select_parts = ["COUNT(*) AS total_rows"]
#     for col in columns:
#         c = col["column_name"]
#         if not is_valid_identifier(c):
#             continue
#         select_parts.append(
#             f"SUM(CASE WHEN `{c}` IS NULL THEN 1 ELSE 0 END) AS `null__{c}`"
#         )
#         select_parts.append(f"approx_count_distinct(`{c}`) AS `dist__{c}`")

#     stats_query = f"SELECT {', '.join(select_parts)} FROM {catalog}.{schema}.{table}"
#     stats_rows = execute_sql("profile_stats", stats_query)
#     stats = stats_rows[0] if stats_rows else {}

#     total_rows = int(stats.get("total_rows") or 0)

#     profile = {
#         "table": f"{catalog}.{schema}.{table}",
#         "total_rows": total_rows,
#         "total_columns": len(columns),
#         "columns": [],
#     }

#     for col in columns:
#         c = col["column_name"]
#         null_count = int(stats.get(f"null__{c}") or 0)
#         distinct = int(stats.get(f"dist__{c}") or 0)
#         profile["columns"].append({
#             "column_name": c,
#             "data_type": col.get("data_type"),
#             "nullable": col.get("is_nullable"),
#             "comment": col.get("comment") or "",
#             "null_count": null_count,
#             "null_pct": round(null_count / total_rows * 100, 2) if total_rows else 0,
#             "approx_distinct_count": distinct,
#             "uniqueness_ratio": round(distinct / total_rows, 4) if total_rows else 0,
#             "is_potential_key": total_rows > 0 and distinct >= total_rows,
#         })

#     return profile


# def build_prompt(profile):
#     taxonomy = {
#         "condition_types_by_category": {
#             "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
#             "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
#             "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
#             "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
#             "Consistency & Standardization Checks": ["MAPPING_CHECK"],
#             "Anomaly Detection": ["OUTLIER_DETECTION"],
#             "Time-based Validations": ["TIME_STAMP_CHECK"],
#             "Trend Analysis": ["ROW_COUNT_TREND"],
#         },
#         "severities": ["Critical", "Warning", "Info"],
#         "criteria_formats": CRITERIA_FORMATS,
#     }
#     return f"""You are a senior data quality architect. Based on the table profile below, generate the 10-15 MOST IMPORTANT data quality rules.

# === TABLE PROFILE ===
# {json.dumps(profile, indent=2, default=str)}

# === ALLOWED TAXONOMY ===
# {json.dumps(taxonomy, indent=2)}

# Rules for your output:
# 1. Return ONLY a JSON array, no prose, no markdown fences.
# 2. Each element must have exactly these fields: column_name, condition_type, condition_criteria, rule_description, severity, violation_threshold.
# 3. condition_type must be one of the UPPER_CASE types in the taxonomy.
# 4. condition_criteria must follow the matching criteria_formats template (use null where the template says null).
# 5. severity must be Critical, Warning or Info. violation_threshold must be an integer (0 = zero tolerance).
# 6. Prefer NOT_NULL for low-null important columns, UNIQUE for potential keys, RANGE_CHECK for numerics, TIME_STAMP_CHECK/DATE_RANGE for dates.
# 7. Do not invent column names; only use columns present in the profile."""


# def call_databricks_llm(prompt):
#     """
#     Calls the Databricks foundation model through ai_query() on the SQL
#     warehouse. The prompt is passed as a bound parameter, so no manual
#     escaping is needed.
#     """
#     query = f"""
#         SELECT ai_query(
#             '{LLM_ENDPOINT}',
#             :prompt,
#             modelParameters => named_struct('max_tokens', 4096, 'temperature', 0.1)
#         ) AS rules_json
#     """
#     params = [{"name": "prompt", "type": "STRING", "value": prompt}]
#     rows = execute_sql("ai_query_recommend_rules", query, params, timeout_seconds=300)
#     if not rows:
#         raise Exception("LLM returned no result.")
#     return rows[0].get("rules_json") or ""


# def parse_llm_rules(rules_text):
#     start = rules_text.find("[")
#     end = rules_text.rfind("]") + 1
#     if start == -1 or end == 0:
#         raise Exception("Could not find a JSON array in the LLM response.")
#     return json.loads(rules_text[start:end])


# def recommend_rules(catalog, schema, table):
#     """Main entry point used by the API route."""
#     for name in (catalog, schema, table):
#         if not is_valid_identifier(name):
#             raise ValueError("Invalid catalog/schema/table name provided.")

#     profile = profile_table(catalog, schema, table)
#     valid_columns = {c["column_name"] for c in profile["columns"]}

#     prompt = build_prompt(profile)
#     raw = call_databricks_llm(prompt)
#     llm_rules = parse_llm_rules(raw)

#     severity_rank = {"Critical": 3, "Warning": 2, "Info": 1}
#     llm_rules.sort(key=lambda r: severity_rank.get(r.get("severity"), 2), reverse=True)

#     formatted = []
#     for rule in llm_rules[:MAX_TOTAL_RULES]:
#         condition_type = str(rule.get("condition_type", "")).upper().strip()
#         if condition_type not in TYPE_TO_CATEGORY:
#             continue

#         column_name = str(rule.get("column_name", "")).strip()
#         # keep only rules that reference real columns (DUPLICATE may list several)
#         cols = [c.strip() for c in column_name.split(",") if c.strip()]
#         if not cols or any(c not in valid_columns for c in cols):
#             continue

#         criteria = rule.get("condition_criteria")
#         if criteria is not None and not isinstance(criteria, str):
#             criteria = json.dumps(criteria)
#         if isinstance(criteria, str) and criteria.strip().lower() in ("null", "none", ""):
#             criteria = None

#         severity = rule.get("severity", "Warning")
#         if severity not in severity_rank:
#             severity = "Warning"

#         try:
#             threshold = int(rule.get("violation_threshold", 0))
#         except (TypeError, ValueError):
#             threshold = 0

#         formatted.append({
#             "catalog": catalog,
#             "schema": schema,
#             "table_name": table,
#             "column_name": ",".join(cols),
#             "rule_description": rule.get("rule_description", ""),
#             "condition_category": TYPE_TO_CATEGORY[condition_type],
#             "condition_type": condition_type,
#             "condition_criteria": criteria,
#             "severity": severity,
#             "violation_threshold": threshold,
#             # Recommended rules default to the safer enforcement option; the
#             # user can change this per-rule before submitting for approval.
#             "enforcement_action": "BLOCK_AND_AUDIT",
#             "email_alert_enabled": True,
#             "alert_group_id": None,
#         })

#     return formatted


# server/app/LLMRecommendation/llm_recommendation_logic.py
#
# Generates DQ rule recommendations using a Databricks LLM (ai_query on the
# SQL warehouse). NOTE: this deliberately does NOT use PySpark, because
# Databricks Apps containers do not have Spark. Everything goes through the
# Statement Execution API, exactly like the rest of the backend.

import json
import re
import time

import requests

from config import config

# The Databricks foundation-model serving endpoint used for generation.
LLM_ENDPOINT = "databricks-meta-llama-3-3-70b-instruct"

# Cap how many columns we profile / send to the LLM (keeps queries + prompt small)
MAX_PROFILE_COLUMNS = 40
MAX_TOTAL_RULES = 20

# Must match categoryToTypes in ui RuleForm.jsx so the recommendations
# drop cleanly into the manual Add Rule form.
TYPE_TO_CATEGORY = {
    "NOT_NULL": "Completeness Rules",
    "BLANK": "Completeness Rules",
    "MUST_HAVE_VALUE": "Completeness Rules",
    "NOT_NULL_LENGTH_CHECK": "Completeness Rules",
    "REGEX_MATCH": "Format & Pattern Validation",
    "LENGTH_CHECK": "Format & Pattern Validation",
    "FORMAT_CHECK": "Format & Pattern Validation",
    "RANGE_CHECK": "Range & Threshold Rules",
    "VALUE_THRESHOLD": "Range & Threshold Rules",
    "DATE_RANGE": "Range & Threshold Rules",
    "UNIQUE": "Uniqueness & Duplicate Checks",
    "DUPLICATE": "Uniqueness & Duplicate Checks",
    "CUSTOM_RULE": "Business Logic Rules",
    "CASE_STANDARDIZATION": "Consistency & Standardization Checks",
    "MAPPING_CHECK": "Consistency & Standardization Checks",
    "OUTLIER_DETECTION": "Anomaly Detection",
    "TIME_STAMP_CHECK": "Time-based Validations",
    "ROW_COUNT_TREND": "Trend Analysis",
    "KPI_CHECK": "KPI Statistics",
}

CRITERIA_FORMATS = {
    "NOT_NULL": "null (no criteria needed)",
    "BLANK": "null (no criteria needed)",
    "LENGTH_CHECK": '{"value": <exact_length>}',
    "NOT_NULL_LENGTH_CHECK": '{"value": <minimum_length>}',
    "MUST_HAVE_VALUE": '{"value": [<allowed_values>]}',
    "REGEX_MATCH": '{"regex_pattern": "<pattern>"}',
    "FORMAT_CHECK": '{"regex_pattern": "<pattern>"}',
    "UNIQUE": '{"identifier_column": "<column_name>"}',
    "DUPLICATE": "null (columns go in column_name field)",
    "RANGE_CHECK": '{"min_value": <min>, "max_value": <max>}',
    "VALUE_THRESHOLD": '{"operator": "<op>", "value_threshold": <val>}',
    "TIME_STAMP_CHECK": '{"condition": "<sql_condition>"}',
    "DATE_RANGE": '{"start_date": "<start>", "end_date": "<end>"}',
    "OUTLIER_DETECTION": '{"value": <num_std_devs>}',
    "MAPPING_CHECK": '{"value": [<mapped_values>]}',
    "ROW_COUNT_TREND": '{"interval": <days>}',
    "KPI_CHECK": '{"custom_query": "<sql>", "interval": <days>, '
                 '"lower_threshold": <val>, "upper_threshold": <val>}',
    "CUSTOM_RULE": '{"custom_query": "<sql_expression_or_condition>"}',
    "CASE_STANDARDIZATION": '{"case": "<UPPER|LOWER>"}',
}


def is_valid_identifier(name):
    """Only allow alphanumerics + underscore to prevent SQL injection."""
    return isinstance(name, str) and bool(re.match(r"^[a-zA-Z0-9_]+$", name))


def execute_sql(name, query, params=None, timeout_seconds=180):
    """Run a statement on the SQL warehouse and wait for the result."""
    url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {config.DATABRICKS_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "statement": query,
        "warehouse_id": config.SQL_WAREHOUSE_ID,
        "wait_timeout": "10s",
    }
    if params:
        payload["parameters"] = params

    res = requests.post(url, headers=headers, json=payload)
    res.raise_for_status()
    response_json = res.json()
    statement_id = response_json.get("statement_id")
    if not statement_id:
        raise Exception(f"No statement_id returned for query '{name}'")

    status_url = f"{config.DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
    deadline = time.time() + timeout_seconds

    while True:
        status_res = requests.get(status_url, headers=headers)
        status_res.raise_for_status()
        status_json = status_res.json()
        state = status_json.get("status", {}).get("state")

        if state == "SUCCEEDED":
            manifest = status_json.get("manifest", {})
            columns = [c["name"] for c in manifest.get("schema", {}).get("columns", [])]
            data_array = status_json.get("result", {}).get("data_array", [])
            return [dict(zip(columns, row)) for row in data_array]
        if state in ("FAILED", "CANCELED", "CLOSED"):
            error = status_json.get("status", {}).get("error", {})
            raise Exception(f"Query '{name}' failed: {error.get('message', 'Unknown error')}")
        if time.time() > deadline:
            raise Exception(f"Query '{name}' timed out after {timeout_seconds}s")
        time.sleep(2)


def get_column_metadata(catalog, schema, table):
    query = f"""
        SELECT column_name, data_type, is_nullable, comment
        FROM {catalog}.information_schema.columns
        WHERE table_catalog = :catalog
          AND table_schema  = :schema
          AND table_name    = :table
        ORDER BY ordinal_position
    """
    params = [
        {"name": "catalog", "type": "STRING", "value": catalog},
        {"name": "schema", "type": "STRING", "value": schema},
        {"name": "table", "type": "STRING", "value": table},
    ]
    return execute_sql("get_column_metadata", query, params)


def profile_table(catalog, schema, table):
    """
    Lightweight profile built with ONE aggregate query:
    row count + per-column null count + approx distinct count.
    """
    columns = get_column_metadata(catalog, schema, table)
    if not columns:
        raise Exception(f"Table {catalog}.{schema}.{table} has no columns or was not found.")

    columns = columns[:MAX_PROFILE_COLUMNS]

    select_parts = ["COUNT(*) AS total_rows"]
    for col in columns:
        c = col["column_name"]
        if not is_valid_identifier(c):
            continue
        select_parts.append(
            f"SUM(CASE WHEN `{c}` IS NULL THEN 1 ELSE 0 END) AS `null__{c}`"
        )
        select_parts.append(f"approx_count_distinct(`{c}`) AS `dist__{c}`")

    stats_query = f"SELECT {', '.join(select_parts)} FROM {catalog}.{schema}.{table}"
    stats_rows = execute_sql("profile_stats", stats_query)
    stats = stats_rows[0] if stats_rows else {}

    total_rows = int(stats.get("total_rows") or 0)

    profile = {
        "table": f"{catalog}.{schema}.{table}",
        "total_rows": total_rows,
        "total_columns": len(columns),
        "columns": [],
    }

    for col in columns:
        c = col["column_name"]
        null_count = int(stats.get(f"null__{c}") or 0)
        distinct = int(stats.get(f"dist__{c}") or 0)
        profile["columns"].append({
            "column_name": c,
            "data_type": col.get("data_type"),
            "nullable": col.get("is_nullable"),
            "comment": col.get("comment") or "",
            "null_count": null_count,
            "null_pct": round(null_count / total_rows * 100, 2) if total_rows else 0,
            "approx_distinct_count": distinct,
            "uniqueness_ratio": round(distinct / total_rows, 4) if total_rows else 0,
            "is_potential_key": total_rows > 0 and distinct >= total_rows,
        })

    return profile


def build_prompt(profile):
    taxonomy = {
        "condition_types_by_category": {
            "Completeness Rules": ["NOT_NULL", "BLANK", "MUST_HAVE_VALUE", "NOT_NULL_LENGTH_CHECK"],
            "Format & Pattern Validation": ["REGEX_MATCH", "LENGTH_CHECK", "FORMAT_CHECK"],
            "Range & Threshold Rules": ["RANGE_CHECK", "VALUE_THRESHOLD", "DATE_RANGE"],
            "Uniqueness & Duplicate Checks": ["UNIQUE", "DUPLICATE"],
            "Business Logic Rules": ["CUSTOM_RULE"],
            "Consistency & Standardization Checks": ["CASE_STANDARDIZATION", "MAPPING_CHECK"],
            "Anomaly Detection": ["OUTLIER_DETECTION"],
            "Time-based Validations": ["TIME_STAMP_CHECK"],
            "Trend Analysis": ["ROW_COUNT_TREND"],
            "KPI Statistics": ["KPI_CHECK"],
        },
        "severities": ["Critical", "Warning", "Info"],
        "criteria_formats": CRITERIA_FORMATS,
    }
    return f"""You are a senior data quality architect. Based on the table profile below, generate the 10-15 MOST IMPORTANT data quality rules.

=== TABLE PROFILE ===
{json.dumps(profile, indent=2, default=str)}

=== ALLOWED TAXONOMY ===
{json.dumps(taxonomy, indent=2)}

Rules for your output:
1. Return ONLY a JSON array, no prose, no markdown fences.
2. Each element must have exactly these fields: column_name, condition_type, condition_criteria, rule_description, severity, violation_threshold.
3. condition_type must be one of the UPPER_CASE types in the taxonomy.
4. condition_criteria must follow the matching criteria_formats template (use null where the template says null).
5. severity must be Critical, Warning or Info. violation_threshold must be an integer (0 = zero tolerance).
6. Prefer NOT_NULL for low-null important columns, UNIQUE for potential keys, RANGE_CHECK for numerics, TIME_STAMP_CHECK/DATE_RANGE for dates.
7. Do not invent column names; only use columns present in the profile."""


def call_databricks_llm(prompt):
    """
    Calls the Databricks foundation model through ai_query() on the SQL
    warehouse. The prompt is passed as a bound parameter, so no manual
    escaping is needed.
    """
    query = f"""
        SELECT ai_query(
            '{LLM_ENDPOINT}',
            :prompt,
            modelParameters => named_struct('max_tokens', 4096, 'temperature', 0.1)
        ) AS rules_json
    """
    params = [{"name": "prompt", "type": "STRING", "value": prompt}]
    rows = execute_sql("ai_query_recommend_rules", query, params, timeout_seconds=300)
    if not rows:
        raise Exception("LLM returned no result.")
    return rows[0].get("rules_json") or ""


def parse_llm_rules(rules_text):
    start = rules_text.find("[")
    end = rules_text.rfind("]") + 1
    if start == -1 or end == 0:
        raise Exception("Could not find a JSON array in the LLM response.")
    return json.loads(rules_text[start:end])


def recommend_rules(catalog, schema, table):
    """Main entry point used by the API route."""
    for name in (catalog, schema, table):
        if not is_valid_identifier(name):
            raise ValueError("Invalid catalog/schema/table name provided.")

    profile = profile_table(catalog, schema, table)
    valid_columns = {c["column_name"] for c in profile["columns"]}

    prompt = build_prompt(profile)
    raw = call_databricks_llm(prompt)
    llm_rules = parse_llm_rules(raw)

    severity_rank = {"Critical": 3, "Warning": 2, "Info": 1}
    llm_rules.sort(key=lambda r: severity_rank.get(r.get("severity"), 2), reverse=True)

    formatted = []
    for rule in llm_rules[:MAX_TOTAL_RULES]:
        condition_type = str(rule.get("condition_type", "")).upper().strip()
        if condition_type not in TYPE_TO_CATEGORY:
            continue

        column_name = str(rule.get("column_name", "")).strip()
        # keep only rules that reference real columns (DUPLICATE may list several)
        cols = [c.strip() for c in column_name.split(",") if c.strip()]
        if not cols or any(c not in valid_columns for c in cols):
            continue

        criteria = rule.get("condition_criteria")
        if criteria is not None and not isinstance(criteria, str):
            criteria = json.dumps(criteria)
        if isinstance(criteria, str) and criteria.strip().lower() in ("null", "none", ""):
            criteria = None

        severity = rule.get("severity", "Warning")
        if severity not in severity_rank:
            severity = "Warning"

        try:
            threshold = int(rule.get("violation_threshold", 0))
        except (TypeError, ValueError):
            threshold = 0

        formatted.append({
            "catalog": catalog,
            "schema": schema,
            "table_name": table,
            "column_name": ",".join(cols),
            "rule_description": rule.get("rule_description", ""),
            "condition_category": TYPE_TO_CATEGORY[condition_type],
            "condition_type": condition_type,
            "condition_criteria": criteria,
            "severity": severity,
            "violation_threshold": threshold,
            # Recommended rules default to the safer enforcement option; the
            # user can change this per-rule before submitting for approval.
            "enforcement_action": "BLOCK_AND_AUDIT",
            "email_alert_enabled": True,
            "alert_group_id": None,
        })

    return formatted
